================
IMPORTANT NOTICE 
================
 
This script is designed to collect information that will help Microsoft Customer Support Services (CSS) troubleshoot an issue you may be experiencing with Azure Virtual Desktop.

The collected data may contain Personally Identifiable Information (PII) and/or sensitive data, such as (but not limited to) IP addresses, PC names and user names.

The script will save the collected data in a subfolder and also compress the results into a ZIP file. The folder or ZIP file are not automatically sent to Microsoft. 

You can send the ZIP file to Microsoft CSS using a secure file transfer tool - Please discuss this with your support professional and also any concerns you may have. 

Find our privacy statement here: https://privacy.microsoft.com/en-US/privacystatement


===================================
How to use AVD-Collect (v210623.0)
===================================

The script must be run with elevated permissions in order to collect all required data.
All collected data will be archived into a .zip file located in the same folder as the script itself.
Run the script on AVD host VMs and/or Windows based devices from where you connect to the AVD hosts, as needed.

When launched, the script will present the Microsoft Diagnostic Tools End User License Agreement (EULA). You need to accept the EULA before you can continue using the script.
Acceptance of the EULA will be stored in the registry under HKCU\Software\Microsoft\CESDiagnosticTools and you will not be prompted again to accept it as long as the registry key is in place.
You can also use the "-AcceptEula" command line parameter to silently accept the EULA.
This is a per user setting, so each user running the script will have to accept the EULA once.

When launched without any command line parameter, the script will ask you to select one of the following five scenarios:

	"Core" (suitable for troubleshooting issues that do not involve Profiles or Teams or MSIX App Attach)
		* Collects core troubleshooting data without including Profiles/FSLogix/OneDrive or Teams or MSIXAA related data
		* Runs Diagnostics. Diagnostics results will be logged

	"Core + Profiles" (suitable for troubleshooting Profiles issues)
		​​​​​​​* Collects all Core data	
		* Collects Profiles/FSLogix/OneDrive related information, as available
		* Runs Diagnostics. Diagnostics results will be logged

	"Core + Teams" (suitable for troubleshooting Teams issues)
		* Collects all Core data
		* Collects Teams related information, as available
		* Runs Diagnostics. Diagnostics results will be logged

	"Core + MSIX App Attach" (suitable for troubleshooting MSIX App Attach issues)
		* Collects all Core data
		* Collects MSIX App Attach related information, as available
		* Runs Diagnostics. Diagnostics results will be logged

	"Core + MSRA" (suitable for troubleshooting Remote Assistance issues)
		* Collects all Core data
		* Collects Remote Assistance related information, as available
		* Runs Diagnostics. Diagnostics results will be logged

	"Extended (all)" (suitable for troubleshooting most issues, including Profiles/FSLogix/OneDrive, Teams and MSIX App Attach)
		* Collects all Core data
		* Collects Profiles/FSLogix/OneDrive related information, as available
		* Collects Microsoft Teams related information, as available
		* Collects MSIX App Attach related information, as available
		* Runs Diagnostics. Diagnostics results will be logged

	"DiagOnly"
​​​​​​​		* Skips all Core/Extended data collection and runs Diagnostics only (regardless if any other parameters have been specified)
		* Runs Diagnostics. Diagnostics results will be logged

The default scenario is "Core".​​​​​​​



Available command line parameters (to preselect the desired scenario)
---------------------------------------------------------------------

	"-Core" - Collects Core data + Runs Diagnostics

	"-Extended" - Collects all Core data + Extended (Profiles/FSLogix/OneDrive, Teams, MSIX App Attach) data + Runs Diagnostics

	"-Profiles" - Collects all Core data + Profiles/FSLogix/OneDrive data + Runs Diagnostics

	"-Teams" - Collects all Core data + Teams data + Runs Diagnostics

	"-MSIXAA" - Collects all Core data + MSIX App Attach data + Runs Diagnostics

	"-MSRA" - Collects all Core data + Remote Assistance data + Runs Diagnostics

	"-DiagOnly" - The script will skip all data collection and will only run the diagnostics part (even if other parameters have been included).

	"-AcceptEula" - Silently accepts the Microsoft Diagnostic Tools End User License Agreement


Usage example with parameters:

To collect only Core data (excluding Profiles/FSLogix/OneDrive, Teams, MSIX App Attach):
	.\AVD-Collect.ps1 -Core

To collect Core + Extended data (incl. Profiles/FSLogix/OneDrive, Teams, MSIX App Attach):
	.\AVD-Collect.ps1 -Extended

To collect Core + Profiles + MSIX App Attach data 
	.\AVD-Collect.ps1 -Profiles -MSIXAA

To collect Core + Profiles data
	.\AVD-Collect.ps1 -Profiles


​​​​​​​If you are missing any of the data that the script should normally collect (see "Data being collected"), check the content of "*_AVD-Collect-Log.txt" and "*_AVD-Collect-Errors.txt" files for more information. Some data may not be present during data collection and thus not picked up by the script. This should be visible in one of the two text files.



PowerShell ExecutionPolicy
--------------------------

If the script does not start, complaining about execution restrictions, then in an elevated PowerShell console run:

	Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force -Scope Process

and verify with "Get-ExecutionPolicy -List" that no ExecutionPolicy with higher precedence is blocking execution of this script.
The script is digitally signed with a Microsoft Code Sign certificate.

After that run the AVD-Collect script again.


Once the script has started, p​​​lease read the "IMPORTANT NOTICE" message and confirm if you agree to continue with the data collection.

Depending on the amount of data that needs to be collected, the script may need run for a few minutes. Please wait until the script finishes collecting all the data.



====================
Data being collected
====================

The collected data is stored in a subfolder under the same folder where the script is located and at the end of the data collection, the results are archived into a .zip file. No data is automatically uploaded to Microsoft.

Data collected in the "Core" scenario:

• Log files
	o C:\Packages\Plugins\Microsoft.Powershell.DSC\<version>\Status\​​​​​​​
	o C:\Packages\Plugins\Microsoft.Compute.JsonADDomainExtension\<version>\Status\
	o C:\Packages\Plugins\Microsoft.EnterpriseCloud.Monitoring.MicrosoftMonitoringAgent\<version>\Status\
	o C:\Program Files\Microsoft RDInfra\AgentInstall.txt
	o C:\Program Files\Microsoft RDInfra\​GenevaInstall.txt
	o C:\Program Files\Microsoft RDInfra\​SXSStackInstall.txt
	o C:\Program Files\Microsoft RDInfra\WVDAgentManagerInstall.txt
	o C:\Users\AgentInstall.txt
	o C:\Users\AgentBootLoaderInstall.txt
	o C:\Windows\debug\NetSetup.log
	o C:\Windows\Temp\ScriptLog.log
	o C:\WindowsAzure\Logs\WaAppAgent.log
	o C:\WindowsAzure\Logs\MonitoringAgent.log
	o C:\WindowsAzure\Logs\Plugins\
• Geneva Scheduled Task information
• "set MON" output (Monitoring Agent)
• Local group membership information
	o Remote Desktop Users
	o Distributed COM Users
	o Offer Remote Assistance Helpers
• Registry keys
	o HKEY_CURRENT_USER\SOFTWARE\Microsoft\RdClientRadc
	o HKEY_CURRENT_USER\SOFTWARE\Microsoft\Remote Desktop​
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Azure\DSC
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\MSRDC\Policies
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDAgentBootLoader
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDInfraAgent
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDMonitoringAgent
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WVDAgentManager
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Terminal Server Client
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies
	o ​​​​​​​HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Terminal Server
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Cryptography
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Remote Assistance
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server​​
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\RdAgent
	o ​​​​​​​HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\RDAgentBootLoader
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WVDAgent
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WVDAgentManager
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\TermService
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\UmRdpService
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WinRM​​
• Event Logs
	o Application
	o Microsoft-Windows-CAPI2/Operational
	o Microsoft-Windows-DSC/Operational
	o Microsoft-Windows-PowerShell/Operational
	o Microsoft-Windows-RemoteAssistance/Admin
	o Microsoft-Windows-RemoteAssistance/Operational
	o Microsoft-Windows-RemoteDesktopServices
	o Microsoft-Windows-RemoteDesktopServices-RdpCoreCDV/Admin
	o Microsoft-Windows-RemoteDesktopServices-RdpCoreCDV/Operational
	o Microsoft-Windows-RemoteDesktopServices-RdpCoreTS/Admin
	o Microsoft-Windows-RemoteDesktopServices-RdpCoreTS/Operational
	o Microsoft-Windows-TaskScheduler/Operational
	o Microsoft-Windows-TerminalServices-LocalSessionManager/Admin
	o Microsoft-Windows-TerminalServices-LocalSessionManager/Operational
	o Microsoft-Windows-TerminalServices-PnPDevices/Admin
	o Microsoft-Windows-TerminalServices-PnPDevices/Operational
	o Microsoft-Windows-TerminalServices-RemoteConnectionManager/Admin
	o Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational
	o Microsoft-Windows-WinINet-Config/ProxyConfigChanged
	o Microsoft-Windows-WinRM/Operational
	o Microsoft-WindowsAzure-Diagnostics/Bootstrapper
	o Microsoft-WindowsAzure-Diagnostics/GuestAgent
	o Microsoft-WindowsAzure-Diagnostics/Heartbeat
	o Microsoft-WindowsAzure-Diagnostics/Runtime
	o Microsoft-WindowsAzure-Status/GuestAgent
	o Microsoft-WindowsAzure-Status/Plugins
	o Security
	o System
• "gpresult /h" and "gpresult /r /v" output
• "fltmc filters" output
• Details of the running processes and services
• Networking information (firewall rules, ipconfig /all, profiles, netstat -anob, proxy configuration)
• "Qwinsta /counter" output
• PowerShell version
• "Get-Hotfix" output
• "Get-DscConfiguration" and "Get-DscConfigurationStatus" output
• File versions of the currently running binaries
• File information about the AVD desktop client binaries ("msrdc.exe" and "msrdcw.exe")
• File versions of key binaries:
	o Windows\System32\*.dll
	o Windows\System32\*.exe
	o Windows\System32\*.sys
	o Windows\System32\drivers\*.sys
• Basic system information
• .NET Framework information
• Msinfo32 output
• WinRM configuration information
• Certificate My store information
• Certificate thumbprint information
• DxDiag output in .txt format with no WHQL check
• "dsregcmd /status" output
• The content of the "C:\Users\%username%\AppData\Local\Temp\DiagOutputDir\RdClientAutoTrace" folder (available on devices used as source clients to connect to AVD hosts) from the past 5 days, containing:
	o AVD remote desktop client connection ETL traces
	o AVD remote desktop client application ETL traces
	o AVD remote desktop client upgrade log (MSI.log)
• Convert existing .tsf files on AVD hosts from under "C:\Windows\System32\config\systemprofile\AppData\Roaming\Microsoft\Monitoring\Tables" into .csv files and collect the resulting .csv files
• "route print" output
• "Azure Instance Metadata service endpoint" request info
• <BrokerURI>api/health and <BrokerURIGlobal>api/health status


Data collected in the "Extended" scenarios:

• Log files
	o C:\ProgramData\FSLogix\Logs
	o %appdata%\Microsoft\Teams\logs.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME_calling.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME_cdl.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME_cdlWorker.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME_chatListData.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME_sync.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME_vdi_partner.txt
• Registry keys
	o HKEY_CURRENT_USER\SOFTWARE\Microsoft\Office​
	o HKEY_CURRENT_USER\SOFTWARE\Microsoft\OneDrive
	o HKEY_CURRENT_USER\SOFTWARE\Policies\Microsoft\Office
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\OneDrive
	o HKEY_LOCAL_MACHINE\SOFTWARE\FSLogix
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Search
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\FSLogix
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Exclusions\Extensions
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Extensions
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Paths
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Processes
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Teams
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\RDWebRTCSvc
• Event Logs
	o Microsoft-FSLogix-Apps/Admin
	o Microsoft-FSLogix-Apps/Operational
	o Microsoft-Windows-AppXDeploymentServer/Operational
	o Microsoft-Windows-SMBClient/Connectivity
	o Microsoft-Windows-SMBClient/Operational
	o Microsoft-Windows-SMBClient/Security
	o Microsoft-Windows-SMBServer/Connectivity
	o Microsoft-Windows-SMBServer/Operational
	o Microsoft-Windows-SMBServer/Security
	o Microsoft-Windows-User Profile Service/Operational
	o Microsoft-Windows-VHDMP/Operational
• FSLogix tool output
	o frx list-redirects
	o frx list-rules
	o frx version
• Local group membership information
	o FSLogix ODFC Exclude List
	o FSLogix ODFC Include List
	o FSLogix Profile Exclude List
	o FSLogix Profile Include List



========
AVD-Diag
========

AVD-Collect also performs diagnostics for some common known issues, regardless of the selected scenario.
Based on your requirements, you may want to skip specific data collection or run diagnostics only. See the scenario descriptions above.
New diagnostics checks may be added in each new release, so make sure to always use the latest version of the script.​​​​​​​

Important Notes:
"Diagnostics" is not a replacement of a full data analysis. It is only meant to give you basic diagnostics of some common scenarios and to ease further troubleshooting. Depending on the scenario, further data collection and analysis will be needed.

Version 210623.0 of the script can perform the following diagnostics:

• Brief check of the system the script is running on (from AVD point of view): FQDN, OS, OS Build
	o Check if the VM is part of a AVD host pool: SessionHostPool name, Ring, Geography
	o Check if the running OS is supported when the VM is part of a AVD host pool
	o Check for last machine boot up time, with an extra notification if it occurred >= 25 hours ago
	o Check for the number of vCPUs available on the machine
	o Check for "LmCompatibilityLevel" registry key value
	o Check for Time Zone Redirection policy configuration
• Check the status of key services: RdAgent, RDAgentBootLoader, WVDAgent (Win7 only), WVDAgentManager (Win7 only), TermService, SessionEnv, UmRdpService, AppReadiness, AppXSvc, WinRM, frxsvc, frxdrv, frxccds, OneDrive Updater Service, msiserver (Windows Installer)
• Check for current and previous AVD Agent and Stack versions and their installation dates (Windows 10 and Server OS hosts)
• Check for all available RD listeners and their configuration: fEnableWinStation, fReverseConnectMode, ReverseConnectionListener
• Check for <BrokerURI>api/health and <BrokerURIGlobal>api/health availability
• Check for AVD agent issues over the past 5 days:
​​​​​​​	o "INVALID_REGISTRATION_TOKEN" (Event 3277)
	o "INVALID_FORM" (Event 3277)
	o "InstallationHealthCheckFailedException" (Event 3277)
	o "ENDPOINT_NOT_FOUND" (Event 3277)
	o "NAME_ALREADY_REGISTERED" (Event 3277)
	o "InstallMsiException" (Event 3277)
	o "DownloadMsiException" (Event 3277)
	o "Transport received an exception" (Event 3019)
	o "RD Gateway Url" (Event 3703)
	o "MissingMethodException" (Event 3389)
	o "SessionHost unhealthy" (Event 0)
	o "IMDS not accessible" (Event 0)
	o "Monitoring Agent Launcher file path was NOT located" (Event 0)
	o "NOT ALL required URLs are accessible!" (Event 0)
	o "Unable to connect to the remote server" (Event 0)
	o "Unhandled status [ConnectFailure] returned for url" (Event 0)
• Check for Session Time Limit policy settings
• Check for required URLs
• Check for WinHTTP proxy settings
• Check for Process crashes that occurred within the last 7 days
• Check the availability and value of the reg key responsible for the 'SSL Cipher Suite Order' policy for scenarios where users cannot connect with a message containing 'security package error' or 'no available resources'
• Check for "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\EccCurves"
• Check if the Remote Desktop Session Host role is installed on the VM when running a Server OS
• Check if reg key "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\DisableAntiSpyware" is enabled on Server OS
• Check for FSLogix best practice settings for enterprises
• Check for "frxsvc" service recovery settings
• Check for Cloud Cache "CCDLocations" registry key for Profile and Office Container
• Check the availability and value of the "CleanupInvalidSessions" registry key when FSLogix is present on the system
• Check for the presence of the recommended Windows Defender Antivirus exclusion values when FSLogix is present on the system
• Check OneDrive configuration/requirements when FSLogix is present on the system
• Check media optimization configuration for Teams when Teams is present on the system
• Check the availability and value of the reg key: 'DeleteUserAppContainersOnLogoff' for firewall rules bloating scenarios
• Check WinRM configuration / requirements
	o ​​​​​​​Presence of "WinRMRemoteWMIUsers__" group
	o IPv4Filter and IPv6Filter values
	o Presence of firewall rules for ports 5985 and 5986
• Check for RDP ShortPath configuration (Windows 10 and Server OS hosts)
• Check for MSIX App Attach issues over the past 5 days:
	* "A certificate chain processed, but terminated in a root certificate which is not trusted by the trust provider"
	* "MountDisk:  Error occured during mount"

The script generates a *_AVD-Diag.txt and a *_AVD-Diag.html output file with the results of the above checks. Additional output files may be generated if process crashes or AVD Agent or MSIX App Attach issues have been identified.


==========
Tool Owner
==========
Robert Viktor Klemencz @ Microsoft Customer Service and Support
If you have any feedback about the tool or want to report any issues with it, please reach out to WVDCollectTalk@microsoft.com



