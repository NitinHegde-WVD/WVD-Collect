﻿<#
    .SYNOPSIS
    Simplify data collection for troubleshooting Azure Virtual Desktop issues and a convenient method for submitting and following quick & easy action plans.

    .DESCRIPTION
    This script is designed to collect information that will help Microsoft Customer Support Services (CSS) troubleshoot an issue you may be experiencing with Azure Virtual Desktop.
    The collected data may contain Personally Identifiable Information (PII) and/or sensitive data, such as (but not limited to) IP addresses; PC names; and user names.
    The script will save the collected data in a folder and also compress the results into a ZIP file, both in the same location from where the script has been launched.
    This folder and its contents or the ZIP file are not automatically sent to Microsoft.
    You can send the ZIP file to Microsoft CSS using a secure file transfer tool - Please discuss this with your support professional and also any concerns you may have.
    Find our privacy statement here: https://privacy.microsoft.com/en-US/privacystatement

    Run 'Get-Help AVD-Collect.ps1 -Full' for more details.

    USAGE SUMMARY:

    The script must be run with elevated permissions in order to collect all required data.
    Run the script on AVD host VMs and/or on Windows based devices from where you connect to the AVD hosts, as needed.

    When launched without any command line parameter, you can select one of the available data collection/diagnostics scenarios. Diagnostics will run for every scenario.

    1: Collect 'Core' data + Run Diagnostics
    2: Collect 'Core + Profiles' data + Run Diagnostics
    3: Collect 'Core + Teams' data + Run Diagnostics
    4: Collect 'Core + MSIX App Attach' data + Run Diagnostics
    5: Collect 'Core + Remote Assistance' data + Run Diagnostics
    6: Collect 'Extended' diagnostic data (Core + all other categories) + Run Diagnostics
    7: Run 'Diagnostics' only (skip data collection - may still log process crash or agent related events, if found)

    If you want to combine multiple (but not all) scenarios or skip having to manually select a scenario, use command line parameters.

    .NOTES
    Author           : Robert Viktor Klemencz (robert.klemencz@microsoft.com)
    Requires         : PowerShell 5.1
    Last update      : June 23th, 2021
    Version          : 210623.0

    .PARAMETER Core
    This parameter will collect only basic AVD data (without Profiles/FSLogix/OneDrive/Teams/MSIX App Attach/MSRA related information).
    Diagnostics will also run at the end.

    .PARAMETER Extended
    This parameter will collect all the basic AVD data, plus Profiles/FSLogix/OneDrive, Teams, MSIX App Attach and MSRA related information.
    Diagnostics will also run at the end.
    If the tool is launched with both "-Core" and "-Extended" parameters at the same time, the higher ("-Extended") parameter will be applied.

    .PARAMETER Profiles
    Use this parameter to collect Core + Profiles/FSLogix/OneDrive related data.
    Diagnostics will also run at the end.

    .PARAMETER Teams
    Use this parameter to collect Core + Microsoft Teams related data.
    Diagnostics will also run at the end.

    .PARAMETER MSIXAA
    Use this parameter to collect Core + MSIX App Attach related data.
    Diagnostics will also run at the end.

    .PARAMETER MSRA
    Use this parameter to collect Core + Remote Assistance related data.
    Diagnostics will also run at the end.

    .PARAMETER DiagOnly
    This parameter will skip collecting troubleshooting data (even if any other parameters are specificed) and will only perform diagnostics. The results of the diagnostics will be stored in the 'AVD-Diag.txt' and 'AVD-Diag.html' files.
    If process crash events have been detected over the past 5 days, information about these process crashes will be logged under 'AVD-Diag-ProcessCrashEvents.txt'.
    If AVD agent issues events have been detected over the past 5 days, information about these agent issues will be logged under 'AVD-Diag-AgentIssuesEvents.txt'.
    If MSIX App Attach issues events have been detected over the past 5 days, information about these MSIXAA issues will be logged under 'AVD-Diag-MSIXAAIssuesEvents.txt'.

    .OUTPUTS
    By default, all collected data are stored in a subfolder in the same location from where the tool was launched.
#>


param ([switch]$Core = $false, [switch]$Extended = $false, [switch]$DiagOnly = $false, [switch]$Teams = $false, [switch]$Profiles = $false, [switch]$MSIXAA = $false, [switch]$MSRA = $false, [switch]$AcceptEula)

$version = "210623.0"
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$myWindowsPrincipal = new-object System.Security.Principal.WindowsPrincipal($myWindowsID)
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator
if (-not $myWindowsPrincipal.IsInRole($adminRole)) {
    Write-Host "This script needs to be run as Administrator" -ForegroundColor Yellow
    exit
}


#region ####################### Initializing ########################

$LogRoot = Split-Path (Get-Variable MyInvocation).Value.MyCommand.Path
$LogFolder = "AVD-Results-" + $env:computername +"-" + $(get-date -f yyyyMMdd_HHmmss)
$LogDir = "$LogRoot\$LogFolder\"
$LogFilePrefix = $env:computername + "_"

New-Item -itemtype directory -path $LogDir | Out-Null

$BasicLogFolder = "$LogDir$env:computername" + "_"
$CertLogFolder = $BasicLogFolder + "Certificates\"
$EventLogFolder = $BasicLogFolder + "EventLogs\"
$LogFileLogFolder = $BasicLogFolder + "LogFiles\"
$NetLogFolder = $BasicLogFolder + "Networking\"
$RegLogFolder = $BasicLogFolder + "RegistryKeys\"
$GenevaLogFolder = $BasicLogFolder + "Geneva\"
$MonTablesFolder = $GenevaLogFolder + "MonTables\"
$SysInfoLogFolder = $BasicLogFolder + "SystemInfo\"
$RDCTraceFolder = $BasicLogFolder + "RDClientAutoTrace\"
$FSLogixLogFolder = $BasicLogFolder + "FSLogix\"
$TeamsLogFolder = $BasicLogFolder + "Teams\"
$ErrorLogFile = $BasicLogFolder + "AVD-Collect-Error.txt"
$TempCommandErrorFile = $BasicLogFolder + "AVD-Collect-CommandError.txt"
$OutputLogFile = $BasicLogFolder + "AVD-Collect-Log.txt"

$LogLevel = @{
    'Normal' = 0
    'Info' = 1
    'Warning' = 2
    'Error' = 3
    'ErrorLogFileOnly' = 4
    'WarnLogFileOnly' = 5
    'DiagFileOnly' = 7
}

$ver = (Get-CimInstance Win32_OperatingSystem).Caption
$fqdn = [System.Net.Dns]::GetHostByName(($env:computerName)).HostName

# Read-only valuables
Set-Variable -Name 'fLogFileOnly' -Value $True -Option readonly

#endregion Initializing


#region ####################### Functions ########################

#region Internal functions

[void][System.Reflection.Assembly]::Load('System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
[void][System.Reflection.Assembly]::Load('System.Windows.Forms, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')

function ShowEULAPopup($mode)
{
    $EULA = New-Object -TypeName System.Windows.Forms.Form
    $richTextBox1 = New-Object System.Windows.Forms.RichTextBox
    $btnAcknowledge = New-Object System.Windows.Forms.Button
    $btnCancel = New-Object System.Windows.Forms.Button

    $EULA.SuspendLayout()
    $EULA.Name = "EULA"
    $EULA.Text = "Microsoft Diagnostic Tools End User License Agreement"

    $richTextBox1.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $richTextBox1.Location = New-Object System.Drawing.Point(12,12)
    $richTextBox1.Name = "richTextBox1"
    $richTextBox1.ScrollBars = [System.Windows.Forms.RichTextBoxScrollBars]::Vertical
    $richTextBox1.Size = New-Object System.Drawing.Size(776, 397)
    $richTextBox1.TabIndex = 0
    $richTextBox1.ReadOnly=$True
    $richTextBox1.Add_LinkClicked({Start-Process -FilePath $_.LinkText})
    $richTextBox1.Rtf = @"
{\rtf1\ansi\ansicpg1252\deff0\nouicompat{\fonttbl{\f0\fswiss\fprq2\fcharset0 Segoe UI;}{\f1\fnil\fcharset0 Calibri;}{\f2\fnil\fcharset0 Microsoft Sans Serif;}}
{\colortbl ;\red0\green0\blue255;}
{\*\generator Riched20 10.0.19041}{\*\mmathPr\mdispDef1\mwrapIndent1440 }\viewkind4\uc1 
\pard\widctlpar\f0\fs19\lang1033 MICROSOFT SOFTWARE LICENSE TERMS\par
Microsoft Diagnostic Scripts and Utilities\par
\par
{\pict{\*\picprop}\wmetafile8\picw26\pich26\picwgoal32000\pichgoal15 
0100090000035000000000002700000000000400000003010800050000000b0200000000050000
000c0202000200030000001e000400000007010400040000000701040027000000410b2000cc00
010001000000000001000100000000002800000001000000010000000100010000000000000000
000000000000000000000000000000000000000000ffffff00000000ff040000002701ffff0300
00000000
}These license terms are an agreement between you and Microsoft Corporation (or one of its affiliates). IF YOU COMPLY WITH THESE LICENSE TERMS, YOU HAVE THE RIGHTS BELOW. BY USING THE SOFTWARE, YOU ACCEPT THESE TERMS.\par
{\pict{\*\picprop}\wmetafile8\picw26\pich26\picwgoal32000\pichgoal15 
0100090000035000000000002700000000000400000003010800050000000b0200000000050000
000c0202000200030000001e000400000007010400040000000701040027000000410b2000cc00
010001000000000001000100000000002800000001000000010000000100010000000000000000
000000000000000000000000000000000000000000ffffff00000000ff040000002701ffff0300
00000000
}\par
\pard 
{\pntext\f0 1.\tab}{\*\pn\pnlvlbody\pnf0\pnindent0\pnstart1\pndec{\pntxta.}}
\fi-360\li360 INSTALLATION AND USE RIGHTS. Subject to the terms and restrictions set forth in this license, Microsoft Corporation (\ldblquote Microsoft\rdblquote ) grants you (\ldblquote Customer\rdblquote  or \ldblquote you\rdblquote ) a non-exclusive, non-assignable, fully paid-up license to use and reproduce the script or utility provided under this license (the "Software"), solely for Customer\rquote s internal business purposes, to help Microsoft troubleshoot issues with one or more Microsoft products, provided that such license to the Software does not include any rights to other Microsoft technologies (such as products or services). \ldblquote Use\rdblquote  means to copy, install, execute, access, display, run or otherwise interact with the Software. \par
\pard\widctlpar\par
\pard\widctlpar\li360 You may not sublicense the Software or any use of it through distribution, network access, or otherwise. Microsoft reserves all other rights not expressly granted herein, whether by implication, estoppel or otherwise. You may not reverse engineer, decompile or disassemble the Software, or otherwise attempt to derive the source code for the Software, except and to the extent required by third party licensing terms governing use of certain open source components that may be included in the Software, or remove, minimize, block, or modify any notices of Microsoft or its suppliers in the Software. Neither you nor your representatives may use the Software provided hereunder: (i) in a way prohibited by law, regulation, governmental order or decree; (ii) to violate the rights of others; (iii) to try to gain unauthorized access to or disrupt any service, device, data, account or network; (iv) to distribute spam or malware; (v) in a way that could harm Microsoft\rquote s IT systems or impair anyone else\rquote s use of them; (vi) in any application or situation where use of the Software could lead to the death or serious bodily injury of any person, or to physical or environmental damage; or (vii) to assist, encourage or enable anyone to do any of the above.\par
\par
\pard\widctlpar\fi-360\li360 2.\tab DATA. Customer owns all rights to data that it may elect to share with Microsoft through using the Software. You can learn more about data collection and use in the help documentation and the privacy statement at {{\field{\*\fldinst{HYPERLINK https://aka.ms/privacy }}{\fldrslt{https://aka.ms/privacy\ul0\cf0}}}}\f0\fs19 . Your use of the Software operates as your consent to these practices.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 3.\tab FEEDBACK. If you give feedback about the Software to Microsoft, you grant to Microsoft, without charge, the right to use, share and commercialize your feedback in any way and for any purpose.\~ You will not provide any feedback that is subject to a license that would require Microsoft to license its software or documentation to third parties due to Microsoft including your feedback in such software or documentation. \par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 4.\tab EXPORT RESTRICTIONS. Customer must comply with all domestic and international export laws and regulations that apply to the Software, which include restrictions on destinations, end users, and end use. For further information on export restrictions, visit {{\field{\*\fldinst{HYPERLINK https://aka.ms/exporting }}{\fldrslt{https://aka.ms/exporting\ul0\cf0}}}}\f0\fs19 .\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360\qj 5.\tab REPRESENTATIONS AND WARRANTIES. Customer will comply with all applicable laws under this agreement, including in the delivery and use of all data. Customer or a designee agreeing to these terms on behalf of an entity represents and warrants that it (i) has the full power and authority to enter into and perform its obligations under this agreement, (ii) has full power and authority to bind its affiliates or organization to the terms of this agreement, and (iii) will secure the permission of the other party prior to providing any source code in a manner that would subject the other party\rquote s intellectual property to any other license terms or require the other party to distribute source code to any of its technologies.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360\qj 6.\tab DISCLAIMER OF WARRANTY. THE SOFTWARE IS PROVIDED \ldblquote AS IS,\rdblquote  WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL MICROSOFT OR ITS LICENSORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\par
\pard\widctlpar\qj\par
\pard\widctlpar\fi-360\li360\qj 7.\tab LIMITATION ON AND EXCLUSION OF DAMAGES. IF YOU HAVE ANY BASIS FOR RECOVERING DAMAGES DESPITE THE PRECEDING DISCLAIMER OF WARRANTY, YOU CAN RECOVER FROM MICROSOFT AND ITS SUPPLIERS ONLY DIRECT DAMAGES UP TO U.S. $5.00. YOU CANNOT RECOVER ANY OTHER DAMAGES, INCLUDING CONSEQUENTIAL, LOST PROFITS, SPECIAL, INDIRECT, OR INCIDENTAL DAMAGES. This limitation applies to (i) anything related to the Software, services, content (including code) on third party Internet sites, or third party applications; and (ii) claims for breach of contract, warranty, guarantee, or condition; strict liability, negligence, or other tort; or any other claim; in each case to the extent permitted by applicable law. It also applies even if Microsoft knew or should have known about the possibility of the damages. The above limitation or exclusion may not apply to you because your state, province, or country may not allow the exclusion or limitation of incidental, consequential, or other damages.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 8.\tab BINDING ARBITRATION AND CLASS ACTION WAIVER. This section applies if you live in (or, if a business, your principal place of business is in) the United States.  If you and Microsoft have a dispute, you and Microsoft agree to try for 60 days to resolve it informally. If you and Microsoft can\rquote t, you and Microsoft agree to binding individual arbitration before the American Arbitration Association under the Federal Arbitration Act (\ldblquote FAA\rdblquote ), and not to sue in court in front of a judge or jury. Instead, a neutral arbitrator will decide. Class action lawsuits, class-wide arbitrations, private attorney-general actions, and any other proceeding where someone acts in a representative capacity are not allowed; nor is combining individual proceedings without the consent of all parties. The complete Arbitration Agreement contains more terms and is at {{\field{\*\fldinst{HYPERLINK https://aka.ms/arb-agreement-4 }}{\fldrslt{https://aka.ms/arb-agreement-4\ul0\cf0}}}}\f0\fs19 . You and Microsoft agree to these terms. \par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 9.\tab LAW AND VENUE. If U.S. federal jurisdiction exists, you and Microsoft consent to exclusive jurisdiction and venue in the federal court in King County, Washington for all disputes heard in court (excluding arbitration). If not, you and Microsoft consent to exclusive jurisdiction and venue in the Superior Court of King County, Washington for all disputes heard in court (excluding arbitration).\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 10.\tab ENTIRE AGREEMENT. This agreement, and any other terms Microsoft may provide for supplements, updates, or third-party applications, is the entire agreement for the software.\par
\pard\sa200\sl276\slmult1\f1\fs22\lang9\par
\pard\f2\fs17\lang2057\par
}
"@
    $richTextBox1.BackColor = [System.Drawing.Color]::White
    $btnAcknowledge.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnAcknowledge.Location = New-Object System.Drawing.Point(544, 415)
    $btnAcknowledge.Name = "btnAcknowledge";
    $btnAcknowledge.Size = New-Object System.Drawing.Size(119, 23)
    $btnAcknowledge.TabIndex = 1
    $btnAcknowledge.Text = "Accept"
    $btnAcknowledge.UseVisualStyleBackColor = $True
    $btnAcknowledge.Add_Click({$EULA.DialogResult=[System.Windows.Forms.DialogResult]::Yes})

    $btnCancel.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnCancel.Location = New-Object System.Drawing.Point(669, 415)
    $btnCancel.Name = "btnCancel"
    $btnCancel.Size = New-Object System.Drawing.Size(119, 23)
    $btnCancel.TabIndex = 2
    if($mode -ne 0)
    {
	    $btnCancel.Text = "Close"
    }
    else
    {
	    $btnCancel.Text = "Decline"
    }
    $btnCancel.UseVisualStyleBackColor = $True
    $btnCancel.Add_Click({$EULA.DialogResult=[System.Windows.Forms.DialogResult]::No})

    $EULA.AutoScaleDimensions = New-Object System.Drawing.SizeF(6.0, 13.0)
    $EULA.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Font
    $EULA.ClientSize = New-Object System.Drawing.Size(800, 450)
    $EULA.Controls.Add($btnCancel)
    $EULA.Controls.Add($richTextBox1)
    if($mode -ne 0)
    {
	    $EULA.AcceptButton=$btnCancel
    }
    else
    {
        $EULA.Controls.Add($btnAcknowledge)
	    $EULA.AcceptButton=$btnAcknowledge
        $EULA.CancelButton=$btnCancel
    }
    $EULA.ResumeLayout($false)
    $EULA.Size = New-Object System.Drawing.Size(800, 650)

    Return ($EULA.ShowDialog())
}

function ShowEULAIfNeeded($toolName, $mode)
{
	$eulaRegPath = "HKCU:Software\Microsoft\CESDiagnosticTools"
	$eulaAccepted = "No"
	$eulaValue = $toolName + " EULA Accepted"
	if(Test-Path $eulaRegPath)
	{
		$eulaRegKey = Get-Item $eulaRegPath
		$eulaAccepted = $eulaRegKey.GetValue($eulaValue, "No")
	}
	else
	{
		$eulaRegKey = New-Item $eulaRegPath
	}
	if($mode -eq 2) # silent accept
	{
		$eulaAccepted = "Yes"
       		$ignore = New-ItemProperty -Path $eulaRegPath -Name $eulaValue -Value $eulaAccepted -PropertyType String -Force
	}
	else
	{
		if($eulaAccepted -eq "No")
		{
			$eulaAccepted = ShowEULAPopup($mode)
			if($eulaAccepted -eq [System.Windows.Forms.DialogResult]::Yes)
			{
	        		$eulaAccepted = "Yes"
	        		$ignore = New-ItemProperty -Path $eulaRegPath -Name $eulaValue -Value $eulaAccepted -PropertyType String -Force
			}
		}
	}
	return $eulaAccepted
}

Function UEXAVD_LogMessage {
    param( [ValidateNotNullOrEmpty()][int] $Level, [ValidateNotNullOrEmpty()][string] $Message, [ValidateNotNullOrEmpty()][string] $Color)

    If (!$Level) { $Level = $LogLevel.Normal }

    $LogMessage = (get-date).ToString("yyyyMMdd HH:mm:ss.fff") + " " + $Message

    Switch($Level){
        '0'{ # Normal + console
            $MessageColor = 'White'
            $LogConsole = $True
        }
        '1'{ # Info + console
            $MessageColor = 'Yellow'
            $LogConsole = $True
        }
        '2'{ # Warning + console
            $MessageColor = 'Magenta'
            $LogConsole = $True
        }
        '3'{ # Error
            $MessageColor = 'Red'
            $LogConsole = $False
        }
        '4'{ # ErrorLogFileOnly
            $LogConsole = $False
        }
        '5'{ # WarnLogFileOnly
            $LogConsole = $False
        }
    }

    If (($Color) -and $Color.Length -ne 0) { $MessageColor = $Color }

    $Index = 0
    # In case of Warning/Error/Debug, add line and function name to message.
    If($Level -eq $LogLevel.Warning -or $Level -eq $LogLevel.Error -or $Level -eq $LogLevel.Debug -or $Level -eq $LogLevel.ErrorLogFileOnly -or $Level -eq $LogLevel.WarnLogFileOnly){
        $CallStack = Get-PSCallStack
        $CallerInfo = $CallStack[$Index]

        If($CallerInfo.FunctionName -like "*UEXAVD_LogMessage"){
            $CallerInfo = $CallStack[$Index+1]
        }

        If($CallerInfo.FunctionName -like "*UEXAVD_LogException"){
            $CallerInfo = $CallStack[$Index+2]
        }

        $FuncName = $CallerInfo.FunctionName
        If($FuncName -eq "<ScriptBlock>"){
            $FuncName = "Main"
        }
        $LogMessage = ((Get-Date).ToString("yyyyMMdd HH:mm:ss.fff") + ': [' + $FuncName + '(' + $CallerInfo.ScriptLineNumber + ')] ' + $Message)
    }Else{
        $LogMessage = (Get-Date).ToString("yyyyMMdd HH:mm:ss.fff") + " " + $Message
    }

    # In case of Error, log to error file
    If($Level -eq $LogLevel.Error -or $Level -eq $LogLevel.ErrorLogFileOnly){
        If(!(Test-Path -Path $LogDir)){
            UEXAVD_CreateLogFolder $LogDir
        }
        $LogMessage | Out-File -Append $ErrorLogFile
    }

    If($LogConsole){
        Write-Host $LogMessage -ForegroundColor $MessageColor
        $LogMessage | Out-File -Append $OutputLogFile
    }

    if ($Level -eq $LogLevel.WarnLogFileOnly) {
        $LogMessage | Out-File -Append $OutputLogFile
    }

}

Function UEXAVD_LogDiag {
    param( [ValidateNotNullOrEmpty()][int] $Level, [ValidateNotNullOrEmpty()][string] $Message, [string] $Color, [string] $NoTimeStamp)

    If(!$Level){ $Level = $LogLevel.Normal }

    if ($NoTimeStamp) {
        $DiagMessage = $Message
    } else {
        $DiagMessage = (get-date).ToString("yyyyMMdd HH:mm:ss.fff") + " " + $Message
    }

    Switch($Level){
        '0'{ # Normal
            $MessageColor = 'Yellow'
            $LogConsole = $True
        }
        '2'{ # Warning
            $MessageColor = 'Magenta'
            $LogConsole = $True
        }
        '3'{ # Error
            $MessageColor = 'Red'
            $LogConsole = $True
        }
        '7'{ # Info only
            $LogConsole = $False
        }
    }

    If ((!$Color) -and $Color.Length -ne 0) { $MessageColor = $Color }

    If (!(Test-Path -Path $LogDir)) { UEXAVD_CreateLogFolder $LogDir }

    If($LogConsole){
        Write-Host $DiagMessage -ForegroundColor $MessageColor
        $DiagMessage | Out-File -Append $DiagFile
    } else {
        $DiagMessage | Out-File -Append $DiagFile
    }
}

Function UEXAVD_CreateLogFolder {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFolder)

    If(!(test-path -Path $LogFolder)){
        Try {
            Write-Host ((get-date).ToString("yyyyMMdd HH:mm:ss.fff") + " Creating log folder $LogFolder") -ForegroundColor Yellow
            (get-date).ToString("yyyyMMdd HH:mm:ss.fff") + " Creating log folder $LogFolder" | Out-File -Append $OutputLogFile
            New-Item $LogFolder -ItemType Directory -ErrorAction Stop | Out-Null
        } Catch {
            UEXAVD_LogException "ERROR: An error occurred while creating $LogFolder" -ErrObj $_ $fLogFileOnly
        }
    } Else {
        UEXAVD_LogMessage "$LogFolder already exist."
    }
}

Function UEXAVD_CleanUpandExit{
    If(($Null -ne $TempCommandErrorFile) -and (Test-Path -Path $TempCommandErrorFile)){
        Remove-Item $TempCommandErrorFile -Force | Out-Null
    }

    If($fQuickEditCodeExist){
        [DisableConsoleQuickEdit]::SetQuickEdit($False) | Out-Null
    }
    Exit
}

Function UEXAVD_LogException{
    param([parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$Message, [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][System.Management.Automation.ErrorRecord]$ErrObj, [Bool]$fErrorLogFileOnly)

    $ErrorCode = "0x" + [Convert]::ToString($ErrObj.Exception.HResult,16)
    $ExternalException = [System.ComponentModel.Win32Exception]$ErrObj.Exception.HResult
    $ErrorMessage = $Message + "`n" `
        + "Command/Function: " + $ErrObj.CategoryInfo.Activity + " failed with $ErrorCode => " + $ExternalException.Message + "`n" `
        + $ErrObj.CategoryInfo.Reason + ": " + $ErrObj.Exception.Message + "`n" `
        + "ScriptStack:" + "`n" `
        + $ErrObj.ScriptStackTrace
    If($fErrorLogFileOnly){
        UEXAVD_LogMessage $LogLevel.ErrorLogFileOnly $ErrorMessage
    } Else {
        UEXAVD_LogMessage $LogLevel.Error $ErrorMessage
    }
}

Function UEXAVD_RunCommands{
    param(
        [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$LogPrefix, [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String[]]$CmdletArray, [parameter(Mandatory=$true)][Bool]$ThrowException,
        [parameter(Mandatory=$true)][Bool]$ShowMessage, [Bool]$ShowError=$False
    )

    ForEach($CommandLine in $CmdletArray){
        $tmpMsg = $CommandLine -replace "\| Out-File.*$",""
        $tmpMsg = $tmpMsg -replace "\| Out-Null.*$",""
        $tmpMsg = $tmpMsg -replace "\-ErrorAction Stop",""
        $tmpMsg = $tmpMsg -replace "\-ErrorAction SilentlyContinue",""
        $CmdlineForDisplayMessage = $tmpMsg -replace "2>&1",""
        Try{
            If($ShowMessage){
                UEXAVD_LogMessage $LogLevel.Normal ("[$LogPrefix] Running $CmdlineForDisplayMessage")
            }

            # There are some cases where Invoke-Expression does not reset $LASTEXITCODE and $LASTEXITCODE has old error value. Hence initialize the powershell managed value manually...
            $LASTEXITCODE = 0

            # Run actual command here. Redirect all streams to temporary error file as some commands output an error to warning stream(3) and others are to error stream(2).
            Invoke-Expression -Command $CommandLine -ErrorAction Stop *> $TempCommandErrorFile

            # It is possible $LASTEXITCODE becomes null in some sucessful case, so perform null check and examine error code.
            If($LASTEXITCODE -ne $Null -and $LASTEXITCODE -ne 0){
                $Message = "An error happened during running `'$CommandLine` " + '(Error=0x' + [Convert]::ToString($LASTEXITCODE,16) + ')'
                UEXAVD_LogMessage $LogLevel.ErrorLogFileOnly $Message
                If(Test-Path -Path $TempCommandErrorFile){
                    # Always log error to error file.
                    Get-Content $TempCommandErrorFile -ErrorAction SilentlyContinue | Out-File -Append $ErrorLogFile
                    # If -ShowError:$True, show the error to console.
                    If($ShowError){
                        Write-Host ("Error happened in $CommandLine.") -ForegroundColor Red
                        Write-Host ('---------- ERROR MESSAGE ----------')
                        Get-Content $TempCommandErrorFile -ErrorAction SilentlyContinue
                        Write-Host ('-----------------------------------')
                    }
                }
                Remove-Item $TempCommandErrorFile -Force -ErrorAction SilentlyContinue | Out-Null
                If($ThrowException){
                    Throw($Message)
                }
            } Else {
                Remove-Item $TempCommandErrorFile -Force -ErrorAction SilentlyContinue | Out-Null
            }

        }Catch{
            If($ThrowException){
                Throw $_   # Leave the error handling to upper function.
            }Else{
                $Message = "An error happened in Invoke-Expression with $CommandLine"
                UEXAVD_LogException ($Message) -ErrObj $_ $fLogFileOnly
                If ($ShowError){
                    Write-Host ("ERROR: $Message") -ForegroundColor Red
                    Write-Host ('---------- ERROR MESSAGE ----------')
                    $_
                    Write-Host ('-----------------------------------')
                }
                Continue
            }
        }
    }
}

Function UEXAVD_GetPackagesLogFiles {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFilePath, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFolderID)

    if (Test-path -path $LogFilePath) {
        $verfolder = get-ChildItem $LogFilePath -recurse | Foreach-Object {If ($_.psiscontainer) {$_.fullname}} | Select-Object -first 1
        $filepath = $verfolder + "\Status\"

        if (Test-path -path $filepath) {
            Try{
                Copy-Item $filepath "$LogFileLogFolder\$LogFolderID" -Recurse -ErrorAction Continue 2>&1 | Out-Null
            } Catch {
                UEXAVD_LogException ("Error: An exception occurred in UEXAVD_GetPackagesLogFiles $filepath.") -ErrObj $_ $fLogFileOnly
                Continue
            }
        } else {
            UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] '$LogFolderID' log not found."
        }
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] '$LogFilePath' folder not found."
    }
}

Function UEXAVD_GetAVDLogFiles {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFilePath, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFileID)

    $LogFile = $LogFileLogFolder + $env:computername + "_log_" + $LogFileID + ".txt"

    if (Test-path -path "$LogFilePath") {
        Try{
            Copy-Item $LogFilePath $LogFile -ErrorAction Continue 2>&1 | Out-Null
        } Catch {
            UEXAVD_LogException ("Error: An exception occurred in UEXAVD_GetAVDLogFiles $LogFilePath.") -ErrObj $_ $fLogFileOnly
            Continue
        }
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] '$LogFilePath' log not found."
    }
}

Function UEXAVD_GetRegKeys {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegRoot, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegPath, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegFile)

    $RegOut = $RegLogFolder + $env:computername + "_reg_" + $RegFile
    $RegFullPath = $RegRoot + "\" + $RegPath
    $RegTest = $RegRoot + ":\" + $RegPath

    if (Test-path $RegTest) {
        Try{
            reg export $RegFullPath $RegOut | Out-Null
        } Catch {
            UEXAVD_LogException ("Error: An exception occurred in UEXAVD_GetRegKeys $RegFullPath.") -ErrObj $_ $fLogFileOnly
            Continue
        }
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] Registry Key '$RegFullPath' not found."
        Continue
    }
}

Function UEXAVD_GetEventLogs {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$EventSource, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$EventFile)

    $EventOut = $EventLogFolder + $env:computername + "_evt_" + $EventFile
    $CommandLine = "wevtutil epl '$EventSource' $EventOut 2>&1 | Out-Null"

    if (Get-WinEvent -ListLog $EventSource -ErrorAction SilentlyContinue) {
        Try {
            Invoke-Expression $CommandLine
        } Catch {
            UEXAVD_LogException ("Error: An error occurred in $CommandLine") -ErrObj $_ $fLogFileOnly
            Continue
        }
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] Event log '$EventSource' not found."
    }
}

Function UEXAVD_GetRdClientAutoTrace {
    $MSRDCfolder = $env:USERPROFILE + '\AppData\Local\Temp\DiagOutputDir\RdClientAutoTrace\*'

    if (Test-path -path $MSRDCfolder) {
        Try {
            UEXAVD_CreateLogFolder $RDCTraceFolder
        } Catch {
            UEXAVD_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
            Return
        }

        #Getting only traces from over the past 3 days
        (Get-ChildItem $MSRDCfolder).LastWriteTime | ForEach-Object {
            if (([datetime]::Now - $_).Days -le "5") {
                Copy-Item $MSRDCfolder $RDCTraceFolder -Recurse -ErrorAction Continue 2>&1 | Out-Null
            }
        }
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] '$MSRDCfolder' folder not found."
    }
}

function UEXAVD_CloseMSRDC {
    $msrdc = Get-Process msrdc -ErrorAction SilentlyContinue

    if ($msrdc) {
        Write-host "The AVD desktop client (MSRDC) has been detected as running."
        Write-host "To collect the most recent AVD Desktop Client specific ETL traces, MSRDC.exe must be closed first.
        "
        $confirm = Read-Host "Do you want to close the MSRDC.exe now? This will disconnect all outgoing active AVD connections on this client! [Y/N]"
        ""
        if ($confirm.ToLower() -eq "n") {
            UEXAVD_LogMessage $LogLevel.Warning ("MSRDC.exe has not been closed. The most recent ETL traces will NOT be available for troubleshooting! Continuing data collection.")
        } elseif ($confirm.ToLower() -eq "y") {
            UEXAVD_LogMessage $LogLevel.Info "Closing MSRDC.exe ..."
            $msrdc.CloseMainWindow() | Out-Null
            Start-Sleep 5
            if (!$msrdc.HasExited) {
                $msrdc | Stop-Process -Force
            }
            UEXAVD_LogMessage $LogLevel.Info "MSRDC.exe has been closed. Waiting 20 seconds for the latest trace file(s) to get saved before continuing with the data collection."
            Start-Sleep 20
        } else {
            UEXAVD_CloseMSRDC
        }
        ""
    }
}

Function UEXAVD_GetMonTables {
    $MTfolder = 'C:\Windows\System32\config\systemprofile\AppData\Roaming\Microsoft\Monitoring\Tables'

    if (Test-path -path $MTfolder) {
        Try {
            UEXAVD_CreateLogFolder $MonTablesFolder
        } Catch {
            UEXAVD_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
            Return
        }

        Try {
            Switch(Get-ChildItem -Path "C:\Program Files\Microsoft RDInfra\") {
                {$_.Name -match "RDMonitoringAgent"} {
                    $convertpath = "C:\Program Files\Microsoft RDInfra\" + $_.Name + "\Agent\table2csv.exe"
                }
            }
        } Catch {
            UEXAVD_LogException ("ERROR: An error occurred during preparing Monitoring Tables conversion") -ErrObj $_ $fLogFileOnly
            Continue
        }

        Try {
            Switch(Get-ChildItem -Path $MTfolder) {
                {($_.Name -notmatch "00000") -and ($_.Name -match ".tsf")} {
                    $monfile = $MTfolder + "\" + $_.name
                    cmd /c $convertpath -path $MonTablesFolder $monfile 2>&1 | Out-Null
                }
            }
        } Catch {
            UEXAVD_LogException ("ERROR: An error occurred during getting Monitoring Tables data") -ErrObj $_ $fLogFileOnly
            Continue
        }

    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] Monitoring\Tables folder not found."
    }
}

Function UEXAVD_GetWinRMConfig {
    $winrmfile = $SysInfoLogFolder + $LogFilePrefix + "WinRM-Config.txt"

    if ((get-service -name WinRM).status -eq "Running") {
        Try {
            $config = Get-ChildItem WSMan:\localhost\ -Recurse -ErrorAction Continue 2>&1 | Out-Null
            if (!$config) {
                UEXAVD_LogMessage $LogLevel.WarnLogFileOnly ("[$LogPrefix] Cannot connect to localhost, trying with FQDN " + $fqdn)
                Connect-WSMan -ComputerName $fqdn -ErrorAction Continue 2>&1 | Out-Null
                $config = Get-ChildItem WSMan:\$fqdn -Recurse -ErrorAction Continue 2>&1 | Out-Null
                Disconnect-WSMan -ComputerName $fqdn -ErrorAction Continue 2>&1 | Out-Null
            }
            $config | out-file -Append $winrmfile
        } Catch {
            UEXAVD_LogException ("ERROR: An error occurred during getting WinRM configuration") -ErrObj $_ $fLogFileOnly
            Continue
        }

        winrm get winrm/config 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "WinRM-Config.txt")
        winrm e winrm/config/listener 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "WinRM-Config.txt")

    } else {
        UEXAVD_LogMessage $LogLevel.Error ("[$LogPrefix] WinRM service is not running. Skipping collection of WinRM configuration data.")
    }
}

Function UEXAVD_GetFSLogixLogFiles {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFilePath)

    if (Test-path -path "$LogFilePath") {
        Copy-Item $LogFilePath $FSLogixLogFolder -Recurse -ErrorAction Continue 2>&1 | Out-Null
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] '$LogFilePath' folder not found."
    }
}

Function UEXAVD_GetTeamsLogs {
    $TeamsLogPath = $env:userprofile + "\AppData\Roaming\Microsoft\Teams\logs.txt"

    if(Test-Path $TeamsLogPath) {
        Try {
            UEXAVD_CreateLogFolder $TeamsLogFolder
        } Catch {
            UEXAVD_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
            Return
        }

        Copy-Item $TeamsLogPath ($TeamsLogFolder + $LogFilePrefix + "Teams_logs.txt") -ErrorAction Continue 2>&1 | Out-Null
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] Teams logs not found."
    }

    $TeamsDiagFolder = $env:userprofile + "\Downloads\MSTeams*"
    if (Test-path -path $TeamsDiagFolder) {
        if (!(Test-path -path $TeamsLogFolder)) {
            Try {
                UEXAVD_CreateLogFolder $TeamsLogFolder
            } Catch {
                UEXAVD_LogMessage $LogLevel.Error ("Unable to create log folder. " + $_.Exception.Message)
                Return
            }
        }

        Switch(Get-ChildItem -Path $TeamsDiagFolder) {
            {$_.Name -match "MSTeams Diagnostics Log"} {
                $diagfile = $TeamsDiagFolder + "\" + $_.Name
                Copy-Item $diagfile ($TeamsLogFolder + $LogFilePrefix + $_.Name) -ErrorAction Continue 2>&1 | Out-Null
                }
            }
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] Teams Diagnostics logs not found."
    }
}

Function UEXAVD_GetStore($store) {
    $certlist = Get-ChildItem ("Cert:\LocalMachine\" + $store)

    foreach ($cert in $certlist) {
        $EKU = ""
        foreach ($item in $cert.EnhancedKeyUsageList) {
            if ($item.FriendlyName) {
                $EKU += $item.FriendlyName + " / "
            } else {
                $EKU += $item.ObjectId + " / "
            }
        }

        $row = $tbcert.NewRow()

        foreach ($ext in $cert.Extensions) {
            if ($ext.oid.value -eq "2.5.29.14") {
                $row.SubjectKeyIdentifier = $ext.SubjectKeyIdentifier.ToLower()
            }
            if (($ext.oid.value -eq "2.5.29.35") -or ($ext.oid.value -eq "2.5.29.1")) {
                $asn = New-Object Security.Cryptography.AsnEncodedData ($ext.oid,$ext.RawData)
                $aki = $asn.Format($true).ToString().Replace(" ","")
                $aki = (($aki -split '\n')[0]).Replace("KeyID=","").Trim()
                $row.AuthorityKeyIdentifier = $aki
            }
        }

        if ($EKU) {$EKU = $eku.Substring(0, $eku.Length-3)}
        $row.Store = $store
        $row.Thumbprint = $cert.Thumbprint.ToLower()
        $row.Subject = $cert.Subject
        $row.Issuer = $cert.Issuer
        $row.NotAfter = $cert.NotAfter
        $row.EnhancedKeyUsage = $EKU
        $row.SerialNumber = $cert.SerialNumber.ToLower()
        $tbcert.Rows.Add($row)
    }
}


Add-Type -MemberDefinition @"
[DllImport("netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
public static extern uint NetApiBufferFree(IntPtr Buffer);
[DllImport("netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
public static extern int NetGetJoinInformation(
    string server,
    out IntPtr NameBuffer,
    out int BufferType);
"@ -Namespace Win32Api -Name NetApi32

Function UEXAVD_GetNBDomainName {
    $pNameBuffer = [IntPtr]::Zero
    $joinStatus = 0
    $apiResult = [Win32Api.NetApi32]::NetGetJoinInformation(
        $null,               # lpServer
        [Ref] $pNameBuffer,  # lpNameBuffer
        [Ref] $joinStatus    # BufferType
    )
    if ( $apiResult -eq 0 ) {
        [Runtime.InteropServices.Marshal]::PtrToStringAuto($pNameBuffer)
        [Void] [Win32Api.NetApi32]::NetApiBufferFree($pNameBuffer)
    }
}

Function UEXAVD_FileVersion {
    param(
        [string] $FilePath, [bool] $Log = $false
    )

    if (Test-Path -Path $FilePath) {
        $fileobj = Get-item $FilePath
        $filever = $fileobj.VersionInfo.FileMajorPart.ToString() + "." + $fileobj.VersionInfo.FileMinorPart.ToString() + "." + $fileobj.VersionInfo.FileBuildPart.ToString() + "." + $fileobj.VersionInfo.FilePrivatepart.ToString()

        if ($log) {
            ($FilePath + "," + $filever + "," + $fileobj.CreationTime.ToString("yyyyMMdd HH:mm:ss")) 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "ver_KeyFileVersions.csv")
        }
        return $filever | Out-Null
    } else {
        return ""
    }
}

#endregion Internal functions



#region Diag functions

function UEXAVD_TestRegistryValue {
    param ([parameter(Mandatory=$true)][ValidateNotNullOrEmpty()]$Path, [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()]$Value)

    try {
        $trv = Get-ItemProperty -Path $Path -ErrorAction Stop | Select-Object -ExpandProperty $Value -ErrorAction Stop
        if ($trv -or ($trv -eq 0)) {
            return $true
        } else {
            return $false
        }
    }
    catch {
        return $false
    }
}

Function UEXAVD_DiagAVDAgentIssues {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogName, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogID, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$Message)

    $StartTimeA = (Get-Date).AddDays(-5)

    If (!(Get-WinEvent -FilterHashtable @{logname=$LogName; id=$LogID; StartTime=$StartTimeA} -ErrorAction SilentlyContinue | where-object { $_.Message -like '*' + $Message + '*' })) {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] '$Message' event not found."
    } else {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] One or more events $LogID with '$Message' have been found over the past 5 days. See 'AVD-Diag-AgentIssuesEvents.txt' for more information."
        $global:aicounter = $global:aicounter + 1
        Get-WinEvent -FilterHashtable @{logname=$LogName; id=$LogID; StartTime=$StartTimeA} -ErrorAction SilentlyContinue | where-object { $_.Message -like '*' + $Message + '*' } | Format-List | Out-File -Append ($BasicLogFolder + "AVD-Diag-AgentIssuesEvents.txt")
    }
}

Function UEXAVD_DiagMSIXAAIssues {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogName, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogID, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$Message)

    $StartTimeX = (Get-Date).AddDays(-5)

    If (!(Get-WinEvent -FilterHashtable @{logname=$LogName; id=$LogID; StartTime=$StartTimeX} -ErrorAction SilentlyContinue | where-object { $_.Message -like '*' + $Message + '*' })) {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] '$Message' event not found."
    } else {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] One or more events $LogID with '$Message' have been found over the past 5 days. See 'AVD-Diag-MSIXAAIssuesEvents.txt' for more information."
        Get-WinEvent -FilterHashtable @{logname=$LogName; id=$LogID; StartTime=$StartTimeX} -ErrorAction SilentlyContinue | where-object { $_.Message -like '*' + $Message + '*' } | Format-List | Out-File -Append ($BasicLogFolder + "AVD-Diag-MSIXAAIssuesEvents.txt")
    }
}

Function UEXAVD_DiagProcessCrash {
    $StartTimeP = (Get-Date).AddDays(-5)

    If (!(Get-WinEvent -FilterHashtable @{logname="Application"; ProviderName='Application Error'; StartTime=$StartTimeP} -ErrorAction SilentlyContinue | where-object { $_.Message -like '*Faulting application name*' })) {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Application crash events not found."
    } else {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] One or more application crash events have been found over the past 5 days. See 'AVD-Diag-ProcessCrashEvents.txt' for more information."
        Get-WinEvent -FilterHashtable @{logname="Application"; ProviderName='Application Error'; StartTime=$StartTimeP} -ErrorAction SilentlyContinue | Format-List | Out-File -Append ($BasicLogFolder + "AVD-Diag-ProcessCrashEvents.txt")
    }
}

Function UEXAVD_CheckRegKeyValue {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegPath, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegKey, [string]$RegValue)

    $global:regok = $null

    if (UEXAVD_TestRegistryValue -path $RegPath -value $RegKey) {
        (Get-ItemProperty -path $RegPath).PSChildName | foreach-object -process {
            $key = Get-ItemPropertyValue -Path $RegPath -name $RegKey
            if ($RegValue) {
                if ($key -eq $RegValue) {
                    $global:regok = 1
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key '$RegPath$RegKey' exists and has the expected value of: " + $key)
                }
                else {
                    $global:regok = 2
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Registry key '$RegPath$RegKey' exists and has a value of '" + $key + "' but this is not the expected value. (The expected value is: " + $RegValue + ")")
                }
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key '$RegPath$RegKey' exists and has a value of: " + $key)
            }
        }
    } else {
        $global:regok = 0
        UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key '$RegPath$RegKey' not found.")
    }
}

Function UEXAVD_TestAVExclusion {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$ExclPath, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][array]$ExclValue)

    if (Test-Path $ExclPath) {
        if ((Get-Item $ExclPath).Property) {
            $msgpath = Compare-Object -ReferenceObject(@((Get-Item $ExclPath).Property)) -DifferenceObject(@($ExclValue))

            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Comparing local values found with recommended values. False positives may occur if you use full paths instead of environment variables."
            if ($msgpath) {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] '=>' indicates a recommended value that is not configured on this VM."
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] '<=' indicates a configured value that is not part of the list of recommended values."
                $msgpath | Out-File -FilePath $diagfile -Append
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] No differences found."
            }

        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] No Paths exclusions have been found. Follow the above article to configure the recommended exclusions."
        }

    } else {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] '$ExclPath' not found. You should have the recommendations implemented either locally (UI/PowerShell) or through GPO."
    }
}

function UEXAVD_CheckSiteURLStatus {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$URL)

    try {
        $request = Invoke-WebRequest $URL -UseBasicParsing

        if ($request.StatusCode -eq "200") {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] '$URL' is up (Return code: $($request.StatusDescription) - $($request.StatusCode))"
        }
        else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] '$URL' is not accessible."
        }
    } catch {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] '$URL' is not accessible."
    }
}

Function UEXAVD_RequiredURLCheck {
    $toolpath = "C:\Program Files\Microsoft RDInfra\"

    if (!($ver -like "*Windows 7*")) {
        if (Test-Path $toolpath) {
            $toolfolder = Get-ChildItem $toolpath -Directory | Foreach-Object {If (($_.psiscontainer) -and ($_.fullname -like "*RDAgent_*")) { $_.Name }} | Select-Object -Last 1
            $URLCheckToolPath = $toolpath + $toolfolder + "\WVDAgentUrlTool.exe"

            if (Test-Path $URLCheckToolPath) {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] WVDAgentUrlTool found."
                Try{
                    & $URLCheckToolPath | Out-File -Append $DiagFile
                } Catch {
                    UEXAVD_LogException ("Error: An exception occurred in UEXAVD_URLCheckTool.") -ErrObj $_ $fLogFileOnly
                    Continue
                }
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] $toolpath found, but 'WVDAgentUrlTool.exe' is missing, skipping check. You should be running agent version 1.0.2944.1200 or higher."
            }
        } else {
            UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] AVD Agent not found. Skipping check (not applicable)."
        }
    } else {
        UEXAVD_LogDiag $LogLevel.Warning ("[$LogPrefix] Windows 7 detected. Skipping check (not applicable).")
    }
}

#endregion Diag functions


#region Main functions

<#
    .SYNOPSIS
        Collects 'Core' AVD troubleshooting data
    .DESCRIPTION
        CollectUEX_AVDCoreLog (no parameters)
    .NOTES
        Date: 2021.06.14
#>
Function CollectUEX_AVDCoreLog{
    " " | Out-File -Append $OutputLogFile
    UEXAVD_LogMessage $LogLevel.Info "Running data collection - please wait ...`n" -Color "Cyan"

    #Collecting RDS/AVD information
    " " | Out-File -Append $OutputLogFile
    UEXAVD_LogMessage $LogLevel.Info ('Collecting RDS/AVD information')
    Try {
        UEXAVD_CreateLogFolder $LogFileLogFolder
        UEXAVD_CreateLogFolder $NetLogFolder
        UEXAVD_CreateLogFolder $SysInfoLogFolder
    } Catch {
        UEXAVD_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
        Return
    }
    $LogPrefix = "AVD"

    UEXAVD_LogMessage $LogLevel.Normal ("[$LogPrefix] Collecting 'C:\WindowsAzure\Logs\Plugins\*'")
    if (Test-path -path 'C:\WindowsAzure\Logs\Plugins') {
        Copy-Item 'C:\WindowsAzure\Logs\Plugins\*' $LogFileLogFolder -Recurse -ErrorAction Continue 2>>$ErrorLogFile
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] WindowsAzure Plugins logs not found."
    }

    $Commands = @(
        "UEXAVD_GetPackagesLogFiles 'c:\Packages\Plugins\microsoft.powershell.dsc' 'Microsoft.PowerShell.DSC'"
        "UEXAVD_GetPackagesLogFiles 'c:\Packages\Plugins\Microsoft.EnterpriseCloud.Monitoring.MicrosoftMonitoringAgent' 'Microsoft.EnterpriseCloud.Monitoring.MicrosoftMonitoringAgent'"
        "UEXAVD_GetPackagesLogFiles 'c:\Packages\Plugins\Microsoft.Compute.JsonADDomainExtension' 'Microsoft.Compute.JsonADDomainExtension'"
        "UEXAVD_GetAVDLogFiles 'C:\WindowsAzure\Logs\WaAppAgent.log' WaAppAgent"
        "UEXAVD_GetAVDLogFiles 'C:\WindowsAzure\Logs\MonitoringAgent.log' MonitoringAgent"
        "UEXAVD_GetAVDLogFiles 'C:\Windows\debug\NetSetup.LOG' NetSetup"
        "UEXAVD_GetAVDLogFiles 'C:\Users\AgentInstall.txt' AgentInstall_initial"
        "UEXAVD_GetAVDLogFiles 'C:\Users\AgentBootLoaderInstall.txt' AgentBootLoaderInstall_initial"
        "UEXAVD_GetAVDLogFiles 'C:\Program Files\Microsoft RDInfra\AgentInstall.txt' AgentInstall_updates"
        "UEXAVD_GetAVDLogFiles 'C:\Program Files\Microsoft RDInfra\GenevaInstall.txt' GenevaInstall"
        "UEXAVD_GetAVDLogFiles 'C:\Program Files\Microsoft RDInfra\SXSStackInstall.txt' SXSStackInstall"
        "UEXAVD_GetAVDLogFiles 'C:\Windows\Temp\ScriptLog.log' ScriptLog"
        "UEXAVD_GetRdClientAutoTrace"
        "qwinsta /counter 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "qwinsta.txt"
        "dxdiag /whql:off /t " + $SysInfoLogFolder + $LogFilePrefix + "DxDiag.txt"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

    if ($ver -like "*Windows 7*") {
        $Commands = @("UEXAVD_GetAVDLogFiles 'C:\Program Files\Microsoft RDInfra\AVDAgentManagerInstall.txt' AVDAgentManagerInstall")
    } else {
        $Commands = @("dsregcmd /status 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "dsregcmd.txt")
    }
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

    if ([ADSI]::Exists("WinNT://localhost/Remote Desktop Users")) {
        $Commands = @(
            "net localgroup 'Remote Desktop Users' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'Remote Desktop Users' group not found."
    }


    #Collecting <BrokerURI>api/health and <BrokerURIGlobal>api/health status
    UEXAVD_LogMessage $LogLevel.Normal ("[$LogPrefix] Collecting <BrokerURI>api/health and <BrokerURIGlobal>api/health status")
    $brokerURIregpath = "HKLM:\SOFTWARE\Microsoft\RDInfraAgent\"
    
    #Extra for Windows 7
    if ($ver -like "*Windows 7*") {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    }

    $brokerout = $NetLogFolder + $LogFilePrefix + "BrokerURIHealth.txt"
    $brokerURIregkey = "BrokerURI"
        if (UEXAVD_TestRegistryValue -path $brokerURIregpath -value $brokerURIregkey) {
            $brokerURI = Get-ItemPropertyValue -Path $brokerURIregpath -name $brokerURIregkey
            $brokerURI = $brokerURI + "api/health"
            "$brokerURI" | Out-File -Append $brokerout
            Invoke-WebRequest $brokerURI -UseBasicParsing | Out-File -Append $brokerout
        } else {
            UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] Registry key '$brokerURIregpath$brokerURIregkey' not found."
        }

    $brokerURIGlobalregkey = "BrokerURIGlobal"
        if (UEXAVD_TestRegistryValue -path $brokerURIregpath -value $brokerURIGlobalregkey) {
            $brokerURIGlobal = Get-ItemPropertyValue -Path $brokerURIregpath -name $brokerURIGlobalregkey
            $brokerURIGlobal = $brokerURIGlobal + "api/health"
            "$brokerURIGlobal" | Out-File -Append $brokerout
            Invoke-WebRequest $brokerURIGlobal -UseBasicParsing | Out-File -Append $brokerout
        } else {
            UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] Registry key '$brokerURIregpath$brokerURIGlobalregkey' not found."
        }


    #Collecting Geneva Monitoring information
    " " | Out-File -Append $OutputLogFile
    UEXAVD_LogMessage $LogLevel.Info ('Collecting Geneva Monitoring information')

    if (!($ver -like "*Windows 7*")) {
        Try {
            UEXAVD_CreateLogFolder $GenevaLogFolder
        } Catch {
            UEXAVD_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
            Return
        }

        Try {
            UEXAVD_LogMessage $LogLevel.Normal ('[$LogPrefix] Collecting Azure Instance Metadata Service (IMDS) endpoint accessibility information')
            $request = [System.Net.WebRequest]::Create("http://169.254.169.254/metadata/instance/network?api-version=2020-06-01")
            $request.Proxy = [System.Net.WebProxy]::new()
            $request.Headers.Add("Metadata","True")
            $request.GetResponse() | Out-File -Append ($GenevaLogFolder + $LogFilePrefix + "IMDSRequestInfo.txt")
        } Catch {
            UEXAVD_LogException ("Error: An error occurred in $request") -ErrObj $_ $fLogFileOnly
        }

        if (Get-ScheduledTask GenevaTask* -ErrorAction Ignore) {
            (Get-ScheduledTask GenevaTask*).TaskName | ForEach-Object -Process {
                $Commands = @(
                    "Export-ScheduledTask -TaskName $_ 2>&1 | Out-File -Append " + $GenevaLogFolder + $LogFilePrefix + "schtasks_" + $_ + ".xml"
                    "Get-ScheduledTaskInfo -TaskName $_ 2>&1 | Out-File -Append " + $GenevaLogFolder + $LogFilePrefix + "schtasks_" + $_ + "_Info.txt"
                )
                UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
            }
        } else {
            UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] Geneva Scheduled Task not found."
        }
    }

    $Commands = @(
        "UEXAVD_GetMonTables"
        "cmd /c set mon 2>&1 | Out-File -Append " + $GenevaLogFolder + $LogFilePrefix + "setMON.txt"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True


    #Collecting event logs
    " " | Out-File -Append $OutputLogFile
    UEXAVD_LogMessage $LogLevel.Info ('Collecting event log information')
    Try {
        UEXAVD_CreateLogFolder $EventLogFolder
    } Catch {
        UEXAVD_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
        Return
    }
    $LogPrefix = "EventLog"
    $Commands = @(
        "UEXAVD_GetEventLogs 'System' 'System.evtx'"
        "UEXAVD_GetEventLogs 'Application' 'Application.evtx'"
        "UEXAVD_GetEventLogs 'Security' 'Security.evtx'"
        "UEXAVD_GetEventLogs 'RemoteDesktopServices' 'RemoteDesktopServices.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-WindowsAzure-Diagnostics/Bootstrapper' 'WindowsAzure-Diag-Bootstrapper.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-WindowsAzure-Diagnostics/GuestAgent' 'WindowsAzure-Diag-GuestAgent.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-WindowsAzure-Diagnostics/Heartbeat' 'WindowsAzure-Diag-Heartbeat.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-WindowsAzure-Diagnostics/Runtime' 'WindowsAzure-Diag-Runtime.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-WindowsAzure-Status/GuestAgent' 'WindowsAzure-Status-GuestAgent.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-WindowsAzure-Status/Plugins' 'WindowsAzure-Status-Plugins.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-CAPI2/Operational' 'CAPI2-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-DSC/Operational' 'DSC-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-WinRM/Operational' 'WinRM-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-PowerShell/Operational' 'PowerShell-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-RemoteDesktopServices-RdpCoreTS/Operational' 'RemoteDesktopServicesRdpCoreTS-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-RemoteDesktopServices-RdpCoreTS/Admin' 'RemoteDesktopServicesRdpCoreTS-Admin.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-RemoteDesktopServices-RdpCoreCDV/Admin' 'RemoteDesktopServicesRdpCoreCDV-Admin.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-RemoteDesktopServices-RdpCoreCDV/Operational' 'RemoteDesktopServicesRdpCoreCDV-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-TaskScheduler/Operational' 'TaskScheduler-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-TerminalServices-LocalSessionManager/Operational' 'TerminalServicesLocalSessionManager-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-TerminalServices-LocalSessionManager/Admin' 'TerminalServicesLocalSessionManager-Admin.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-TerminalServices-RemoteConnectionManager/Admin' 'TerminalServicesRemoteConnectionManager-Admin.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational' 'TerminalServicesRemoteConnectionManager-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-TerminalServices-PnPDevices/Admin' 'TerminalServicesPnPDevices-Admin.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-TerminalServices-PnPDevices/Operational' 'TerminalServicesPnPDevices-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-WinINet-Config/ProxyConfigChanged' 'WinHttp-ProxyConfigChanged.evtx'"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True


    #Collecting registry keys
    " " | Out-File -Append $OutputLogFile
    UEXAVD_LogMessage $LogLevel.Info ('Collecting registry key information')
    Try {
        UEXAVD_CreateLogFolder $RegLogFolder
    } Catch {
        UEXAVD_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
        Return
    }
    $LogPrefix = "Reg"
    $Commands = @(
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Azure\DSC' 'SW-MS-Azure-DSC.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\MSRDC\Policies' 'SW-MS-MSRDC-Policies.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\NET Framework Setup\NDP' 'SW-MS-NetFS-NDP.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\RDMonitoringAgent' 'SW-MS-RDMonitoringAgent.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\RDInfraAgent' 'SW-MS-RDInfraAgent.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Terminal Server Client' 'SW-MS-TerminalServerClient.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows\CurrentVersion\Policies' 'SW-MS-Win-CV-Policies.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows\CurrentVersion\Run' 'SW-MS-Win-CV-Run.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Terminal Server' 'SW-MS-WinNT-CV-TerminalServer.txt'"

        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\Cryptography' 'SW-Policies-MS-Cryptography.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation' 'SW-Policies-MS-Win-CredentialsDelegation.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' 'SW-Policies-MS-WinNT-TerminalServices.txt'"

        "UEXAVD_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\Cryptography' 'Sys-CCS-Control-Cryptography.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\Lsa' 'Sys-CCS-Control-LSA.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\SecurityProviders' 'Sys-CCS-Control-SecurityProviders.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\Terminal Server' 'Sys-CCS-Control-TerminalServer.txt'"

        "UEXAVD_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\RdAgent' 'Sys-CCS-Svc-RdAgent.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\TermService' 'Sys-CCS-Svc-TermService.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\UmRdpService' 'Sys-CCS-Svc-UmRdpService.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\WinRM' 'Sys-CCS-Svc-WinRM.txt'"

        "UEXAVD_GetRegKeys 'HKCU' 'SOFTWARE\Microsoft\RdClientRadc' 'SW-MS-RdClientRadc.txt'"
        "UEXAVD_GetRegKeys 'HKCU' 'SOFTWARE\Microsoft\Remote Desktop' 'SW-MS-RemoteDesktop.txt'"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

    if (!($ver -like "*Windows 7*")) {
    $Commands = @(
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\RDAgentBootLoader' 'SW-MS-RDAgentBootLoader.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\RDAgentBootLoader' 'Sys-CCS-Svc-RDAgentBootLoader.txt'"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        $Commands = @(
            "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\AVDAgentManager' 'SW-MS-AVDAgentManager.txt'"
            "UEXAVD_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\AVDAgent' 'Sys-CCS-Svc-AVDAgent.txt'"
            "UEXAVD_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\AVDAgentManager' 'Sys-CCS-Svc-AVDAgentManager.txt'"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    }


    #Collecting RDP and Net info
    " " | Out-File -Append $OutputLogFile
    UEXAVD_LogMessage $LogLevel.Info ('Collecting networking information')

    $LogPrefix = "Net"
    if (!($ver -like "*Windows 7*")) {
        $Commands = @(
            "Get-NetConnectionProfile | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "NetConnectionProfile.txt"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    }

    $Commands = @(
        "netsh advfirewall firewall show rule name=all 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "FirewallRules.txt"
        "netstat -anob 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "Netstat.txt"
        "ipconfig /all 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "Ipconfig.txt"
        "netsh winhttp show proxy 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "WinHTTP-Proxy.txt"
        "nslookup wpad 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "WinHTTP-Proxy.txt"
        "nslookup rdweb.AVD.microsoft.com 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "WinHTTP-Proxy.txt"
        "route print 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "Route.txt"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True


    #Collecting system information
    " " | Out-File -Append $OutputLogFile
    UEXAVD_LogMessage $LogLevel.Info ('Collecting system information')
    $LogPrefix = "System"

    UEXAVD_LogMessage $LogLevel.Normal "[$LogPrefix] Collecting details about currently running processes"
    $proc = Get-CimInstance -Namespace "root\cimv2" -Query "select Name, CreationDate, ProcessId, ParentProcessId, WorkingSetSize, UserModeTime, KernelModeTime, ThreadCount, HandleCount, CommandLine, ExecutablePath from Win32_Process" -ErrorAction Continue 2>>$ErrorLogFile
    if ($PSVersionTable.psversion.ToString() -ge "3.0") {
        $StartTime= @{e={$_.CreationDate.ToString("yyyyMMdd HH:mm:ss")};n="Start time"}
    } else {
        $StartTime= @{n='StartTime';e={$_.ConvertToDateTime($_.CreationDate)}}
    }

    if ($proc) {
        $proc | Sort-Object Name | Format-Table -AutoSize -property @{e={$_.ProcessId};Label="PID"}, @{e={$_.ParentProcessId};n="Parent"}, Name,
        @{N="WorkingSet";E={"{0:N0}" -f ($_.WorkingSetSize/1kb)};a="right"},
        @{e={[DateTime]::FromFileTimeUtc($_.UserModeTime).ToString("HH:mm:ss")};n="UserTime"}, @{e={[DateTime]::FromFileTimeUtc($_.KernelModeTime).ToString("HH:mm:ss")};n="KernelTime"},
        @{N="Threads";E={$_.ThreadCount}}, @{N="Handles";E={($_.HandleCount)}}, $StartTime, CommandLine | Out-String -Width 500 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "RunningProcesses.txt")

        UEXAVD_LogMessage $LogLevel.Normal "[$LogPrefix] Collecting file version of running and key system binaries"
        $binlist = $proc | Group-Object -Property ExecutablePath
        foreach ($file in $binlist) {
            if ($file.Name) {
                UEXAVD_FileVersion -Filepath ($file.name) -Log $true 2>&1 | Out-Null
            }
        }

        $pad = 27
        $OS = Get-CimInstance -Namespace "root\cimv2" -Query "select Caption, CSName, OSArchitecture, BuildNumber, InstallDate, LastBootUpTime, LocalDateTime, TotalVisibleMemorySize, FreePhysicalMemory, SizeStoredInPagingFiles, FreeSpaceInPagingFiles from Win32_OperatingSystem" -ErrorAction Continue 2>>$ErrorLogFile
        $CS = Get-CimInstance -Namespace "root\cimv2" -Query "select Model, Manufacturer, SystemType, NumberOfProcessors, NumberOfLogicalProcessors, TotalPhysicalMemory, DNSHostName, Domain, DomainRole from Win32_ComputerSystem" -ErrorAction Continue 2>>$ErrorLogFile
        $BIOS = Get-CimInstance -Namespace "root\cimv2" -query "select BIOSVersion, Manufacturer, ReleaseDate, SMBIOSBIOSVersion from Win32_BIOS" -ErrorAction Continue 2>>$ErrorLogFile
        $TZ = Get-CimInstance -Namespace "root\cimv2" -Query "select Description from Win32_TimeZone" -ErrorAction Continue 2>>$ErrorLogFile
        $PR = Get-CimInstance -Namespace "root\cimv2" -Query "select Name, Caption from Win32_Processor" -ErrorAction Continue 2>>$ErrorLogFile

        $ctr = Get-Counter -Counter "\Memory\Pool Paged Bytes" -ErrorAction Continue 2>>$ErrorLogFile
        $PoolPaged = $ctr.CounterSamples[0].CookedValue
        $ctr = Get-Counter -Counter "\Memory\Pool Nonpaged Bytes" -ErrorAction Continue 2>>$ErrorLogFile
        $PoolNonPaged = $ctr.CounterSamples[0].CookedValue

        "Computer name".PadRight($pad) + " : " + $OS.CSName 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Model".PadRight($pad) + " : " + $CS.Model 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Manufacturer".PadRight($pad) + " : " + $CS.Manufacturer 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "BIOS Version".PadRight($pad) + " : " + $BIOS.BIOSVersion 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "BIOS Manufacturer".PadRight($pad) + " : " + $BIOS.Manufacturer 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "BIOS Release date".PadRight($pad) + " : " + $BIOS.ReleaseDate 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "SMBIOS Version".PadRight($pad) + " : " + $BIOS.SMBIOSBIOSVersion 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "SystemType".PadRight($pad) + " : " + $CS.SystemType 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Processor".PadRight($pad) + " : " + $PR.Name + " / " + $PR.Caption 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Processors physical/logical".PadRight($pad) + " : " + $CS.NumberOfProcessors + " / " + $CS.NumberOfLogicalProcessors 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Memory physical/visible".PadRight($pad) + " : " + ("{0:N0}" -f ($CS.TotalPhysicalMemory/1mb)) + " MB / " + ("{0:N0}" -f ($OS.TotalVisibleMemorySize/1kb)) + " MB" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Pool Paged / NonPaged".PadRight($pad) + " : " + ("{0:N0}" -f ($PoolPaged/1mb)) + " MB / " + ("{0:N0}" -f ($PoolNonPaged/1mb)) + " MB" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Free physical memory".PadRight($pad) + " : " + ("{0:N0}" -f ($OS.FreePhysicalMemory/1kb)) + " MB" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Paging files size / free".PadRight($pad) + " : " + ("{0:N0}" -f ($OS.SizeStoredInPagingFiles/1kb)) + " MB / " + ("{0:N0}" -f ($OS.FreeSpaceInPagingFiles/1kb)) + " MB" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Operating System".PadRight($pad) + " : " + $OS.Caption + " " + $OS.OSArchitecture 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")

        [string]$WinVerBuild = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentBuild).CurrentBuild
        [string]$WinVerRevision = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' UBR).UBR

        if (!($ver -like "*Windows 7*")) {
            [string]$WinVerMajor = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentMajorVersionNumber).CurrentMajorVersionNumber
            [string]$WinVerMinor = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentMinorVersionNumber).CurrentMinorVersionNumber
            "Build Number".PadRight($pad) + " : " + $WinVerMajor + "." + $WiNVerMinor + "." + $WinVerBuild + "." + $WinVerRevision 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        } else {
            "Build Number".PadRight($pad) + " : " + $WinVerBuild + "." + $WinVerRevision 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        }

        "Installation type".PadRight($pad) + " : " + (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").InstallationType 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Time zone".PadRight($pad) + " : " + $TZ.Description 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Install date".PadRight($pad) + " : " + $OS.InstallDate 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Last boot time".PadRight($pad) + " : " + $OS.LastBootUpTime 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Local time".PadRight($pad) + " : " + $OS.LocalDateTime 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "DNS Hostname".PadRight($pad) + " : " + $CS.DNSHostName 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "DNS Domain name".PadRight($pad) + " : " + $CS.Domain 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "NetBIOS Domain name".PadRight($pad) + " : " + (UEXAVD_GetNBDomainName) 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        $roles = "Standalone Workstation", "Member Workstation", "Standalone Server", "Member Server", "Backup Domain Controller", "Primary Domain Controller"
        "Domain role".PadRight($pad) + " : " + $roles[$CS.DomainRole] 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")

        " " | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")

        $drives = @()
        $drvtype = "Unknown", "No Root Directory", "Removable Disk", "Local Disk", "Network Drive", "Compact Disc", "RAM Disk"
        $Vol = Get-CimInstance -NameSpace "root\cimv2" -Query "select * from Win32_LogicalDisk" -ErrorAction Continue 2>>$ErrorLogFile
        foreach ($disk in $vol) {
                $drv = New-Object PSCustomObject
                $drv | Add-Member -type NoteProperty -name Letter -value $disk.DeviceID
                $drv | Add-Member -type NoteProperty -name DriveType -value $drvtype[$disk.DriveType]
                $drv | Add-Member -type NoteProperty -name VolumeName -value $disk.VolumeName
                $drv | Add-Member -type NoteProperty -Name TotalMB -Value ($disk.size)
                $drv | Add-Member -type NoteProperty -Name FreeMB -value ($disk.FreeSpace)
                $drives += $drv
            }
        $drives | Format-Table -AutoSize -property Letter, DriveType, VolumeName, @{N="TotalMB";E={"{0:N0}" -f ($_.TotalMB/1MB)};a="right"}, @{N="FreeMB";E={"{0:N0}" -f ($_.FreeMB/1MB)};a="right"} 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
    } else {
        $proc = Get-Process | Where-Object {$_.Name -ne "Idle"}
        $proc | Format-Table -AutoSize -property id, name, @{N="WorkingSet";E={"{0:N0}" -f ($_.workingset/1kb)};a="right"},
        @{N="VM Size";E={"{0:N0}" -f ($_.VirtualMemorySize/1kb)};a="right"},
        @{N="Proc time";E={($_.TotalProcessorTime.ToString().substring(0,8))}}, @{N="Threads";E={$_.threads.count}},
        @{N="Handles";E={($_.HandleCount)}}, StartTime, Path | Out-String -Width 300 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "RunningProcesses.txt")
    }

    $Commands = @(
        "Get-DscConfigurationStatus -all 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "Get-DscConfiguration.txt"
        "gpresult /h " + $SysInfoLogFolder + $LogFilePrefix + "Gpresult.html" + " 2>&1 | Out-Null"
        "gpresult /r /z 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "Gpresult-rz.txt"
        "Get-HotFix -ErrorAction SilentlyContinue | Sort-Object -Property InstalledOn -Descending -ErrorAction SilentlyContinue 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "Hotfixes.txt"
        "(Get-Item -Path 'C:\Windows\System32\*.dll').VersionInfo | Format-List -Force 2>&1 | Out-File " + $SysInfoLogFolder + $LogFilePrefix + "ver_System32_DLL.txt"
        "(Get-Item -Path 'C:\Windows\System32\*.exe').VersionInfo | Format-List -Force 2>&1 | Out-File " + $SysInfoLogFolder + $LogFilePrefix + "ver_System32_EXE.txt"
        "(Get-Item -Path 'C:\Windows\System32\*.sys').VersionInfo | Format-List -Force 2>&1 | Out-File " + $SysInfoLogFolder + $LogFilePrefix + "ver_System32_SYS.txt"
        "(Get-Item -Path 'C:\Windows\System32\drivers\*.sys').VersionInfo | Format-List -Force 2>&1 | Out-File " + $SysInfoLogFolder + $LogFilePrefix + "ver_Drivers.txt"
        "msinfo32 /nfo " + $SysInfoLogFolder + $LogFilePrefix + "msinfo32.nfo" + " 2>&1 | Out-Null"
        "fltmc filters 2>&1 | Out-File " + $SysInfoLogFolder + $LogFilePrefix + "Fltmc.txt"
        "UEXAVD_GetWinRMConfig"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

    UEXAVD_LogMessage $LogLevel.Normal "[$LogPrefix] Collecting PowerShell and .Net version information"
    "PowerShell Information:" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
    $PSVersionTable | Format-Table Name, Value 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
    ".Net Framework Information:" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
    Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP' -Recurse | Get-ItemProperty -Name version -EA 0 | Where-Object { $_.PSChildName -Match '^(?!S)\p{L}'} | Select-Object PSChildName, version 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")

    UEXAVD_LogMessage $LogLevel.Normal "[$LogPrefix] Collecting service details"
    $svc = Get-CimInstance -NameSpace "root\cimv2" -Query "select  ProcessId, DisplayName, StartMode,State, Name, PathName, StartName from Win32_Service" -ErrorAction Continue
    if ($svc) {
        $svc | Sort-Object DisplayName | Format-Table -AutoSize -Property ProcessId, DisplayName, StartMode,State, Name, PathName, StartName | Out-String -Width 400 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "Services.txt")
    }

    $LogPrefix = "Cert"
    UEXAVD_LogMessage $LogLevel.Info "[$LogPrefix] Collecting certificates information"
    Try {
        UEXAVD_CreateLogFolder $CertLogFolder
    } Catch {
        UEXAVD_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
        Return
    }
    $Commands = @(
        "certutil -verifystore -v MY 2>&1 | Out-File -Append " + $CertLogFolder + $LogFilePrefix + "Certificates-My.txt"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

    UEXAVD_LogMessage $LogLevel.Normal "[$LogPrefix] Exporting additional certificates information"
    $tbCert = New-Object system.Data.DataTable
    $col = New-Object system.Data.DataColumn Store,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn Thumbprint,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn Subject,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn Issuer,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn NotAfter,([DateTime]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn IssuerThumbprint,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn EnhancedKeyUsage,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn SerialNumber,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn SubjectKeyIdentifier,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn AuthorityKeyIdentifier,([string]); $tbCert.Columns.Add($col)
    UEXAVD_GetStore "My"
    $aCert = $tbCert.Select("Store = 'My' ")
    foreach ($cert in $aCert) {
        $aIssuer = $tbCert.Select("SubjectKeyIdentifier = '" + ($cert.AuthorityKeyIdentifier).tostring() + "'")
        if ($aIssuer.Count -gt 0) {
        $cert.IssuerThumbprint = ($aIssuer[0].Thumbprint).ToString()
        }
    }
    $tbcert | Export-Csv ($CertLogFolder + $LogFilePrefix + "Certificates.csv") -noType -Delimiter "`t"
}


<#
    .SYNOPSIS
        Collects Profiles specific AVD troubleshooting data
    .DESCRIPTION
        CollectUEX_AVDProfilesLog (no parameters)
    .NOTES
        Date: 2021.06.14
#>
Function CollectUEX_AVDProfilesLog{
    " " | Out-File -Append $OutputLogFile
    UEXAVD_LogMessage $LogLevel.Info ('Collecting Profiles information (incl. FSLogix if present)')

    $LogPrefix = "Profiles"
    if (Test-path -path 'C:\Program Files\FSLogix') {

        Try {
            UEXAVD_CreateLogFolder $FSLogixLogFolder
        } Catch {
            UEXAVD_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
            Return
        }


        #Collecting FSLogix Logs
        $Commands = @(
            "UEXAVD_GetFSLogixLogFiles 'C:\ProgramData\FSLogix\Logs\*'"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

        $cmd = "c:\program files\fslogix\apps\frx.exe"

        if (Test-path -path 'C:\Program Files\FSLogix\apps') {
            UEXAVD_LogMessage $LogLevel.Normal ("[$LogPrefix] Running frx.exe version")
            Invoke-Expression "& '$cmd' + 'version'" | Out-File -FilePath ($FSLogixLogFolder + $LogFilePrefix + 'frx-list.txt') -Append

            "`n====================================================================================`n" | Out-File -FilePath ($FSLogixLogFolder + $LogFilePrefix + 'Frx-list.txt') -Append

            UEXAVD_LogMessage $LogLevel.Normal ("[$LogPrefix] Running frx.exe list-redirects")
            Invoke-Expression "& '$cmd' + 'list-redirects'" | Out-File -FilePath ($FSLogixLogFolder + $LogFilePrefix + 'frx-list.txt') -Append

            "`n====================================================================================`n" | Out-File -FilePath ($FSLogixLogFolder + $LogFilePrefix + 'Frx-list.txt') -Append

            UEXAVD_LogMessage $LogLevel.Normal ("[$LogPrefix] Running frx.exe list-rules")
            Invoke-Expression "& '$cmd' + 'list-rules'" | Out-File -FilePath ($FSLogixLogFolder + $LogFilePrefix + 'frx-list.txt') -Append
        } else {
            UEXAVD_LogMessage $LogLevel.WarnLogFileOnly ("[$LogPrefix] 'C:\Program Files\FSLogix\apps' folder not found.")
        }

        $Commands = @(
            "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\FSLogix' 'SW-FSLogix.txt'"
            "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Policies\FSLogix' 'SW-Policies-FSLogix.txt'"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly ("[$LogPrefix] 'C:\Program Files\FSLogix' folder not found.")
    }


    #Collecting profile registry keys
    $LogPrefix = "Reg"
    $Commands = @(
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows Defender\Exclusions\Extensions' 'SW-MS-WinDef-Excl-Extensions.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths' 'SW-MS-WinDef-Excl-Paths.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes' 'SW-MS-WinDef-Excl-Processes.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Extensions' 'SW-GPO-MS-WinDef-Excl-Extensions.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Paths' 'SW-GPO-MS-WinDef-Excl-Paths.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Processes' 'SW-GPO-MS-WinDef-Excl-Processes.txt'"
        "UEXAVD_GetRegKeys 'HKCU' 'SOFTWARE\Microsoft\Office' 'SW-MS-Office.txt'"
        "UEXAVD_GetRegKeys 'HKCU' 'Software\Policies\Microsoft\office' 'SW-Policies-MS-Office.txt'"
        "UEXAVD_GetRegKeys 'HKCU' 'SOFTWARE\Microsoft\OneDrive' 'HKCU_SW-MS-OneDrive.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\OneDrive' 'HKLM_SW-MS-OneDrive.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\OneDrive' 'HKLM_SW-Pol-MS-OneDrive.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows Search' 'SW-MS-WindowsSearch.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList' 'SW-MS-WinNT-CV-ProfileList.txt'"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True


    #Collecting profiles event logs
    $LogPrefix = "EventLog"
    $Commands = @(
        "UEXAVD_GetEventLogs 'Microsoft-Windows-User Profile Service/Operational' 'UserProfileService-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-VHDMP-Operational' 'VHDMP-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-SMBClient/Operational' 'SMBClient-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-SMBClient/Connectivity' 'SMBClient-Connectivity.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-SMBClient/Security' 'SMBClient-Security.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-SMBServer/Operational' 'SMBServer-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-SMBServer/Connectivity' 'SMBServer-Connectivity.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-SMBServer/Security' 'SMBServer-Security.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-FSLogix-Apps/Admin' 'FSLogix-Apps-Admin.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-FSLogix-Apps/Operational' 'FSLogix-Apps-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-FSLogix-CloudCache/Admin' 'FSLogix-CloudCache-Admin.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-FSLogix-CloudCache/Operational' 'FSLogix-CloudCache-Operational.evtx'"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True


    #Collecting FSLogix group memberships
    if ([ADSI]::Exists("WinNT://localhost/FSLogix ODFC Exclude List")) {
        $Commands = @(
            "net localgroup 'FSLogix ODFC Exclude List' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'FSLogix ODFC Exclude List' group not found."
    }

    if ([ADSI]::Exists("WinNT://localhost/FSLogix ODFC Include List")) {
        $Commands = @(
            "net localgroup 'FSLogix ODFC Include List' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'FSLogix ODFC Include List' group not found."
    }

    if ([ADSI]::Exists("WinNT://localhost/FSLogix Profile Exclude List")) {
        $Commands = @(
            "net localgroup 'FSLogix Profile Exclude List' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'FSLogix Profile Exclude List' group not found."
    }

    if ([ADSI]::Exists("WinNT://localhost/FSLogix Profile Include List")) {
        $Commands = @(
            "net localgroup 'FSLogix Profile Include List' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'FSLogix Profile Include List' group not found."
    }
}


<#
    .SYNOPSIS
        Collects MSIX App Attach related data (AppXDeployment)
    .DESCRIPTION
        CollectUEX_AVDMSIXAALog (no parameters)
    .NOTES
        Date: 2021.06.14
#>
Function CollectUEX_AVDMSIXAALog{
    $LogPrefix = "MSIXAA"
    " " | Out-File -Append $OutputLogFile
    UEXAVD_LogMessage $LogLevel.Info ('Collecting MSIX App Attach data')

    $Commands = @(
        "UEXAVD_GetEventLogs 'Microsoft-Windows-AppXDeploymentServer/Operational' 'AppXDeploymentServer-Operational.evtx'"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

    UEXAVD_LogMessage $LogLevel.Normal "[$LogPrefix] Collecting MSIXAA filtered RemoteDesktopServices event logs"
    $eventlog = "RemoteDesktopServices"
    $msixaalog = $EventLogFolder + $env:computername + "_evt_MSIXAA_filtered.evtx"

    if (Get-WinEvent -ListLog $eventlog -ErrorAction SilentlyContinue) {
        Try {
            wevtutil epl $eventlog $msixaalog "/q:*[System [Provider[@Name='Microsoft.RDInfra.AppAttach.AppAttachServiceImpl' or '@Name=Microsoft.RDInfra.AppAttach.SysNtfyServiceImpl' or @Name='Microsoft.RDInfra.AppAttach.UserImpersonationServiceImpl' or @Name='Microsoft.RDInfra.RDAgent.AppAttach.CimVolume' or @Name='Microsoft.RDInfra.RDAgent.AppAttach.ImagedMsixExtractor' or @Name='Microsoft.RDInfra.RDAgent.AppAttach.MsixProcessor' or @Name='Microsoft.RDInfra.RDAgent.AppAttach.VhdVolume' or @Name='Microsoft.RDInfra.RDAgent.AppAttach.VirtualDiskManager' or @Name='Microsoft.RDInfra.RDAgent.Service.AppAttachHealthCheck']]]"
        } Catch {
            UEXAVD_LogException "Error: An error occurred while exporting the MSIXAA logs" -ErrObj $_ $fLogFileOnly
            Continue
        }
    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] Event log '$eventlog' not found."
    }
}


<#
    .SYNOPSIS
        Collects Microsoft Teams specific AVD troubleshooting data
    .DESCRIPTION
        CollectUEX_AVDTeamsLog (no parameters)
    .NOTES
        Date: 2021.06.14
#>
Function CollectUEX_AVDTeamsLog{
    $LogPrefix = "Teams"
    " " | Out-File -Append $OutputLogFile
    UEXAVD_LogMessage $LogLevel.Info ('Collecting information on Teams and AVD media optimization for Teams')

    $Commands = @(
        "UEXAVD_GetTeamsLogs"
        "UEXAVD_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Teams' 'SW-MS-Teams.txt'"
        "UEXAVD_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\RDWebRTCSvc' 'Sys-CCS-Svc-RDWebRTCSvc.txt'"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
}


<#
    .SYNOPSIS
        Collects Microsoft Remote Assistance specific AVD troubleshooting data
    .DESCRIPTION
        CollectUEX_AVDMSRALog (no parameters)
    .NOTES
        Date: 2021.06.14
#>
Function CollectUEX_AVDMSRALog{
    $LogPrefix = "MSRA"
    " " | Out-File -Append $OutputLogFile
    UEXAVD_LogMessage $LogLevel.Info ('Collecting Remote Assistance information')

    if ([ADSI]::Exists("WinNT://localhost/Offer Remote Assistance Helpers")) {
        $Commands = @(
            "net localgroup 'Offer Remote Assistance Helpers' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

        if ([ADSI]::Exists("WinNT://localhost/Distributed COM Users")) {
            $Commands = @(
                "net localgroup 'Distributed COM Users' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
            )
            UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
        } else {
            UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'Distributed COM Users' group not found."
        }

    } else {
        UEXAVD_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'Offer Remote Assistance Helpers' group not found."
    }

    $Commands = @(
        "UEXAVD_GetEventLogs 'Microsoft-Windows-RemoteAssistance/Operational' 'RemoteAssistance-Operational.evtx'"
        "UEXAVD_GetEventLogs 'Microsoft-Windows-RemoteAssistance/Admin' 'RemoteAssistance-Admin.evtx'"
        "UEXAVD_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\Remote Assistance' 'Sys-CCS-Control-MSRA.txt'"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
}


<#
    .SYNOPSIS
        Runs AVD Diagnostics
    .DESCRIPTION
        RunUEX_AVDDiag (no parameters)
    .NOTES
        Date: 2021.06.14
#>
Function RunUEX_AVDDiag {
    $LogPrefix = "Diag"
    ""
    " " | Out-File -Append $OutputLogFile
    if (!$DiagOnly) {
        UEXAVD_LogMessage $LogLevel.Info "Data collection complete - running diagnostics - please wait ...`n" -Color "Cyan"
    } else {
        UEXAVD_LogMessage $LogLevel.Info "Running diagnostics - please wait ...`n" -Color "Cyan"
    }
    " " | Out-File -Append $OutputLogFile

    $DiagFile = $BasicLogFolder + "AVD-Diag.txt"

    "`nThis report is intended to help you get a better overview of the system, identify known issues and ease overall troubleshooting. Depending on the issue you are investigating, additional data collection and analysis may be required." | Out-File -Append $diagfile
    "======================================================================`n" | Out-File -Append $diagfile


###core

#region Brief deployment info
    "Core Diagnostics" | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking system/deployment"
    " " | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FQDN: " + $fqdn)

    if (($ver -like "*Pro*") -or ($ver -like "*Enterprise N*") -or ($ver -like "*LTSB*") -or ($ver -like "*LTSC*") -or ($ver -like "*Enterprise KN*")) {
        UEXAVD_LogDiag $LogLevel.Warning ("[$LogPrefix] [WARNING] OS: " + $ver + ". If this machine is a AVD host VM, then this OS is not supported to be run inside AVD. See the list of supported virtual machine OS images for AVD: https://docs.microsoft.com/en-us/azure/virtual-desktop/overview#supported-virtual-machine-os-images")
    } else {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] OS: " + $ver)
    }

    [string]$WinVerBuild = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentBuild).CurrentBuild
    [string]$WinVerRevision = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' UBR).UBR

    if (!($ver -like "*Windows 7*")) {
        [string]$WinVerMajor = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentMajorVersionNumber).CurrentMajorVersionNumber
        [string]$WiNVerMinor = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentMinorVersionNumber).CurrentMinorVersionNumber
        UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] OS Build: " + $WinVerMajor + "." + $WiNVerMinor + "." + $WinVerBuild + "." + $WinVerRevision)
    } else {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] OS Build: " + $WinVerBuild + "." + $WinVerRevision)
    }


    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\RDMonitoringAgent') {
        if (UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\Microsoft\RDMonitoringAgent" -value "SessionHostPool") {
            $hp = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Microsoft\RDMonitoringAgent" -name "SessionHostPool"
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Machine is part of AVD host pool: " + $hp)
        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] 'RDMonitoringAgent' registry key found, but this machine is not part of a AVD host pool. It might have host pool registration issues.")
        }

        if (UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\Microsoft\RDMonitoringAgent" -value "Ring") {
            $ring = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Microsoft\RDMonitoringAgent" -name "Ring"

            if ($ring -eq "R0") {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Host pool ring: " + $ring + ". This is a validation ring, intended for testing, not production use.")
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Host pool ring: " + $ring)
            }
        }

        if (UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\Microsoft\RDInfraAgent" -value "Geography") {
            $geo = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Microsoft\RDInfraAgent" -name "Geography"
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Geography: " + $geo)
        }
    } else {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] This machine is not part of a AVD host pool.")
    }


    #check number of vCPUs
    $vCPUs = (Get-CimInstance -Namespace "root\cimv2" -Query "select NumberOfLogicalProcessors from Win32_ComputerSystem" -ErrorAction SilentlyContinue).NumberOfLogicalProcessors

    if (($ver -like "*Virtual Desktops*") -or ($ver -like "*Server*")) {
        if (($vCPUs -lt 4) -or ($vCPUs -gt 24)) {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Number of vCPUs: " + $vCPUs + ". We recommend limiting VM size to between 4 vCPUs and 24 vCPUs. See: https://docs.microsoft.com/en-us/windows-server/remote/remote-desktop-services/virtual-machine-recs#recommended-vm-sizes-for-standard-or-larger-environments")
        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Number of vCPUs: " + $vCPUs)
        }
    }
    else {
        if ($vCPUs -lt 4) {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Number of vCPUs: " + $vCPUs + ". We recommend at least 4 vCPUs for single-session VMs. See: https://docs.microsoft.com/en-us/windows-server/remote/remote-desktop-services/virtual-machine-recs#recommended-vm-sizes-for-standard-or-larger-environments")
        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Number of vCPUs: " + $vCPUs)
        }
    }


    #check last boot up time
    $lboott = (Get-CimInstance -ClassName win32_operatingsystem).lastbootuptime
    $lboottdif = [datetime]::Now - $lboott
    $sincereboot = " (" + $lboottdif.Days + "d " + $lboottdif.Hours + "h " + $lboottdif.Minutes + "m ago)"

    if ($lboottdif.TotalHours -ge 25) {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Last boot up time: " + $lboott + $sincereboot + ". Rebooting once every day could help clean out stuck sessions and avoid potential profile load issues.")
    } else {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Last boot up time: " + $lboott + $sincereboot)
    }


    #check Time Zone Redirection policy
    if (Test-Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\') {
        if (UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\" -value "fEnableTimeZoneRedirection") {
            $tzr = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\" -name "fEnableTimeZoneRedirection"
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] 'fEnableTimeZoneRedirection' registry key found. Value: " + $tzr)
        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] 'fEnableTimeZoneRedirection' registry key not found.")
        }
    }


    #check LmCompatibilityLevel
    if (Test-Path 'HKLM:\System\CurrentControlSet\Control\Lsa\') {
        if (UEXAVD_TestRegistryValue -path "HKLM:\System\CurrentControlSet\Control\Lsa\" -value "LmCompatibilityLevel") {
            $lm = Get-ItemPropertyValue -Path "HKLM:\System\CurrentControlSet\Control\Lsa\" -name "LmCompatibilityLevel"
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] 'LmCompatibilityLevel' registry key found. Value: " + $lm)
        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] 'LmCompatibilityLevel' registry key not found.")
        }
    }

#endregion Brief deployment info


#region Checking status of key services
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking status of key services"
    " " | Out-File -Append $diagfile

    if (!($ver -like "*Windows 7*")) {
        $servlist = "RdAgent", "RDAgentBootLoader", "TermService", "SessionEnv", "UmRdpService", "WinRM", "AppXSvc", "AppReadiness", "frxsvc", "frxdrv", "frxccds", "OneDrive Updater Service", "msiserver"
    } else {
        $servlist = "WVDAgent", "WVDAgentManager", "TermService", "SessionEnv", "UmRdpService", "WinRM", "frxsvc", "frxdrv", "frxccds", "OneDrive Updater Service", "msiserver"
    }

    $servlist | ForEach-Object -Process {

        $service = Get-Service -Name $_ -ErrorAction SilentlyContinue
        if ($service.Length -gt 0) {
            $servstatus = (Get-Service $_).Status
            $servdispname = (Get-Service $_).DisplayName
            $servstart = (Get-Service $_).StartType
            if ($servstart -eq "Disabled") {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] " + $_ + " (" + $servdispname + ") is in '" + $servstatus + "' state (StartType: " + $servstart + ").")
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] " + $_ + " (" + $servdispname + ") is in '" + $servstatus + "' state (StartType: " + $servstart + ").")
            }
        }
        else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] " + $_ + " not found.")
        }
    }

#endregion Checking status of key services


#region Checking <BrokerURI>/api/health and <BrokerURIGlobal>/api/health availability
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking BrokerURI and BrokerURIGlobal health status"
    " " | Out-File -Append $diagfile

    $brokerURIregpath = "HKLM:\SOFTWARE\Microsoft\RDInfraAgent\"

    if (Test-Path $brokerURIregpath) {
        $brokerURIregkey = "BrokerURI"
            if (UEXAVD_TestRegistryValue -path $brokerURIregpath -value $brokerURIregkey) {
                $brokerURI = Get-ItemPropertyValue -Path $brokerURIregpath -name $brokerURIregkey
                $brokerURI = $brokerURI + "api/health"
                UEXAVD_CheckSiteURLStatus $brokerURI
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Registry key '$brokerURIregpath$brokerURIregkey' not found. This machine doesn't seem to be a AVD VM or it is not configured properly."
            }

        $brokerURIGlobalregkey = "BrokerURIGlobal"
            if (UEXAVD_TestRegistryValue -path $brokerURIregpath -value $brokerURIGlobalregkey) {
                $brokerURIGlobal = Get-ItemPropertyValue -Path $brokerURIregpath -name $brokerURIGlobalregkey
                $brokerURIGlobal = $brokerURIGlobal + "api/health"
                UEXAVD_CheckSiteURLStatus $brokerURIGlobal
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Registry key '$brokerURIregpath$brokerURIGlobalregkey' not found. This machine doesn't seem to be a AVD VM or it is not configured properly."
            }
    } else {
        UEXAVD_LogDiag $LogLevel.Warning ("[$LogPrefix] AVD Agent not found. Skipping check (not applicable).")
    }

#endregion Checking <BrokerURI>/api/health and <BrokerURIGlobal>/api/health availability


#region Checking AVD Agent and Stack information (not for Win7)
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking AVD Agent and Stack information"
    " " | Out-File -Append $diagfile

    if (!($ver -like "*Windows 7*")) {
        if (Test-Path 'HKLM:\SOFTWARE\Microsoft\RDAgentBootLoader') {
            if (UEXAVD_TestRegistryValue -Path 'HKLM:\SOFTWARE\Microsoft\RDAgentBootLoader\' -Value 'DefaultAgent') {
                $AVDagent = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\RDAgentBootLoader\' -name "DefaultAgent"
                $AVDagentver = $AVDagent.split("_")[1]
                $AVDagentdate = (Get-ItemProperty  hklm:\software\microsoft\windows\currentversion\uninstall\* | Where-Object {($_.DisplayName -eq "Remote Desktop Services Infrastructure Agent" -and $_.DisplayVersion -eq $AVDagentver)}).InstallDate
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Current AVD Agent version: " + $AVDagentver + " (Installed on: " + $AVDagentdate + ")")

                if (UEXAVD_TestRegistryValue -Path 'HKLM:\SOFTWARE\Microsoft\RDInfraAgent\SxsStack\' -Value 'CurrentVersion') {
                    $sxsstack = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\RDInfraAgent\SxsStack' -name "CurrentVersion"
                    $sxsstackpath = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\RDInfraAgent\SxsStack' -name $sxsstack
                    $sxsstackver = $sxsstackpath.split("-")[1].trimend(".msi")
                    $sxsstackdate = (Get-ItemProperty  hklm:\software\microsoft\windows\currentversion\uninstall\* | Where-Object {($_.DisplayName -eq "Remote Desktop Services SxS Network Stack" -and $_.DisplayVersion -eq $sxsstackver)}).InstallDate
                } else {
                    $sxsstackver = "N/A"
                    $sxsstackdate = "N/A"
                }
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Current SxS Stack version: " + $sxsstackver + " (Installed on: " + $sxsstackdate + ")")

                if (UEXAVD_TestRegistryValue -Path 'HKLM:\SOFTWARE\Microsoft\RDAgentBootLoader\' -Value 'PreviousAgent') {
                    $AVDagentpre = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\RDAgentBootLoader\' -name "PreviousAgent"
                    $AVDagentverpre = $AVDagentpre.split("_")[1]
                    $AVDagentdatepre = (Get-ItemProperty  hklm:\software\microsoft\windows\currentversion\uninstall\* | Where-Object {($_.DisplayName -eq "Remote Desktop Services Infrastructure Agent" -and $_.DisplayVersion -eq $AVDagentverpre)}).InstallDate
                } else {
                    $AVDagentverpre = "N/A"
                    $AVDagentdatepre = "N/A"
                }
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Previous AVD Agent version: " + $AVDagentverpre + " (Installed on: " + $AVDagentdatepre + ")")

                if (UEXAVD_TestRegistryValue -Path 'HKLM:\SOFTWARE\Microsoft\RDInfraAgent\SxsStack\' -Value 'PreviousVersion') {
                    $sxsstackpre = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\RDInfraAgent\SxsStack' -name "PreviousVersion"
                    $sxsstackpathpre = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\RDInfraAgent\SxsStack' -name $sxsstackpre
                    $sxsstackverpre = $sxsstackpathpre.split("-")[1].trimend(".msi")
                    $sxsstackdatepre = (Get-ItemProperty  hklm:\software\microsoft\windows\currentversion\uninstall\* | Where-Object {($_.DisplayName -eq "Remote Desktop Services SxS Network Stack" -and $_.DisplayVersion -eq $sxsstackverpre)}).InstallDate
                } else {
                    $sxsstackverpre = "N/A"
                    $sxsstackdatepre = "N/A"
                }
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Previous SxS Stack version: " + $sxsstackverpre + " (Installed on: " + $sxsstackdatepre + ")")

            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDAgentBootLoader\DefaultAgent' not found. This machine is either not a AVD VM or the AVD agent is not installed or configured properly.")
            }
        } else {
            UEXAVD_LogDiag $LogLevel.Warning ("[$LogPrefix] AVD Agent not found. Skipping check (not applicable).")
        }

    } else {
        UEXAVD_LogDiag $LogLevel.Warning ("[$LogPrefix] Windows 7 detected. Skipping check (not applicable).")
    }

#endregion Checking AVD Agent and Stack information (not for Win7)


#region Checking for RD Listener configuration
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking Remote Desktop Listener configuration"
    " " | Out-File -Append $diagfile

    $Commands = @(
        "UEXAVD_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\' 'fEnableWinStation' '1'"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True


    #checking if multiple AVD listener reg keys are present

    if (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\rdp-sxs*') {

        (Get-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\rdp-sxs*').PSChildName | foreach-object -process {

            $AVDlistener = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\" + $_

            if (UEXAVD_TestRegistryValue -Path $AVDlistener -Value 'fEnableWinStation') {
                $AVDkeyvalue = Get-ItemPropertyValue -Path $AVDlistener -name "fEnableWinStation"
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\" + $_ + "\fEnableWinStation' exists and has a value of: " + $AVDkeyvalue)
            }
            else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] AVD Listener registry keys found, but the registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\" + $_ + "\fEnableWinStation' not found.")
            }
        }
    }
    else {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] AVD listener (HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\rdp-sxs*) registry keys not found. This machine is either not a AVD VM or the AVD listener is not configured properly.")
    }


    #checking for the current AVD listener version and "fReverseConnectMode"

    if (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations') {
        if (UEXAVD_TestRegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\' -Value 'ReverseConnectionListener') {
            $listenervalue = Get-ItemPropertyValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations' -name "ReverseConnectionListener"
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] The AVD listener currently in use is: " + $listenervalue)
            $listenerregpath = 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\' + $listenervalue

            if (UEXAVD_TestRegistryValue -Path $listenerregpath -Value 'fReverseConnectMode') {
                $revconkeyvalue = Get-ItemPropertyValue -Path $listenerregpath -name "fReverseConnectMode"
                if ($revconkeyvalue -eq "1") {
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\" + $listenervalue + "\fReverseConnectMode' exists and has a value of: " + $revconkeyvalue)
                } else {
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\" + $listenervalue + "\fReverseConnectMode' exists BUT has a value of: " + $revconkeyvalue + " (instead of the expected value of '1'). Please review: https://docs.microsoft.com/en-us/azure/virtual-desktop/troubleshoot-agent#error-stack-listener-isnt-working-on-windows-10-2004-vm")
                }
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\" + $listenervalue + "\fReverseConnectMode not found.")
            }

        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\ReverseConnectionListener' not found. This machine is either not a AVD VM or the AVD listener is not configured properly.")
        }
    } else {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations' not found. This machine is either not a AVD VM or the AVD listener is not configured properly.")
    }

#endregion Checking for RD Listener configuration


#region Checking for AVD Agent issues
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking for AVD Agent issues over the past 5 days"
    " " | Out-File -Append $diagfile

    $agentpath = "C:\Program Files\Microsoft RDInfra\"
    $global:aicounter = 0

    if (Test-Path $agentpath) {
        $Commands = @(
            "UEXAVD_DiagAVDAgentIssues 'Application' '3019' 'Transport received an exception'"
            "UEXAVD_DiagAVDAgentIssues 'Application' '3277' 'ENDPOINT_NOT_FOUND'"
            "UEXAVD_DiagAVDAgentIssues 'Application' '3277' 'INVALID_FORM'"
            "UEXAVD_DiagAVDAgentIssues 'Application' '3277' 'INVALID_REGISTRATION_TOKEN'"
            "UEXAVD_DiagAVDAgentIssues 'Application' '3277' 'NAME_ALREADY_REGISTERED'"
            "UEXAVD_DiagAVDAgentIssues 'Application' '3277' 'DownloadMsiException'"
            "UEXAVD_DiagAVDAgentIssues 'Application' '3277' 'InstallationHealthCheckFailedException'"
            "UEXAVD_DiagAVDAgentIssues 'Application' '3277' 'InstallMsiException'"
            "UEXAVD_DiagAVDAgentIssues 'Application' '3389' 'MissingMethodException'"
            "UEXAVD_DiagAVDAgentIssues 'Application' '3703' 'RD Gateway Url'"
            "UEXAVD_DiagAVDAgentIssues 'RemoteDesktopServices' '0' 'IMDS not accessible'"
            "UEXAVD_DiagAVDAgentIssues 'RemoteDesktopServices' '0' 'Monitoring Agent Launcher file path was NOT located'"
            "UEXAVD_DiagAVDAgentIssues 'RemoteDesktopServices' '0' 'NOT ALL required URLs are accessible!'"
            "UEXAVD_DiagAVDAgentIssues 'RemoteDesktopServices' '0' 'SessionHost unhealthy'"
            "UEXAVD_DiagAVDAgentIssues 'RemoteDesktopServices' '0' 'Unable to connect to the remote server'"
            "UEXAVD_DiagAVDAgentIssues 'RemoteDesktopServices' '0' 'Unhandled status [ConnectFailure] returned for url'"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True
        if ($global:aicounter -gt 0) {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] You might have issues with registering this VM to the host pool, the VM might be in an 'Unavailable' state or connecting to it through the AVD services might be failing."
        }
    } else {
        UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] AVD Agent not found. Skipping check (not applicable)."
    }

#endregion Checking for AVD Agent issues


#region Checking for WinHTTP proxy settings
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking for NETSH WINHTTP proxy configuration"
    " " | Out-File -Append $diagfile

    $binval = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Connections" -Name WinHttpSettings).WinHttPSettings
    $proxylength = $binval[12]
    if ($proxylength -gt 0) {
        $proxy = -join ($binval[(12+3+1)..(12+3+1+$proxylength-1)] | ForEach-Object {([char]$_)})
        UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] A NETSH WINHTTP proxy is configured: " + $proxy)
        $bypasslength = $binval[(12+3+1+$proxylength)]

        if ($bypasslength -gt 0) {
            $bypasslist = -join ($binval[(12+3+1+$proxylength+3+1)..(12+3+1+$proxylength+3+1+$bypasslength)] | ForEach-Object {([char]$_)})
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Bypass list: " + $bypasslist)
        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] No bypass list is configured."
        }
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] AVD may not work very well through proxies when the required URLs are not allowed. Please review https://docs.microsoft.com/en-us/azure/virtual-desktop/safe-url-list to make sure all URLs are accessible."
    } else {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] NETSH WINHTTP proxy configuration not found."
    }

#endregion Checking for WinHTTP proxy settings


#region Checking SSL configuration
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking SSL configuration"
    " " | Out-File -Append $diagfile

    if (Test-Path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002') {
        if (UEXAVD_TestRegistryValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -Value 'Functions') {
            $rdpkeyvalue1 = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -name "Functions"
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\Functions' exists and has a value of: " + $rdpkeyvalue1)
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] Make sure that the configured SSL cipher suites contain also the ones required by Azure Front Door: https://docs.microsoft.com/en-us/azure/frontdoor/front-door-faq#what-are-the-current-cipher-suites-supported-by-azure-front-door"
        }
        else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\Functions' not found."
        }

        if (UEXAVD_TestRegistryValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -Value 'EccCurves') {
            $rdpkeyvalue2 = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -name "EccCurves"
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\EccCurves' exists and has a value of: " + $rdpkeyvalue2)
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] You might be running into an issue with reverse connect failing with error 0x80072F7D (2147954557) leading to users being unable to connect."
        }
        else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\EccCurves' not found."
        }

    } else {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' not found."
    }

#endregion Checking 'SSL Cipher Suite Order' configuration


#region Checking for Session Time Limit policy settings
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking for Session Time Limit policy settings"
    " " | Out-File -Append $diagfile

    $agentpath = "C:\Program Files\Microsoft RDInfra\"

    if (Test-Path $agentpath) {
        $Commands = @(
            "UEXAVD_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'MaxIdleTime'"
            "UEXAVD_CheckRegKeyValue 'HKCU:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'MaxIdleTime'"
            "UEXAVD_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'MaxConnectionTime'"
            "UEXAVD_CheckRegKeyValue 'HKCU:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'MaxConnectionTime'"
            "UEXAVD_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'MaxDisconnectionTime'"
            "UEXAVD_CheckRegKeyValue 'HKCU:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'MaxDisconnectionTime'"
            "UEXAVD_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'RemoteAppLogoffTimeLimit'"
            "UEXAVD_CheckRegKeyValue 'HKCU:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'RemoteAppLogoffTimeLimit'"
            "UEXAVD_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fResetBroken'"
            "UEXAVD_CheckRegKeyValue 'HKCU:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fResetBroken'"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True
    } else {
        UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] AVD Agent not found. Skipping check (not applicable)."
    }

#endregion Checking 'DeleteUserAppContainersOnLogoff' registry key


#region Checking if the Remote Desktop Session Host role is installed (only if OS is Windos Server based)
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking Remote Desktop Session Host role presence"
    " " | Out-File -Append $diagfile

    if ($ver -like "*Windows Server*") {
        if (Get-WindowsFeature -Name RDS-RD-Server) {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Remote Desktop Session Host role is installed on this VM."
        }
        else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] Remote Desktop Session Host role is not installed on this VM. The VM is running server OS and the RDSH role is required for proper host pool registration."
        }
    } else {
        UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] Windows Server OS not found. Skipping check (not applicable)."
    }

#endregion Checking if the Remote Desktop Session Host role is installed (only if OS is Windos Server based)


#region Checking 'DeleteUserAppContainersOnLogoff' registry key
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking DeleteUserAppContainersOnLogoff registry key"
    " " | Out-File -Append $diagfile

    $Commands = @(
        "UEXAVD_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\' 'DeleteUserAppContainersOnLogoff' '1'"
    )
    UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True
    if (($global:regok -eq 2) -or ($global:regok -eq 0)) {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] You could eventually run into host performance/hang issues if this key is not configured. See: https://support.microsoft.com/en-us/help/4490481"
    }

#endregion Checking 'DeleteUserAppContainersOnLogoff' registry key


#region Checking WinRM configuration
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking WinRM configuration"
    " " | Out-File -Append $diagfile

    if ((get-service -name WinRM).status -eq "Running") {
            $ipfilter = Get-Item WSMan:\localhost\Service\IPv4Filter
            if ($ipfilter.Value) {
                if ($ipfilter.Value -eq "*") {
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] IPv4Filter = *"
                } else {
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] IPv4Filter = " + $ipfilter.Value)
                }
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] IPv4Filter is empty, WinRM will not listen on IPv4.")
            }

            $ipfilter = Get-Item WSMan:\localhost\Service\IPv6Filter
            if ($ipfilter.Value) {
                if ($ipfilter.Value -eq "*") {
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] IPv6Filter = *"
                } else {
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] IPv6Filter = " + $ipfilter.Value)
                }
            } else {
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] IPv6Filter is empty, WinRM will not listen on IPv6.")
            }
        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] The WinRM service is not running.")
        }

    if (!($ver -like "*Windows 7*")) {
        $fwrules = (Get-NetFirewallPortFilter –Protocol TCP | Where-Object { $_.localport –eq ‘5985’ } | Get-NetFirewallRule)
        if ($fwrules.count -eq 0) {
          UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] No firewall rule for port 5985."
        } else {
          UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Found firewall rule for port 5985. Check the 'FirewallRules.txt' file for more details."
        }


        $fwrules = (Get-NetFirewallPortFilter –Protocol TCP | Where-Object { $_.localport –eq ‘5986’ } | Get-NetFirewallRule)
        if ($fwrules.count -eq 0) {
          UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] No firewall rule for port 5986."
        } else {
          UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Found firewall rule for port 5986. Check the 'FirewallRules.txt' file for more details."
        }
    } else {
        UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] Windows 7 detected. Skipping firewall port check. (not implemented yet)"
    }

#endregion Checking WinRM configuration


#region Checking the WinRMRemoteWMIUsers__ group"
    if ((get-ciminstance -Class Win32_ComputerSystem).PartOfDomain) {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Checking the WinRMRemoteWMIUsers__ group"
        $search = New-Object DirectoryServices.DirectorySearcher([ADSI]"")  # This is a Domain local group, therefore we need to collect to a non-global catalog
        $search.filter = "(samaccountname=WinRMRemoteWMIUsers__)"
        try {
            $results = $search.Findall()
        } catch {
            $_ | Out-File -Append -FilePath $ErrorLogFile
        }

        if ($results.count -gt 0) {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Found " + $results.Properties.distinguishedname)
            if ($results.Properties.grouptype -eq  -2147483644) {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] WinRMRemoteWMIUsers__ is a Domain local group."
            } elseif ($results.Properties.grouptype -eq -2147483646) {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] WinRMRemoteWMIUsers__ is a Global group."
            } elseif ($results.Properties.grouptype -eq -2147483640) {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] WinRMRemoteWMIUsers__ is a Universal group."
            }
            if (get-ciminstance -query "select * from Win32_Group where Name = 'WinRMRemoteWMIUsers__' and Domain = '$env:computername'") {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The group WinRMRemoteWMIUsers__ is also present as machine local group."
            }
        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The WinRMRemoteWMIUsers__ was not found in the domain."
            if (get-ciminstance -query "select * from Win32_Group where Name = 'WinRMRemoteWMIUsers__' and Domain = '$env:computername'") {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The group WinRMRemoteWMIUsers__ is present as machine local group."
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] WinRMRemoteWMIUsers__ group not found as machine local group."
            }
        }
    } else {
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] The machine is not joined to a domain."
        if (get-ciminstance -query "select * from Win32_Group where Name = 'WinRMRemoteWMIUsers__' and Domain = '$env:computername'") {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The group WinRMRemoteWMIUsers__ is present as machine local group."
        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] WinRMRemoteWMIUsers__ group not found as machine local group."
        }
    }

#endregion Checking the WinRMRemoteWMIUsers__ group"


#region Checking UDP ShortPath configuration
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking UDP ShortPath configuration"
    " " | Out-File -Append $diagfile

    if (!($ver -like "*Windows 7*")) {
        $agentpath = "C:\Program Files\Microsoft RDInfra\"
        if (Test-Path $agentpath) {
            $Commands = @(
                "UEXAVD_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\' 'fUseUdpPortRedirector' '1'"
                "UEXAVD_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\' 'UdpPortNumber' '3390'"
            )
            UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True

            # Checking if TermService is listening for UDP
            $udplistener = Get-NetUDPEndpoint -OwningProcess ((get-ciminstance win32_service -Filter "name = 'TermService'").ProcessId) -LocalPort 3390 -ErrorAction SilentlyContinue

            if ($udplistener) {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] TermService is listening on UDP port 3390."
            } else {
                # Checking the process occupying UDP port 3390
                $procpid = (Get-NetUDPEndpoint -LocalPort 3390 -LocalAddress 0.0.0.0 -ErrorAction SilentlyContinue).OwningProcess

                if ($procpid) {
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] TermService is NOT listening on UDP port 3390. UDP ShortPath is either not configured at all or not configured properly. The UDP port 3390 is being used by:"
                    tasklist /svc /fi "PID eq $procpid" | Out-File -Append $diagfile
                } else {
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] No process is using UDP port 3390. UDP ShortPath is either not configured at all or not configured properly."
                }
            }

            #Checking if there are Firewall rules for UDP 3390
            $fwrules = (Get-NetFirewallPortFilter –Protocol UDP | Where-Object { $_.localport –eq ‘3390’ } | Get-NetFirewallRule)
            if ($fwrules.count -eq 0) {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] No firewall rule for UDP port 3390."
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Found firewall rule for UDP port 3390. Check the 'FirewallRules.txt' file for more details."
            }

        } else {
            UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] AVD Agent not found. Skipping check (not applicable)."
        }

    } else {
        UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] Windows 7 detected. Skipping check (not applicable)."
    }

#endregion Checking UDP ShortPath configuration


#region Checking for process crash events
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking for process crash events over the past 5 days"
    " " | Out-File -Append $diagfile
    UEXAVD_DiagProcessCrash

#endregion Checking for process crash events


#region Checking AVD host VM access to the required URLs
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking AVD host VM access to the required URLs"
    " " | Out-File -Append $diagfile
    UEXAVD_RequiredURLCheck

#endregion Checking AVD host VM access to the required URLs


###extended

#region Checking FSLogix settings
    "`n======================================================================`n" | Out-File -Append $diagfile

    " " | Out-File -Append $diagfile
    "Extended Diagnostics" | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking FSLogix settings"
    " " | Out-File -Append $diagfile

    $cmd = "c:\program files\fslogix\apps\frx.exe"

    if (Test-path -path 'C:\Program Files\FSLogix\apps') {
        Invoke-Expression "& '$cmd' + 'version'" | ForEach-Object -Process {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] " + $_)
            if ($_ -like "*Service*") {
                $frxver = ($_.Split(":")[1]).Trim()
            }
        }

        if (UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Profiles\" -value "Enabled") {
            $pOn = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\FSLogix\Profiles\" -name "Enabled"
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Profiles container 'Enabled' registry key found and has a value of: " + $pOn)

            if (UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Profiles\" -value "VHDLocations") {
                $pvhd = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\FSLogix\Profiles\" -name "VHDLocations"
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Profiles container 'VHDLocations' registry key found and has a value of: " + $pvhd)
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] FSLogix Profile Container 'VHDLocations' registry key not found.")
            }

            if (UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Profiles\" -value "CCDLocations") {
                $pccd = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\FSLogix\Profiles\" -name "CCDLocations"
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Cloud Cache for Profile Container 'CCDLocations' registry key found and has a value of: " + $pccd)
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Cloud Cache for Profile Container 'CCDLocations' registry key not found.")
            }

            if ((UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Profiles\" -value "VHDLocations") -and (UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Profiles\" -value "CCDLocations")) {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Both Profile VHDLocations and Profile Cloud Cache CCDLocations registry keys are present. If you want to use Profile Cloud Cache, remove any setting for Profile 'VHDLocations'. See: https://docs.microsoft.com/en-us/fslogix/configure-cloud-cache-tutorial#configure-cloud-cache-for-smb")
            }

        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] FSLogix Profile Container 'Enabled' registry key not found. Profile container is not enabled.")
        }

        if (UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -value "Enabled") {
            $oOn = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -name "Enabled"
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Office container 'Enabled' registry key found and has a value of: " + $oOn)

            if (UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -value "VHDLocations") {
                $ovhd = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -name "VHDLocations"
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Office container 'VHDLocations' registry key found and has a value of: " + $ovhd)
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] FSLogix Office Container 'VHDLocations' registry key not found.")
            }

            if (UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -value "CCDLocations") {
                $occd = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -name "CCDLocations"
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Cloud Cache for Office Container 'CCDLocations' registry key found and has a value of: " + $occd)
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Cloud Cache for Office Container 'CCDLocations' registry key not found.")
            }

            if ((UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -value "VHDLocations") -and (UEXAVD_TestRegistryValue -path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -value "CCDLocations")) {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Both Office VHDLocations and Office Cloud Cache CCDLocations registry keys are present. If you want to use Office Cloud Cache, remove any setting for Office 'VHDLocations'. See: https://docs.microsoft.com/en-us/fslogix/configure-cloud-cache-tutorial#configure-cloud-cache-for-smb")
            }

        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] FSLogix Office Container 'Enabled' registry key not found. Office Container is not enabled.")
        }

        $frxver = $frxver.Replace(".","")
        if ($frxver -ge 29762130127) {
            $Commands = @(
                "UEXAVD_CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Apps\' 'CleanupInvalidSessions' '1'"
            )
            UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True
        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] FSLogix release earlier than release 2009 found. Please update FSLogix to the latest version. Review: https://docs.microsoft.com/en-us/fslogix/whats-new"
        }

        $Commands = @(
            "UEXAVD_CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Profiles\' 'DeleteLocalProfileWhenVHDShouldApply' '1'"
            "UEXAVD_CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Profiles\' 'SizeInMBs' '30000'"
            "UEXAVD_CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Profiles\' 'VolumeType' 'VHDx'"
            "UEXAVD_CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Profiles\' 'FlipFlopProfileDirectoryName' '1'"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True

        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] FSLogix service recovery settings:"
        $commandline = "sc.exe qfailure frxsvc"
        $out = Invoke-Expression -Command $commandline
        foreach ($outopt in $out) {
            if (!($outopt -like "*QueryServiceConfig*")) {
                $outopt | Out-File -Append $DiagFile
            }
        }

    } else {
        UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] FSLogix not found. Skipping check (not applicable)."
    }

#endregion Checking FSLogix settings


#region Checking for recommended Windows Defender configuration for Server OS
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking for recommended Windows Defender configuration for Server OS"
    " " | Out-File -Append $diagfile

    if ($ver -like "*Windows Server*") {
        $WDpath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\"
        $WDkey = "DisableAntiSpyware"
        if (UEXAVD_TestRegistryValue -path $WDpath -value $WDkey) {
            (Get-ItemProperty -path $WDpath).PSChildName | foreach-object -process {
                $key = Get-ItemPropertyValue -Path $WDpath -name $WDkey

                if ($key -eq $True) {
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Registry key '$WDpath$WDkey' exists and is set to 'True'. It is not recommended to disable Windows Defender, unless you are using another Antivirus software. Please see: https://docs.microsoft.com/en-us/windows-hardware/customize/desktop/unattend/security-malware-windows-defender-disableantispyware")
                }
                else {
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key '$WDpath$WDkey' exists and is set to 'False'.")
                }
            }
        } else {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key '$WDpath$WDkey' not found.")
        }
    } else {
        UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] Windows Server OS not found. Skipping check (not applicable)."
    }

#endregion Checking for recommended Windows Defender configuration for Server OS


#region Checking for proper Defender Exclusions for FSLogix
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking for recommended Windows Defender Exclusions for FSLogix"
    " " | Out-File -Append $diagfile

    if (Test-path -path 'C:\Program Files\FSLogix\apps') {

        #checking for actual Profiles VHDLocations value
        $pVHDpath = "HKLM:\SOFTWARE\FSLogix\Profiles\"
        $pVHDkey = "VHDLocations"
        if (UEXAVD_TestRegistryValue -path $pVHDpath -value $pVHDkey) {
            $pkey = (Get-ItemPropertyValue -Path $pVHDpath -name $pVHDkey).replace("`n","")
            $pkey1 = $pkey + "\*.VHD"
            $pkey2 = $pkey + "\*.VHDX"
        } else {
            #no path found, defaulting to generic value
            $pkey1 = "\\<storageaccount>.file.core.windows.net\<share>\*.VHD"
            $pkey2 = "\\<storageaccount>.file.core.windows.net\<share>\*.VHDX"
        }

        $ccdVHDkey = "CCDLocations"
        if (UEXAVD_TestRegistryValue -path $pVHDpath -value $ccdVHDkey) {
            $ccdkey = $True
        } else {
            $ccdkey = $false
        }

        $ccdRec = "%ProgramData%\FSLogix\Cache\*.VHD","%ProgramData%\FSLogix\Cache\*.VHDX","%ProgramData%\FSLogix\Proxy\*.VHD","%ProgramData%\FSLogix\Proxy\*.VHDX"
        $avRec = "%ProgramFiles%\FSLogix\Apps\frxdrv.sys","%ProgramFiles%\FSLogix\Apps\frxdrvvt.sys","%ProgramFiles%\FSLogix\Apps\frxccd.sys","%TEMP%\*.VHD","%TEMP%\*.VHDX","%Windir%\TEMP\*.VHD","%Windir%\TEMP\*.VHDX"

        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The tool is comparing the Windows Defender exclusion settings with the recommended settings. See: https://docs.microsoft.com/en-us/azure/architecture/example-scenario/AVD/windows-virtual-desktop-fslogix#antivirus-exclusions"
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The recommendations might change over time, so verify them periodically and ensure that you are using the latest recommendations."
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The recommended values could be configured through UI or GPO. They should be present at least in one of the locations."

        " " | Out-File -Append $diagfile

        if ($ccdkey) {
            $recAVexclusionsPaths = $avRec + $pkey1 + $pkey2 + $ccdRec
        } else {
            $recAVexclusionsPaths = $avRec + $pkey1 + $pkey2
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Cloud Cache is not enabled. The recommended Cloud Cache Exclusions will not be taken into consideration for this check. This may lead to false positives if you have the Cloud Cache Exclusions configured."
        }

        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Windows Defender Paths exclusions (UI configuration)"
        UEXAVD_TestAVExclusion "HKLM:\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths" $recAVexclusionsPaths
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Windows Defender Paths exclusions (GPO configuration)"
        UEXAVD_TestAVExclusion "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Paths" $recAVexclusionsPaths

        " " | Out-File -Append $diagfile
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Windows Defender Processes exclusions (UI configuration)"
        UEXAVD_TestAVExclusion "HKLM:\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes" ("%ProgramFiles%\FSLogix\Apps\frxccd.exe","%ProgramFiles%\FSLogix\Apps\frxccds.exe","%ProgramFiles%\FSLogix\Apps\frxsvc.exe")
        UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Windows Defender Processes exclusions (GPO configuration)"
        UEXAVD_TestAVExclusion "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Processes" ("%ProgramFiles%\FSLogix\Apps\frxccd.exe","%ProgramFiles%\FSLogix\Apps\frxccds.exe","%ProgramFiles%\FSLogix\Apps\frxsvc.exe")

    } else {
        UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] FSLogix not found. Skipping check (not applicable)."
    }

#endregion Checking for proper Defender Exclusions for FSLogix


#region Checking OneDrive configuration
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking OneDrive configuration"
    " " | Out-File -Append $diagfile

    $agentpath = "C:\Program Files\Microsoft RDInfra\"
    if (Test-Path $agentpath) {
        $ODM = "C:\Program Files (x86)\Microsoft OneDrive" + '\OneDrive.exe'
        $ODU = "$ENV:localappdata" + '\Microsoft\OneDrive\OneDrive.exe'

        if ((test-path $ODM) -or (test-path $ODU)) {
            $Commands = @(
                "UEXAVD_CheckRegKeyValue 'HKLM:\Software\Microsoft\OneDrive\' 'AllUsersInstall' '1'"
            )
            UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True

            if ($global:regok -eq 1) {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] OneDrive is installed in per-machine mode."
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] OneDrive is installed in per-user mode."
            }

            $Commands = @(
                "UEXAVD_CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Profiles\' 'ConcurrentUserSessions' '0'"
                "UEXAVD_CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Profiles\' 'ProfileType' '0'"
                "UEXAVD_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\FSLogix\ODFC\' 'VHDAccessMode' '0'"
            )
            UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True

        } else {
            UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] OneDrive installation not found."
        }

    } else {
        UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] AVD Agent not found. Skipping check (not applicable)."
    }

#endregion Checking OneDrive configuration


#region Checking media optimization configuration for Teams
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking media optimization configuration for Teams"
    " " | Out-File -Append $diagfile

    if ($ver -like "*Windows 10*") {

        #Checking Teams installation info
        $TeamsLogPath = $env:userprofile + "\AppData\Local\Microsoft\Teams\current\Teams.exe"
        if(Test-Path $TeamsLogPath) {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] Teams is installed in per-user mode. Teams won't work properly with per-user installation on a non-persistent setup."
            $isinst = $true
        } elseif (Test-Path "C:\Program Files (x86)\Microsoft\Teams\current\Teams.exe") {
            UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Teams is installed in per-machine mode."
            $isinst = $true
        } else {
            UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] Teams not found. Skipping check (not applicable)."
            $isinst = $false
        }

        if ($isinst) {
            #Checking for IsWVDEnvironment reg key
            if (Test-Path HKLM:\SOFTWARE\Microsoft\Teams) {
                if (UEXAVD_TestRegistryValue -Path 'HKLM:\SOFTWARE\Microsoft\Teams\' -Value 'IsWVDEnvironment') {
                    $teamskeyvalue = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\Teams' -name "IsWVDEnvironment"
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Teams\IsWVDEnvironment' exists and has a value of: " + $teamskeyvalue)
                } else {
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Teams\IsWVDEnvironment' not found. Media optimization for Teams is not configured or this machine is not part of a AVD host pool."
                }
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Teams' not found. Media optimization for Teams is not configured or this machine is not part of a AVD host pool."
            }

            #Checking Teams deployment
            $verpath = $env:userprofile + ”\AppData\Roaming\Microsoft\Teams\settings.json”

            if (Test-Path $verpath) {
                if ($PSVersionTable.PSVersion -like "*5.1*") {
                    $response = Get-Content $verpath -ErrorAction Continue
                    $response = $response -creplace 'enableIpsForCallingContext','enableIPSForCallingContext'
                    $response = $response | ConvertFrom-Json

                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Teams version: " + $response.version)
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Teams ring: " + $response.ring)
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Teams environment: " + $response.environment)
                } else {
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Teams version: " + (Get-Content $verpath -ErrorAction Continue | ConvertFrom-Json -AsHashTable).version)
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Teams ring: " + (Get-Content $verpath -ErrorAction Continue | ConvertFrom-Json -AsHashTable).ring)
                    UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Teams environment: " + (Get-Content $verpath -ErrorAction Continue | ConvertFrom-Json -AsHashTable).environment)
                }
            } else {
                UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] $verpath not found."
            }

            if ((Get-CimInstance -Class Win32_Product | Where-Object name -eq "Remote Desktop WebRTC Redirector Service").Version) {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Remote Desktop WebRTC Redirector Service version: " + (Get-CimInstance -Class Win32_Product | Where-Object name -eq "Remote Desktop WebRTC Redirector Service").Version)
            } else {
                UEXAVD_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] The Remote Desktop WebRTC Redirector Service is not installed. Media optimization for Teams is not configured or this machine is not part of a AVD host pool. Please review: https://docs.microsoft.com/en-us/azure/virtual-desktop/teams-on-AVD#install-the-teams-websocket-service")
            }
        }

    } else {
        UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] Windows 10 OS not found. Skipping check (not applicable)."
    }

#endregion Checking media optimization configuration for Teams


#region Checking for MSIX App Attach issues
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXAVD_LogDiag $LogLevel.Normal "Checking for MSIX App Attach issues over the past 5 days"
    " " | Out-File -Append $diagfile

    $agentpath = "C:\Program Files\Microsoft RDInfra\"

    if (Test-Path $agentpath) {
        $Commands = @(
            "UEXAVD_DiagMSIXAAIssues 'RemoteDesktopServices' '0' 'A certificate chain processed, but terminated in a root certificate which is not trusted by the trust provider'"
            "UEXAVD_DiagMSIXAAIssues 'RemoteDesktopServices' '0' 'MountDisk:  Error occured during mount'"
        )
        UEXAVD_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True
    } else {
        UEXAVD_LogDiag $LogLevel.Warning "[$LogPrefix] AVD Agent not found. Skipping check (not applicable)."
    }

#endregion Checking for MSIX App Attach issues


    " " | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile
    "`n======================================================================`n" | Out-File -Append $diagfile
    "`nReport generated with tool version: $version" | Out-File -Append $diagfile

    #Generating AVD-Diag to HTML file
    $SourceFile = $BasicLogFolder + "AVD-Diag.txt"
    $TargetFile = $BasicLogFolder + "AVD-Diag.html"
    $Title = "AVD-Diag : " + $env:computername

    $body = '<style>
    BODY {
    background-color:#E0E0E0;
    font-family: sans-serif;
    }
    table {
    background-color: white;
    border-collapse:collapse;
    border: 1px solid black;
    padding: 10px;
    }
    td {
    padding-left: 10px;
    }
    </style>'

    $File = Get-Content $SourceFile
    $FileLine = @()
    Foreach ($Line in $File) {
        $MyObject = New-Object -TypeName PSObject
        Add-Member -InputObject $MyObject -Type NoteProperty -Name "AVD CSS Diagnostics" -Value $Line
        $FileLine += $MyObject
    }

    $FileLine | ConvertTo-Html -Title $Title -body $body -Property "AVD CSS Diagnostics" | ForEach-Object {

        $PSItem -replace "AVD CSS Diagnostics","<br>AVD CSS Diagnostics<br><br>" `
        -replace "WARNING","<span style='background-color: #FFFF00'>WARNING</span>" `
        -replace "Skipping check","<span style='color: brown'>Skipping check</span>" `
        -replace "not found","<span style='color: brown'>not found</span>" `
        -replace "Running","<span style='color: green'>Running</span>" `
        -replace "Stopped","<span style='color: blue'>Stopped</span>" `
        -replace "Disabled","<span style='background-color: #FFFF00'>Disabled</span>" `
        -replace "NOT Accessible URLs:","<span style='background-color: #FFFF00'>NOT Accessible URLs:</span>" `
        -replace "AVD-Diag-ProcessCrashEvents.txt","<span style='font-weight: bold'>AVD-Diag-ProcessCrashEvents.txt</span>" `
        -replace "======================================================================","<br><hr><br>" `
        -replace "<td>Core Diagnostics</td>","<th>Core Diagnostics</th>" `
        -replace "<td>Extended Diagnostics</td>","<th>Extended Diagnostics</th>" `
        -replace "https://docs.microsoft.com/en-us/fslogix/configure-cloud-cache-tutorial#configure-cloud-cache-for-smb", "<a href='https://docs.microsoft.com/en-us/fslogix/configure-cloud-cache-tutorial#configure-cloud-cache-for-smb' target='_blank'>https://docs.microsoft.com/en-us/fslogix/configure-cloud-cache-tutorial#configure-cloud-cache-for-smb</a>" `
        -replace "https://docs.microsoft.com/en-us/azure/architecture/example-scenario/AVD/windows-virtual-desktop-fslogix#antivirus-exclusions","<a href='https://docs.microsoft.com/en-us/azure/architecture/example-scenario/AVD/windows-virtual-desktop-fslogix#antivirus-exclusions' target='_blank'>https://docs.microsoft.com/en-us/azure/architecture/example-scenario/AVD/windows-virtual-desktop-fslogix#antivirus-exclusions</a>" `
        -replace "https://support.microsoft.com/en-us/help/4490481","<a href='https://support.microsoft.com/en-us/help/4490481' target='_blank'>https://support.microsoft.com/en-us/help/4490481</a>" `
        -replace "https://docs.microsoft.com/en-us/windows-server/remote/remote-desktop-services/virtual-machine-recs#recommended-vm-sizes-for-standard-or-larger-environments","<a href='https://docs.microsoft.com/en-us/windows-server/remote/remote-desktop-services/virtual-machine-recs#recommended-vm-sizes-for-standard-or-larger-environments' target='_blank'>https://docs.microsoft.com/en-us/windows-server/remote/remote-desktop-services/virtual-machine-recs#recommended-vm-sizes-for-standard-or-larger-environments</a>" `
        -replace "https://docs.microsoft.com/en-us/azure/virtual-desktop/teams-on-AVD#install-the-teams-websocket-service","<a href='https://docs.microsoft.com/en-us/azure/virtual-desktop/teams-on-AVD#install-the-teams-websocket-service' target='_blank'>https://docs.microsoft.com/en-us/azure/virtual-desktop/teams-on-AVD#install-the-teams-websocket-service</a>" `
        -replace "https://docs.microsoft.com/en-us/azure/virtual-desktop/overview#supported-virtual-machine-os-images", "<a href='https://docs.microsoft.com/en-us/azure/virtual-desktop/overview#supported-virtual-machine-os-images' target='_blank'>https://docs.microsoft.com/en-us/azure/virtual-desktop/overview#supported-virtual-machine-os-images</a>" `
        -replace "Checking system/deployment","<b>Checking system/deployment</b>" `
        -replace "Checking status of key services","<b>Checking status of key services</b>" `
        -replace "Checking BrokerURI and BrokerURIGlobal health status","<b>Checking BrokerURI and BrokerURIGlobal health status</b>" `
        -replace "Checking AVD Agent and Stack information","<b>Checking AVD Agent and Stack information</b>" `
        -replace "Checking Remote Desktop Listener configuration","<b>Checking Remote Desktop Listener configuration</b>" `
        -replace "Checking for AVD Agent issues over the past 5 days","<b>Checking for AVD Agent issues over the past 5 days</b>" `
        -replace "AVD-Diag-AgentIssuesEvents.txt","<b>AVD-Diag-AgentIssuesEvents.txt</b>" `
        -replace "Checking for NETSH WINHTTP proxy configuration","<b>Checking for NETSH WINHTTP proxy configuration</b>" `
        -replace "Checking SSL configuration","<b>Checking SSL configuration</b>" `
        -replace "Checking for Session Time Limit policy settings","<b>Checking for Session Time Limit policy settings</b>" `
        -replace "Checking Remote Desktop Session Host role presence","<b>Checking Remote Desktop Session Host role presence</b>" `
        -replace "Checking DeleteUserAppContainersOnLogoff registry key","<b>Checking DeleteUserAppContainersOnLogoff registry key</b>" `
        -replace "Checking WinRM configuration","<b>Checking WinRM configuration</b>" `
        -replace "Checking UDP ShortPath configuration","<b>Checking UDP ShortPath configuration</b>" `
        -replace "Checking for process crash events over the past 5 days","<b>Checking for process crash events over the past 5 days</b>" `
        -replace "Checking AVD host VM access to the required URLs","<b>Checking AVD host VM access to the required URLs</b>" `
        -replace "Checking FSLogix settings", "<b>Checking FSLogix settings</b>" `
        -replace "Checking for recommended Windows Defender configuration for Server OS","<b>Checking for recommended Windows Defender configuration for Server OS</b>" `
        -replace "Checking for recommended Windows Defender Exclusions for FSLogix","<b>Checking for recommended Windows Defender Exclusions for FSLogix</b>" `
        -replace "Checking OneDrive configuration","<b>Checking OneDrive configuration</b>" `
        -replace "Checking media optimization configuration for Teams","<b>Checking media optimization configuration for Teams</b>" `
        -replace "Checking for MSIX App Attach issues over the past 5 days","<b>Checking for MSIX App Attach issues over the past 5 days</b>" `
        -replace "UI configuration","<span style='color: blue'>UI configuration</span>" `
        -replace "GPO configuration","<span style='color: blue'>GPO configuration</span>" `
        -replace "VHDLocations","<span style='color: blue'>VHDLocations</span>" `
        -replace "not enabled","<span style='color: brown'>not enabled</span>"
       } | Out-File $TargetFile
}

#endregion Main functions

#endregion Functions


#region ####################### MAIN ########################

UEXAVD_LogMessage $LogLevel.Info "Starting AVD-Collect - v$version" -Color "Cyan"

if ($AcceptEula) {
    UEXAVD_LogMessage $LogLevel.Info ("AcceptEula switch specified, silently continuing")
    $eulaAccepted = ShowEULAIfNeeded "AVD-Collect" 2
  } else {
    $eulaAccepted = ShowEULAIfNeeded "AVD-Collect" 0
    if($eulaAccepted -ne "Yes")
     {
       UEXAVD_LogMessage $LogLevel.Info ("EULA declined, exiting")
       exit
     }
   }
UEXAVD_LogMessage $LogLevel.Info ("EULA accepted, continuing")

Write-Host "`n=============== Microsoft CSS Diagnostics Script ===============`n"
Write-Host "This Data Collection is for troubleshooting reported issues for the given scenarios."
Write-Host "Once you have started this script please wait until all data has been collected.`n`n"
Write-Host "======================= IMPORTANT NOTICE =======================`n"
Write-Host "This script is designed to collect information that will help Microsoft Customer Support Services (CSS) troubleshoot an issue you may be experiencing with Azure Virtual Desktop."
Write-Host "The collected data may contain Personally Identifiable Information (PII) and/or sensitive data, such as (but not limited to) IP addresses; PC names; and user names."
Write-Host "The script will save the collected data in a folder and also compress the results into a ZIP file, both in the same location from where the script has been launched."
Write-Host "This folder and its contents or the ZIP file are not automatically sent to Microsoft."
Write-Host "You can send the ZIP file to Microsoft CSS using a secure file transfer tool - Please discuss this with your support professional and also any concerns you may have."
Write-Host "Find our privacy statement here: https://privacy.microsoft.com/en-US/privacystatement`n"

$UserConsent = Read-Host -Prompt 'Are you sure you want to continue? [Y/N]'

if ($UserConsent.ToLower() -ne "y") {
    Write-Host "Script execution not approved by the admin user, exiting.`n"
    Remove-Item -path $LogDir -Recurse | Out-Null
    UEXAVD_CleanUpandExit
}

""
if (!($Core) -and !($Extended) -and !($DiagOnly) -and !($Profiles) -and !($Teams) -and !($MSIXAA) -and !($MSRA)) {
    $title = "Please select one of the following AVD-Collect scenarios:"
    $message = "
        1) Collect 'Core' data (does not include Profiles/Teams/MSIX App Attach/MSRA data) + Run Diagnostics`n
        2) Collect 'Core + Profiles' data (for troubleshooting Profiles scenarios) + Run Diagnostics`n
        3) Collect 'Core + Teams' data (for troubleshooting Teams scenarios) + Run Diagnostics`n
        4) Collect 'Core + MSIX App Attach' data (for troubleshooting MSIX App Attach scenarios) + Run Diagnostics`n
        5) Collect 'Core + MSRA' data (for troubleshooting Remote Assistance scenarios) + Run Diagnostics`n
        6) Collect 'Extended' (all) troubleshooting data (includes Core + all other categories) + Run Diagnostics`n
        7) Run 'Diagnostics' only (skip data collection - may still log process crash or agent related events, if found)`n
    "

    $optCore = New-Object System.Management.Automation.Host.ChoiceDescription ' &1-Core ', 'The tool will collect core troubleshooting data without Profiles/Teams/MSIX App Attach/MSRA related information. + Run Diagnostics'
    $optProfiles = New-Object System.Management.Automation.Host.ChoiceDescription ' &2-Profiles ', 'The tool will collect all troubleshooting data included in the Core scenario and Profiles/FSLogix/OneDrive related data, as available. + Run Diagnostics'
    $optTeams = New-Object System.Management.Automation.Host.ChoiceDescription ' &3-Teams  ', 'The tool will collect all troubleshooting data included in the Core scenario and Teams related information, as data. + Run Diagnostics'
    $optMsixaa = New-Object System.Management.Automation.Host.ChoiceDescription ' &4-MSIXAA ', 'The tool will collect all troubleshooting data included in the Core scenario and MSIX App Attach related data, as available. + Run Diagnostics'
    $optMsra = New-Object System.Management.Automation.Host.ChoiceDescription ' &5-MSRA ', 'The tool will collect all troubleshooting data included in the Core scenario and Remote Assistance related data, as available. + Run Diagnostics'
    $optAll = New-Object System.Management.Automation.Host.ChoiceDescription ' &6-Extended ', 'The tool will collect all troubleshooting data included in the Core scenario and also Profiles/Teams/MSIXAA/MSRA related information, as available. + Run Diagnostics'
    $optDiag = New-Object System.Management.Automation.Host.ChoiceDescription ' &7-DiagOnly ', 'The tool will only run Diagnostics and log the results. It may also log process crash or agent related events, if found.'

    $options = [System.Management.Automation.Host.ChoiceDescription[]]($optCore, $optProfiles, $optTeams, $optMsixaa, $optMsra, $optAll, $optDiag)
    $result = $host.ui.PromptForChoice($title, $message, $options, 0)

    switch ($result) {
        0 {
            UEXAVD_LogMessage $LogLevel.Info ("'Core' scenario selected.")
            $Core = $True
        }
        1 {
            UEXAVD_LogMessage $LogLevel.Info ("'Core + Profiles' scenario selected.")
            $Profiles = $True
        }
        2 {
            UEXAVD_LogMessage $LogLevel.Info ("'Core + Teams' scenario selected.")
            $Teams = $True
        }
        3 {
            UEXAVD_LogMessage $LogLevel.Info ("'Core + MSIX App Attach' scenario selected.")
            $MSIXAA = $True
        }
        4 {
            UEXAVD_LogMessage $LogLevel.Info ("'Core + MSRA' scenario selected.")
            $MSRA = $True
          }
        5 {
            UEXAVD_LogMessage $LogLevel.Info ("'All' scenario selected.")
            $Extended = $True
          }
        6 {
            UEXAVD_LogMessage $LogLevel.Info ("'Diagnostics Only' scenario selected.")
            $DiagOnly = $True
          }
    }
}

$StopWatchDC = [system.diagnostics.stopwatch]::startNew()
""
" " | Out-File -Append $OutputLogFile
UEXAVD_CloseMSRDC

if ($Extended -and !($DiagOnly)) {
    CollectUEX_AVDCoreLog
    CollectUEX_AVDProfilesLog
    CollectUEX_AVDTeamsLog
    CollectUEX_AVDMSIXAALog
    CollectUEX_AVDMSRALog
}

if (!($Extended) -and !($DiagOnly)) {
    CollectUEX_AVDCoreLog
    if ($Profiles) { CollectUEX_AVDProfilesLog }
    if ($Teams) { CollectUEX_AVDTeamsLog }
    if ($MSIXAA) { CollectUEX_AVDMSIXAALog }
    if ($MSRA) { CollectUEX_AVDMSRALog }
}

RunUEX_AVDDiag

#endregion MAIN


#region ####################### Archive results ########################

$StopWatchDC.Stop()
$tsDC =  [timespan]::fromseconds(($StopWatchDC.Elapsed).TotalSeconds)
$elapsedDC = ("{0:hh\:mm\:ss\.fff}" -f $tsDC)
""
" " | Out-File -Append $OutputLogFile
UEXAVD_LogMessage $LogLevel.Info "Diagnostics complete - archiving files!" -Color "Cyan"
UEXAVD_LogMessage $LogLevel.Normal "Data collection/diagnostics duration (hh:mm:ss.fff): $elapsedDC`n"
$destination = $LogRoot + "\" + $LogFolder + ".zip"
Compress-Archive -Path $LogDir -DestinationPath $destination -CompressionLevel Optimal -Force

if (Test-path -path $destination) {
        UEXAVD_LogMessage $LogLevel.Normal "Zip file ready. Location of the collected data: $LogRoot\`n" -Color "Green"
    } else {
        UEXAVD_LogMessage $LogLevel.Error "Zip file could not be created. Please manually archive the subfolder containing the collected data. Location of the collected data: $LogRoot\`n"
    }
""
explorer $LogRoot

#endregion Archive

# Disabling quick edit mode as somethimes this causes the script stop working until enter key is pressed.
If($fQuickEditCodeExist){
    [DisableConsoleQuickEdit]::SetQuickEdit($True) | Out-Null
}

# SIG # Begin signature block
# MIIjigYJKoZIhvcNAQcCoIIjezCCI3cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDdY5+u2CurDF4Q
# dNtCG3uCHZRf8q5Nnovl1QVCV0xNTqCCDYUwggYDMIID66ADAgECAhMzAAAB4HFz
# JMpcmPgZAAAAAAHgMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ2WhcNMjExMjAyMjEzMTQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDRXpc9eiGRI/2BlmU7OMiQPTKpNlluodjT2rltPO/Gk47bH4gBShPMD4BX/4sg
# NvvBun6ZOG2dxUW30myWoUJJ0iRbTAv2JFzjSpVQvPE+D5vtmdu6WlOR2ahF4leF
# 5Vvk4lPg2ZFrqg5LNwT9gjwuYgmih+G2KwT8NMWusBhO649F4Ku6B6QgA+vZld5S
# G2XWIdvS0pmpmn/HFrV4eYTsl9HYgjn/bPsAlfWolLlEXYTaCljK7q7bQHDBrzlR
# ukyyryFpPOR9Wx1cxFJ6KBqg2jlJpzxjN3udNJPOqarnQIVgB8DUm3I5g2v5xTHK
# Ovz9ucN21467cYcIxjPC4UkDAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUVBWIZHrG4UIX3uX4142l+8GsPXAw
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzQ2MzAxMDAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AE5msNzmYzYbNgpnhya6YsrM+CIC8CXDu10nwzZtkgQciPOOqAYmFcWJCwD5VZzs
# qFwad8XIOrfCylWf4hzn09mD87yuazpuCstLSqfDLNd3740+254vEZqdGxOglAGU
# ih2IiF8S0GDwucpLGzt/OLXPFr/d4MWxPuX0L+HB5lA3Y/CJE673dHGQW2DELdqt
# ohtkhp+oWFn1hNDDZ3LP++HEZvA7sI/o/981Sh4kaGayOp6oEiQuGeCXyfrIC9KX
# eew0UlYX/NHVDqr4ykKkqpHtzbUbuo7qovUHPbYKcRGWrrEtBS5SPLFPumqsRtzb
# LgU9HqfRAN36bMsd2qynGyWBVFOM7NMs2lTCGM85Z/Fdzv/8tnYT36Cmbue+IM+6
# kS86j6Ztmx0VIFWbOvNsASPT6yrmYiecJiP6H0TrYXQK5B3jE8s53l+t61ab0Eul
# 7DAxNWX3lAiUlzKs3qZYQEK1LFvgbdTXtBRnHgBdABALK3RPrieIYqPln9sAmg3/
# zJZi4C/c2cWGF6WwK/w1Nzw08pj7jaaZZVBpCeDe+y7oM26QIXxracot7zJ21/TL
# 70biK36YybSUDkjhQPP/uxT0yebLNBKk7g8V98Wna2MsHWwk0sgqpkjIp02TrkVz
# 26tcF2rml2THRSDrwpBa4x9c8rM8Qomiyeh2tEJnsx2LMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCFVswghVXAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAHgcXMkylyY+BkAAAAA
# AeAwDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIN28
# IAWbqRv7PDDPvfkffTuTPEYi8dLaDOMIUqDfjUqRMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEAc0xxDnZP0KkJ+H7KSAuF7xFXHoVeKvk+X9n7
# 8XxoYkT3pdsYnaStRdlCmyqcmd+PBcpqpaEhSKCp+VcM4zhmeW7aYlRuduCSeoC+
# KeMOjS83fEsajqTtxty6G9rH3gTqRTzKlUbHgz9gMCAbMO+z+3ctD6ei6AMgsKXa
# 3uQ/8Ju+9Lwws1AkvXVjhskwG5HPkyhsXI0Pv9AX4ao/3LaA27v3YVmUCbg4OLt9
# aJVTa3nVFot24kLmF7Cc0juhfUpHU7shwMswdcCMKwmSP1i4w7xCp+w0NYvPxJv/
# SKGEAeUwmitBDJGfLp+HD58s3byJULNvFqujP1GbM4obPMDda6GCEuUwghLhBgor
# BgEEAYI3AwMBMYIS0TCCEs0GCSqGSIb3DQEHAqCCEr4wghK6AgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFRBgsqhkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCBt6wMZin/HFlYfvaB/tKrp9+on4kXeo5Nw
# OEoO2SUMdgIGYNGaRYfQGBMyMDIxMDYyMzEzNDUxOS44NzVaMASAAgH0oIHQpIHN
# MIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQL
# ExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjozQkJELUUzMzgtRTlBMTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCDjwwggTxMIID2aADAgECAhMzAAABT2QudfZ6A1qDAAAA
# AAFPMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIwMTExMjE4MjYwMloXDTIyMDIxMTE4MjYwMlowgcoxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVy
# aWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjNCQkQtRTMz
# OC1FOUExMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIB
# IjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoxR3tWT2aCjsG+T9xO/7SB0m
# r4rYXzH/LCaHciW1CyB5a1J2sUngsTchSgd6S3FjnckA8iQk0W6kapgtG0ng9Q30
# 9TyL+vwOhw7GdzYO890JQ4PwxJV5X0Gkr6d9nX0/VO+NjtH7yQu7AExHpwWs+34U
# 10IpcI7h1X1OVqm0sR503IhVqZgGyXPQT7j/u6WFzFKUt2sBiWZPXARX1XPQtawO
# XKk+AriBDEsOB1ELCJuBBWw0zAUj0f4aS0lYKCN7qdU0zqe+qPYBrS/p0HFX1UzR
# Nn37M6R8RAgPxbO168HGxBXtNNkR72tFgT24pGWmXh0BBw4thGfTJbI8rT9q/QID
# AQABo4IBGzCCARcwHQYDVR0OBBYEFI6N7tcWBhB+VZO/NcJk8TFf8qCgMB8GA1Ud
# IwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0
# dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0
# YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKG
# Pmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENB
# XzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUH
# AwgwDQYJKoZIhvcNAQELBQADggEBADwx5KscXOQyDnrK0Xs8m6KBX5eEMRpjQmuk
# btvr4C9uwusGQdEefJAZ4lpeQJoy6LyZSryXiST2nmIVO8FR3l8McH/pEZEGLhhR
# dp0ZCD/HZdqG+gHeMm9MHg/aOl+YUm+kmkAsg/2I6EpQ+QIAOCgp7JtgLr2u8wZu
# RCIen4nuSzqjN655vzgJdlDpzW33xebIOr2hcuPDwdRTCVGeIK909svJBF5rBPe/
# tmY4yVG3BNa/r7Pm9b+sWcHn9XXLQU1FpFtb/2v+1qjF7TSI6zh4wsLLB4cAH7pR
# e5rOBTtb/z2DzrrBxuKmyrzEYcQODJ6GA+4dYcknCncb1Kzd5bkwggZxMIIEWaAD
# AgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBD
# ZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3
# MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# JjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWl
# CgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/Fg
# iIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeR
# X4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/Xcf
# PfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogI
# Neh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB
# 5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvF
# M2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAP
# BgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjE
# MFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kv
# Y3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEF
# BQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8E
# gZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5t
# aWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcC
# AjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUA
# bgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Pr
# psz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOM
# zPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCv
# OA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v
# /rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99
# lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1kl
# D3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQ
# Hm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30
# uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp
# 25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HS
# xVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi6
# 2jbb01+P3nSISRKhggLOMIICNwIBATCB+KGB0KSBzTCByjELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJp
# Y2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046M0JCRC1FMzM4
# LUU5QTExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoB
# ATAHBgUrDgMCGgMVAOgiDOKq0gc6nIzXh1J3Xil4KqvooIGDMIGApH4wfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQACBQDkfWo9MCIY
# DzIwMjEwNjIzMTYwNzI1WhgPMjAyMTA2MjQxNjA3MjVaMHcwPQYKKwYBBAGEWQoE
# ATEvMC0wCgIFAOR9aj0CAQAwCgIBAAICIuwCAf8wBwIBAAICEcIwCgIFAOR+u70C
# AQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEK
# MAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQBbaxOvQBC7JB6XyVvDxZMIbYqP
# dIkUSm29JxBKUqCKprWdDZ8LZ75gRYYOBMB70isgA4b0f47yJyPOj7/zBwlVP0X2
# Vag6TZztdq2fFiyv6PjkY+MRWOKWEEs2wUcjfrxlUL1ynC2QGgVCKUrq0J2GXvj1
# IPReK7o/JFa9qsBDZDGCAw0wggMJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwAhMzAAABT2QudfZ6A1qDAAAAAAFPMA0GCWCGSAFlAwQCAQUAoIIB
# SjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEIG0z
# tZVqRBm4wLGI4pXmKWiJmeve+qGn3im7PL59WykzMIH6BgsqhkiG9w0BCRACLzGB
# 6jCB5zCB5DCBvQQgAGcmEPaCWKTAxnIhbRhyekPPqvh5bTCNEMXGwQC1NwIwgZgw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAU9kLnX2egNa
# gwAAAAABTzAiBCBVqs3TfdGx59G+eHpMF0QPGRef9TMKVqvNmWuRVa5L6zANBgkq
# hkiG9w0BAQsFAASCAQCZtjsH3l3nuwODKdN4dIrCF2gsxquKIJUG7Fc0MeSHlJvC
# JXjJr4hP4I2qu6ZTYJyXCW/blBW7qllQqK+qhrKiA2PwdDGvACDaMppBKBHkdnSr
# yE0E9+r4g6p7iIN17x85iJqmO/pyrGoC9Jn8GUXN0LDDWXlgcV8avMdQNSfnVjVO
# 6qEzzLPrFWdHuavtYuVxSRkKXF6VFN9OuQOCMRngPz1in8uI8GFURpGJo8jHdAx0
# FlsjGCxLDwqOm1yYP3qo/Ef+/Jet/AwSOcTEe0uRjdbCySjzlLc9RywoiL7ON4g9
# YMzs2T8zzQGoyYPy+3JbWhEkdcRbERjC27f80JPb
# SIG # End signature block
