==========
DISCLAIMER
==========

THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.

IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


================
IMPORTANT NOTICE 
================
 
This script is designed to collect information that will help Microsoft Customer Support Services (CSS) troubleshoot an issue you may be experiencing with Windows Virtual Desktop.

The collected data may contain Personally Identifiable Information (PII) and/or sensitive data, such as (but not limited to) IP addresses, PC names and user names.

The script will save the collected data in a subfolder and also compress the results into a ZIP file. The folder or ZIP file are not automatically sent to Microsoft. 

You can send the ZIP file to Microsoft CSS using a secure file transfer tool - Please discuss this with your support professional and also any concerns you may have. 

Find our privacy statement here: https://privacy.microsoft.com/en-us/privacy 


===================================
How to use WVD-Collect (v210407.14)
===================================

The script must be run with elevated permissions in order to collect all required data.
All collected data will be archived into a .zip file located in the same folder as the script itself.
Run the script on WVD host VMs and/or Windows based devices from where you connect to the WVD hosts, as needed.

When launched without any command line parameter, the script will ask you to select one of the following five scenarios:

	"Core" (suitable for most issues not involving Profiles or Teams)
		* Collects core troubleshooting data without including Profiles/FSLogix/OneDrive or Teams related data
		* Runs Diagnostics. Diagnostics results will be logged.

	"Extended" (suitable for all issues, including Profiles/FSLogix/OneDrive and Teams)
		* Collects all Core data
		* Collects Profiles/FSLogix/OneDrive related information, as available
		* Collects Microsoft Teams related information, as available
		* If the script is started with the "-NoTeams" and/or "-NoProfiles" command line parameter(s), these parameters will have priority
		* Runs Diagnostics. Diagnostics results will be logged

	"Extended with Profiles only" (suitable for all issues, excluding Teams)
​​​​​​​		* Collects Profiles/FSLogix/OneDrive related information, as available
		* If the script is started with the "-Extended -NoProfiles" command line parameters, these parameters will have priority
		* Runs Diagnostics. Diagnostics results will be logged

	"Extended with Teams only" (suitable for all issues, excluding Profiles/FSLogix/OneDrive)
		* Collects Teams related information, as available
		* If the script is started with the "-Extended -NoTeams" command line parameters, these parameter will have priority
		* Runs Diagnostics. Diagnostics results will be logged

	"DiagOnly"
​​​​​​​		* Skips all Core/Extended data collection and runs Diagnostics only (regardless if any other parameters have been specified)
		* Runs Diagnostics. Diagnostics results will be logged

The default scenario is "Core".​​​​​​​



Available command line parameters (to preselect the desired scenario)
---------------------------------------------------------------------

	"-Core" - Collects Core data + Runs Diagnostics

	"-Extended" - Collects all Core data + Extended (Profiles/FSLogix/OneDrive and Teams) data + Runs Diagnostics

	"-NoTeams" - Has to be used in combination with "-Extended". As a result, collects "Extended" data but without any Teams related data.

	"-NoProfiles" - Has to be used in combination with "-Extended". As a result, collects "Extended" data but without Profiles/FSLogix/OneDrive related data.

	"-DiagOnly" - The script will skip all data collection and will only run the diagnostics part (even if other parameters have been included).


Usage example with parameters:

To collect only Core data (excluding Profiles/FSLogix/OneDrive and Teams):
	.\WVD-Collect.ps1 -Core

To collect Core + Extended data (incl. Profiles/FSLogix/OneDrive and Teams):
	.\WVD-Collect.ps1 -Extended

To collect Core + Extended data (incl. Profiles/FSLogix/OneDrive, excluding Teams):
	.\WVD-Collect.ps1 -Extended -NoTeams

To collect Core + Extended data (incl. Teams, excluding Profiles/FSLogix/OneDrive):
	.\WVD-Collect.ps1 -Extended -NoProfiles


​​​​​​​If you are missing any of the data that the script should normally collect (see "Data being collected"), check the content of "*_WVD-Collect-Log.txt" and "*_WVD-Collect-Errors.txt" files for more information. Some data may not be present during data collection and thus not picked up by the script. This should be visible in one of the two text files.



PowerShell ExecutionPolicy
--------------------------

If the script does not start, complaining about execution restrictions, then in an elevated PowerShell console run:

	Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force -Scope Process

and verify with "Get-ExecutionPolicy -List" that no ExecutionPolicy with higher precedence is blocking execution of this script.
The script is digitally signed with a Microsoft Code Sign certificate.

After that run the WVD-Collect script again.


Once the script has started, p​​​lease read the "IMPORTANT NOTICE" message and confirm if you agree to continue with the data collection.

Depending on the amount of data that needs to be collected, the script may need run for a few minutes. Please wait until the script finishes collecting all the data.



====================
Data being collected
====================

The collected data is stored in a subfolder under the same folder where the script is located and at the end of the data collection, the results are archived into a .zip file. No data is automatically uploaded to Microsoft.

Data collected in the "Core" scenario:

• Log files
	o C:\Packages\Plugins\Microsoft.Powershell.DSC\<version>\Status\​​​​​​​
	o C:\Packages\Plugins\Microsoft.Compute.JsonADDomainExtension\<version>\Status\
	o C:\Packages\Plugins\Microsoft.EnterpriseCloud.Monitoring.MicrosoftMonitoringAgent\<version>\Status\
	o C:\Program Files\Microsoft RDInfra\AgentInstall.txt
	o C:\Program Files\Microsoft RDInfra\​GenevaInstall.txt
	o C:\Program Files\Microsoft RDInfra\​SXSStackInstall.txt
	o C:\Program Files\Microsoft RDInfra\WVDAgentManagerInstall.txt
	o C:\Windows\debug\NetSetup.log
	o C:\Windows\Temp\ScriptLog.log
	o C:\WindowsAzure\Logs\WaAppAgent.log
	o C:\WindowsAzure\Logs\MonitoringAgent.log
	o C:\WindowsAzure\Logs\Plugins\
• Geneva Scheduled Task information
• Local group membership information
	o Remote Desktop Users
	o Distributed COM Users
	o Offer Remote Assistance Helpers
• Registry keys
	o HKEY_CURRENT_USER\SOFTWARE\Microsoft\RdClientRadc
	o HKEY_CURRENT_USER\SOFTWARE\Microsoft\Remote Desktop​
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Azure\DSC
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDAgentBootLoader
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDInfraAgent
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDMonitoringAgent
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WVDAgentManager
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Terminal Server Client
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies
	o ​​​​​​​HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Terminal Server
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Cryptography
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Remote Assistance
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server​​
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\RdAgent
	o ​​​​​​​HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\RDAgentBootLoader
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WVDAgent
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WVDAgentManager
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\TermService
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\UmRdpService
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WinRM​​
• Event Logs
	o Application
	o Microsoft-Windows-CAPI2/Operational
	o Microsoft-Windows-DSC/Operational
	o Microsoft-Windows-PowerShell/Operational
	o Microsoft-Windows-RemoteAssistance/Admin
	o Microsoft-Windows-RemoteAssistance/Operational
	o Microsoft-Windows-RemoteDesktopServices
	o Microsoft-Windows-RemoteDesktopServices-RdpCoreCDV/Admin
	o Microsoft-Windows-RemoteDesktopServices-RdpCoreCDV/Operational
	o Microsoft-Windows-RemoteDesktopServices-RdpCoreTS/Admin
	o Microsoft-Windows-RemoteDesktopServices-RdpCoreTS/Operational
	o Microsoft-Windows-TerminalServices-LocalSessionManager/Admin
	o Microsoft-Windows-TerminalServices-LocalSessionManager/Operational
	o Microsoft-Windows-TerminalServices-PnPDevices/Admin
	o Microsoft-Windows-TerminalServices-PnPDevices/Operational
	o Microsoft-Windows-TerminalServices-RemoteConnectionManager/Admin
	o Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational
	o Microsoft-Windows-WinINet-Config/ProxyConfigChanged
	o Microsoft-Windows-WinRM/Operational
	o Microsoft-WindowsAzure-Diagnostics/Bootstrapper
	o Microsoft-WindowsAzure-Diagnostics/GuestAgent
	o Microsoft-WindowsAzure-Diagnostics/Heartbeat
	o Microsoft-WindowsAzure-Diagnostics/Runtime
	o Microsoft-WindowsAzure-Status/GuestAgent
	o Microsoft-WindowsAzure-Status/Plugins
	o Security
	o System
• "gpresult /h" and "gpresult /r /v" output
• "fltmc filters" output
• Details of the running processes and services
• Networking information (firewall rules, ipconfig /all, profiles, netstat -anob, proxy configuration)
• "Qwinsta /counter" output
• PowerShell version
• "Get-Hotfix" output
• "Get-DscConfiguration" and "Get-DscConfigurationStatus" output
• File versions of the currently running binaries
• File information about the WVD desktop client binaries ("msrdc.exe" and "msrdcw.exe")
• File versions of key binaries:
	o Windows\System32\*.dll
	o Windows\System32\*.exe
	o Windows\System32\*.sys
	o Windows\SysWOW64\*.dll
	o Windows\SysWOW64\*.exe
	o Windows\System32\drivers\*.sys
• Basic system information
• .NET Framework information
• Msinfo32 output
• WinRM configuration information
• Certificate My store information
• Certificate thumbprint information
• DxDiag output in .txt format with no WHQL check
• "dsregcmd /status" output
• The content of the "C:\Users\%username%\AppData\Local\Temp\DiagOutputDir\RdClientAutoTrace" folder (available on devices used as source clients to connect to WVD hosts), containing:
	o WVD remote desktop client connection ETL traces
	o WVD remote desktop client application ETL traces
	o WVD remote desktop client upgrade log (MSI.log)
• Convert existing .tsf files on WVD hosts from under "C:\Windows\System32\config\systemprofile\AppData\Roaming\Microsoft\Monitoring\Tables" into .csv files and collect the resulting .csv files
• Basic Diagnostics information (see below for more details)


Data collected in the "Extended" scenarios:

• FSLogix ​log files (will not be collected when "-NoProfiles" is used)
	o C:\ProgramData\FSLogix\Logs
• Profiles registry keys (will not be collected when "-NoProfiles" is used)
	o HKEY_CURRENT_USER\SOFTWARE\Microsoft\Office​
	o HKEY_CURRENT_USER\SOFTWARE\Microsoft\OneDrive
	o HKEY_CURRENT_USER\SOFTWARE\Policies\Microsoft\Office
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\OneDrive
	o HKEY_LOCAL_MACHINE\SOFTWARE\FSLogix
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Search
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\FSLogix
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Exclusions\Extensions
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes
• Event Logs (will not be collected when "-NoProfiles" is used)
	o Microsoft-FSLogix-Apps/Admin
	o Microsoft-FSLogix-Apps/Operational
	o Microsoft-Windows-SMBClient/Connectivity
	o Microsoft-Windows-SMBClient/Operational
	o Microsoft-Windows-SMBClient/Security
	o Microsoft-Windows-SMBServer/Connectivity
	o Microsoft-Windows-SMBServer/Operational
	o Microsoft-Windows-SMBServer/Security
	o Microsoft-Windows-User Profile Service/Operational
	o Microsoft-Windows-VHDMP/Operational
• FSLogix tool output (will not be collected when "-NoProfiles" is used)
	o frx list-redirects
	o frx list-rules
	o frx version
• Teams ​log files (will not be collected when "-NoTeams" is used)
	o %appdata%\Microsoft\Teams\logs.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME_calling.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME_cdl.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME_cdlWorker.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME_chatListData.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME_sync.txt
	o %userprofile%\Downloads\MSTeams Diagnostics Log DATE_TIME_vdi_partner.txt
Teams registry keys (will not be collected when "-NoTeams" is used)
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Teams
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\RDWebRTCSvc



========
WVD-Diag
========

WVD-Collect also performs diagnostics for some common known issues, regardless of the selected scenario.
Based on your requirements, you may want to skip specific data collection or run diagnostics only. See the scenario descriptions above.
New diagnostics checks may be added in each new release, so make sure to always use the latest version of the script.​​​​​​​

Important Notes:
"Diagnostics" is not a replacement of a full data analysis. It is only meant to give you basic diagnostics of some common scenarios and to ease further troubleshooting. Depending on the scenario, further data collection and analysis will be needed.

Version 200406.12 of the script can perform the following diagnostics:

• Brief check of the system the script is running on (from WVD point of view): FQDN, OS, OS Build
	o Check if the VM is part of a WVD host pool: SessionHostPool name, Ring, Geography
	o Check if the running OS is supported when the VM is part of a WVD host pool
• Check the status of key services: RdAgent, RDAgentBootLoader, WVDAgent (Win7 only), WVDAgentManager (Win7 only), TermService, SessionEnv, UmRdpService, AppReadiness, AppXSvc, WinRM, frxsvc, frxdrv, frxccds, OneDrive Updater Service, msiserver (Windows Installer)
• Check for current and previous WVD Agent and Stack versions and their installation dates (Windows 10 and Server OS hosts)
• Check for all available RD listeners and their configuration: fEnableWinStation, fReverseConnectMode, ReverseConnectionListener
• Check for known WVD agent issues:
​​​​​​​	o "INVALID_REGISTRATION_TOKEN" (Event 3277)
	o "INVALID_FORM" (Event 3277)
	o "InstallationHealthCheckFailedException" (Event 3277)
	o "ENDPOINT_NOT_FOUND" (Event 3277)
	o "InstallMsiException" (Event 3277)
	o "DownloadMsiException" (Event 3277)
	o "Transport received an exception" (Event 3019)
	o "RD Gateway Url" (Event 3703)
	o "MissingMethodException" (Event 3389)
• Check for WinHTTP proxy settings
• Check the availability and value of the reg key responsible for the 'SSL Cipher Suite Order' policy for scenarios where users cannot connect with a message containing 'security package error' or 'no available resources'
• Check if the Remote Desktop Session Host role is installed on the VM when running a Server OS
• Check the availability and value of the "CleanupInvalidSessions" registry key when FSLogix is present on the system
• Check for the presence of the recommended Windows Defender Antivirus exclusion values when FSLogix is present on the system
• Check OneDrive configuration/requirements when FSLogix is present on the system
• Check media optimization configuration for Teams when Teams is present on the system
• Check the availability and value of the reg key: 'DeleteUserAppContainersOnLogoff' for firewall rules bloating scenarios
• Check WinRM configuration / requirements
	o ​​​​​​​Presence of "WinRMRemoteWMIUsers__" group
	o IPv4Filter and IPv6Filter values
	o Presence of firewall rules for ports 5985 and 5986
• Check for RDP ShortPath configuration (Windows 10 and Server OS hosts)

The script generates a *_WVD-Diag.txt output file with the results of the above checks.


==========
Tool Owner
==========
Robert Klemencz @ Microsoft Customer Service and Support
If you have any feedback about the tool or want to report any issues with it, please reach out to me (Robert Klemencz) at robert.klemencz@microsoft.com


