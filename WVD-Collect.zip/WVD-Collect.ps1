﻿# =====================================================
# DISCLAIMER:
#
# THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# =====================================================


<#
        .SYNOPSIS
        Simplify data collection for troubleshooting Windows Virtual Desktop issues and a convenient method for submitting and following quick & easy action plans.
        
        .DESCRIPTION
        This script is designed to collect information that will help Microsoft Customer Support Services (CSS) troubleshoot an issue you may be experiencing with Windows Virtual Desktop.
        The collected data may contain Personally Identifiable Information (PII) and/or sensitive data, such as (but not limited to) IP addresses; PC names; and user names.
        The script will save the collected data in a folder and also compress the results into a ZIP file, both in the same location from where the script has been launched.
        This folder and its contents or the ZIP file are not automatically sent to Microsoft.
        You can send the ZIP file to Microsoft CSS using a secure file transfer tool - Please discuss this with your support professional and also any concerns you may have.
        Find our privacy statement here: https://privacy.microsoft.com/en-us/privacy
        
        Run 'Get-Help WVD-Collect.ps1 -Full' for more details.

        USAGE SUMMARY:

        The script must be run with elevated permissions in order to collect all required data. 
        It works on any Windows client and Windows server OS supporting at least PowerShell 5.1.

        Run the script on WVD host VMs and/or on Windows based devices from where you connect to the WVD hosts, as needed.

        When launched without any command line parameter, the script will collect both "Basic" and "Extended" troubleshooting data and also run basic diagnostics at the end. 
       
        .PARAMETER Core
        This parameter will collect only basic WVD data (without Profiles/FSLogix/OneDrive and without Teams related information). Basic diagnostics will also run at the end.

        .PARAMETER Extended
        This parameter will collect all the basic WVD data, plus Profiles/FSLogix/OneDrive and Teams related information. Basic diagnostics will also run at the end.
        When the tool is launched with both "-Core" and "-Extended" parameters at the same time, the higher ("-Extended") parameter will be applied.

        .PARAMETER DiagOnly
        This parameter will skip collecting troubleshooting data (even if any other parameters are specificed) and will only perform basic diagnostics. The results of the diagnostics will be stored in the 'WVD-Diag.txt' file.
        
        .PARAMETER NoTeams
        Use this parameter if you want to prevent Microsoft Teams related data collection when running the "Extended" scenario. The "Extended" scenario will be limited to Profiles/FSLogix/OneDrive data collection. This does not apply to the "Core" and "DiagOnly" scenarios.
        
        .PARAMETER NoProfiles
        Use this parameter if you want to prevent Profiles/FSLogix/OneDrive related data collection when running the "Extended" scenario. The "Extended" scenario will be limited to Microsoft Teams data collection. This does not apply to the "Core" and "DiagOnly" scenarios.

        .OUTPUTS
        By default, all collected data are stored in a subfolder in the same location from where the tool was launched.
#>


param (
    [switch]$Core = $false,
    [switch]$Extended = $false,
    [switch]$DiagOnly = $false,
    [switch]$NoTeams = $false,
    [switch]$NoProfiles = $false
)

$version = "210407.14"
# Author: Robert Klemencz @ Microsoft Customer Service and Support


$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$myWindowsPrincipal = new-object System.Security.Principal.WindowsPrincipal($myWindowsID)
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator
if (-not $myWindowsPrincipal.IsInRole($adminRole)) {
  Write-Host "This script needs to be run as Administrator" -ForegroundColor Yellow
  exit
}


#region ####################### Initializing ########################

$LogRoot = Split-Path (Get-Variable MyInvocation).Value.MyCommand.Path
$LogFolder = "WVD-Results-" + $env:computername +"-" + $(get-date -f yyyyMMdd_HHmmss)
$LogDir = "$LogRoot\$LogFolder\"

New-Item -itemtype directory -path $LogDir | Out-Null

  $BasicLogFolder = "$LogDir$env:computername" + "_"
  $CertLogFolder = $BasicLogFolder + "Certificates\"
  $EventLogFolder = $BasicLogFolder + "EventLogs\"
  $LogFileLogFolder = $BasicLogFolder + "LogFiles\"
  $NetLogFolder = $BasicLogFolder + "Networking\"
  $RegLogFolder = $BasicLogFolder + "RegistryKeys\"
  $SchedLogFolder = $BasicLogFolder + "ScheduledTasks\"
  $SysInfoLogFolder = $BasicLogFolder + "SystemInfo\"
  $RDCTraceFolder = $BasicLogFolder + "RDClientAutoTrace\"
  $MonTablesFolder = $BasicLogFolder + "MonitoringTables\"
  
  $FSLogixLogFolder = $BasicLogFolder + "FSLogix\"
  $TeamsLogFolder = $BasicLogFolder + "Teams\"

  $LogFile = $env:computername + "_"

$ErrorLogFile = $BasicLogFolder + "WVD-Collect-Error.txt"
$OutputLogFile = $BasicLogFolder + "WVD-Collect-Log.txt"

$LogLevel = @{
  'Normal' = 0
  'Info' = 1
  'Warning' = 2
  'Error' = 3
  'ErrorLogFileOnly' = 4
  'WarnLogFileOnly' = 5
  'Archive' = 6
  'DiagFileOnly' = 7
}

$ver = (Get-CimInstance Win32_OperatingSystem).Caption
$fqdn = [System.Net.Dns]::GetHostByName(($env:computerName)).HostName

#endregion Initializing


#region ####################### Functions ########################

#region Internal functions

Function LogMessage {
  param( [ValidateNotNullOrEmpty()][int] $Level, [ValidateNotNullOrEmpty()][string] $Message, [ValidateNotNullOrEmpty()][string] $Color)
  
  If(!$Level){
    $Level = $LogLevel.Normal
  }

  $LogMessage = (get-date).ToString("yyyyMMdd HH:mm:ss.fff") + " " + $Message

  Switch($Level){
    '0'{ # Normal
        $MessageColor = 'White'
        $LogConsole = $True
    }
    '1'{ # Info console message
        $MessageColor = 'Yellow'
        $LogConsole = $True
    }
    '2'{ # Warning
        $MessageColor = 'Magenta'
        $LogConsole = $True
    }
    '3'{ # Error
        $MessageColor = 'Red'
        $LogConsole = $False
    }
    '4'{ # ErrorLogFileOnly
        $LogConsole = $False
    }
    '5'{ # WarnLogFileOnly
        $LogConsole = $False
    }
  }

  # If color is specifed, overwrite it.
  If(($Color) -and $Color.Length -ne 0){
    $MessageColor = $Color
  }

  # In case of Warning/Error, log to error file
  If($Level -eq $LogLevel.Error -or $Level -eq $LogLevel.Warning -or $Level -eq $LogLevel.ErrorLogFileOnly -or $Level -eq $LogLevel.WarnLogFileOnly){
   
    If(!(Test-Path -Path $LogDir)){
      CreateLogFolder $LogDir
    }
    $LogMessage | Out-File -Append $ErrorLogFile
  }

  If($LogConsole){
    Write-Host $LogMessage -ForegroundColor $MessageColor
    $LogMessage | Out-File -Append $OutputLogFile
  }
}

Function LogDiag {
  param( [ValidateNotNullOrEmpty()][int] $Level, [ValidateNotNullOrEmpty()][string] $Message, [ValidateNotNullOrEmpty()][string] $Color)
  
  If(!$Level){
    $Level = $LogLevel.Normal
  }

  $LogMessage = (get-date).ToString("yyyyMMdd HH:mm:ss.fff") + " " + $Message

  Switch($Level){
    '0'{ # Normal
        $MessageColor = 'White'
        $LogConsole = $False
    }
    '1'{ # Info console message
        $MessageColor = 'Yellow'
        $LogConsole = $True
    }
    '2'{ # Warning
        $MessageColor = 'Magenta'
        $LogConsole = $True
    }
    '3'{ # Error
        $MessageColor = 'Red'
        $LogConsole = $True
    }
    '7'{ # Info only
        $LogConsole = $False
    }
  }

  # If color is specifed, overwrite it.
  If((!$Color) -and $Color.Length -ne 0){
    $MessageColor = $Color
  }
  
    If(!(Test-Path -Path $LogDir)){
      CreateLogFolder $LogDir
    }

    If($LogConsole){
        Write-Host $LogMessage -ForegroundColor $MessageColor
        $LogMessage | Out-File -Append $DiagFile
    } else {
        $LogMessage | Out-File -Append $DiagFile 
    }
}

Function CreateLogFolder {
  Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFolder)
    
  If(!(test-path -Path $LogFolder)){
      Write-Host((get-date).ToString("yyyyMMdd HH:mm:ss.fff") + " Creating log folder $LogFolder") -ForegroundColor Yellow
      (get-date).ToString("yyyyMMdd HH:mm:ss.fff") + " Creating log folder $LogFolder" | Out-File -Append $OutputLogFile
      New-Item $LogFolder -ItemType Directory -ErrorAction Stop | Out-Null
  }Else{
      LogMessage "$LogFolder already exist."
  }
  
}

Function CleanUpandExit{
  If($fQuickEditCodeExist){
      [DisableConsoleQuickEdit]::SetQuickEdit($False) | Out-Null
  }
  Exit
}

Function RunCommands{
  param(
      [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$LogPrefix,
      [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String[]]$CmdletArray,
      [parameter(Mandatory=$true)][Bool]$ThrowException,
      [parameter(Mandatory=$true)][Bool]$ShowMessage
  )

  ForEach($CommandLine in $CmdletArray){
      $tmpMsg = $CommandLine -replace "\| Out-File.*$",""
      $tmpMsg = $tmpMsg -replace "\| Out-Null.*$",""
      $tmpMsg = $tmpMsg -replace "\-ErrorAction Stop",""
      $tmpMsg = $tmpMsg -replace "\-ErrorAction SilentlyContinue",""
      $CmdlineForDisplayMessage = $tmpMsg -replace "2>&1",""
      Try{
          If($ShowMessage){
              LogMessage $LogLevel.Normal ("[$LogPrefix] Running $CmdlineForDisplayMessage")
          }
          # Run actual command here.
          $LASTEXITCODE = 0
          
          Invoke-Expression -Command $CommandLine -ErrorAction Stop | Out-Null 
          
          #write-host $CommandLine
          #(get-date).ToString("yyyyMMdd HH:mm:ss.fff") + " ... " + $CommandLine | Out-File -Append $OutputLogFile
          If($LASTEXITCODE -ne 0){
              Throw("An error happened during running `'$CommandLine` " + '(Error=0x' + [Convert]::ToString($LASTEXITCODE,16) + ')')
          }
      }Catch{
          If($ThrowException){
              Throw $_   # Leave the error handling to upper function.
          }Else{
              LogException ("An error happened in $CommandLine") $_ $fErrorLogFileOnly
              Continue
          }
      }
  }
}

Function LogException{
  param(
      [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$Message,
      [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][System.Management.Automation.ErrorRecord]$ErrObj,
      [Bool]$fErrorLogFileOnly
  )
  $ErrorCode = "0x" + [Convert]::ToString($ErrObj.Exception.HResult,16)
  $ExternalException = [System.ComponentModel.Win32Exception]$ErrObj.Exception.HResult
  $ErrorMessage = $Message + "`n" `
      + "Command/Function: " + $ErrObj.CategoryInfo.Activity + " failed with $ErrorCode => " + $ExternalException.Message + "`n" `
      + $ErrObj.CategoryInfo.Reason + ": " + $ErrObj.Exception.Message + "`n" `
      + "ScriptStack:" + "`n" `
      + $ErrObj.ScriptStackTrace
  If($fErrorLogFileOnly){
      LogMessage $LogLevel.ErrorLogFileOnly $ErrorMessage
  }Else{
      LogMessage $LogLevel.Error $ErrorMessage
  }
}

Function GetPackagesLogFiles {
  Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFilePath, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFolderID)

  if (Test-path -path $LogFilePath) {

    $verfolder = get-ChildItem $LogFilePath -recurse | Foreach-Object {If ($_.psiscontainer) {$_.fullname}} | Select-Object -first 1  
    $filepath = $verfolder + "\Status\"

    if (Test-path -path $filepath) {
      #$filetarget = $LogFileLogFolder + "\" + $LogFolderID
      Copy-Item $filepath "$LogFileLogFolder\$LogFolderID" -Recurse -ErrorAction Continue 2>&1 | Out-Null
    } else {
      LogMessage $LogLevel.Error "[$LogPrefix] '$LogFolderID' log not found."
    }

  } else {
    LogMessage $LogLevel.Error "[$LogPrefix] '$LogFilePath' folder not found."
  }
}

Function GetWVDLogFiles {
  Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFilePath, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFileID)

  $LogFile = $LogFileLogFolder + $env:computername + "_log_" + $LogFileID + ".txt"

  if (Test-path -path "$LogFilePath") {  
    Copy-Item $LogFilePath $LogFile -ErrorAction Continue 2>&1 | Out-Null
  } else {
    LogMessage $LogLevel.Error "[$LogPrefix] '$LogFilePath' log not found."
  }
}

Function GetRegKeys {
  Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegRoot, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegPath, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegFile)
  
  $RegOut = $RegLogFolder + $env:computername + "_reg_" + $RegFile + ".txt"
  $RegFullPath = $RegRoot + "\" + $RegPath
  $RegTest = $RegRoot + ":\" + $RegPath
  
  if (Test-path $RegTest) {  
    reg export $RegFullPath $RegOut | Out-Null
  } else {
    LogMessage $LogLevel.Error "[$LogPrefix] Registry Key '$RegFullPath' not found."
  }
}

Function GetEventLogs {
  Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$EventSource, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$EventFile)
  
  $EventOut = $EventLogFolder + $env:computername + "_evt_" + $EventFile + ".evtx"
  
  if (Get-WinEvent -ListLog $EventSource -ErrorAction SilentlyContinue) {
    wevtutil epl $EventSource $EventOut
  } else {
    LogMessage $LogLevel.Error "[$LogPrefix] Event log '$EventSource' not found."
  }
}

Function GetRdClientAutoTrace {

    $MSRDCfolder = $env:USERPROFILE + '\AppData\Local\Temp\DiagOutputDir\RdClientAutoTrace\*'
        
    if (Test-path -path $MSRDCfolder) {
        Try {
            CreateLogFolder $RDCTraceFolder
        } Catch {
            LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
            Return
        }

        Copy-Item $MSRDCfolder $RDCTraceFolder -Recurse -ErrorAction Continue 2>&1 | Out-Null         
    } else {
        LogMessage $LogLevel.Error "[$LogPrefix] '$MSRDCfolder' folder not found."
    }
}

function CloseMSRDC {
    $msrdc = Get-Process msrdc -ErrorAction SilentlyContinue

    if ($msrdc) {
        Write-host "The WVD desktop client (MSRDC) has been detected as running."
        Write-host "To collect the most recent WVD Desktop Client specific ETL traces, MSRDC.exe must be closed first.
        "
        $confirm = Read-Host ("Do you want to close the MSRDC.exe now? This will disconnect all outgoing active WVD connections on this client! [Y/N]")
        
        if ($confirm.ToLower() -ne "y") {
            Write-host
            LogMessage $LogLevel.Warning ("[NOTE] MSRDC.exe has not been closed. The most recent ETL traces will NOT be available for troubleshooting! Continuing data collection.")
        } else {
            Write-Host
            LogMessage $LogLevel.Info "Closing MSRDC.exe ..."
            $msrdc.CloseMainWindow() | Out-Null
            Start-Sleep 5
            if (!$msrdc.HasExited) {
                $msrdc | Stop-Process -Force
            }
            LogMessage $LogLevel.Info "MSRDC.exe has been closed. Waiting 10 seconds for the latest trace file(s) to get saved before continuing with the data collection."
            Start-Sleep 10
        }
        Write-Host
    }    
}

Function GetMonTables {

    $MTfolder = 'C:\Windows\System32\config\systemprofile\AppData\Roaming\Microsoft\Monitoring\Tables'
        
    if (Test-path -path $MTfolder) {
        Try {
            CreateLogFolder $MonTablesFolder
        } Catch {
            LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
            Return
        }

        Switch(Get-ChildItem -Path "C:\Program Files\Microsoft RDInfra\") {
                {$_.Name -match "RDMonitoringAgent"} {
                    $convertpath = "C:\Program Files\Microsoft RDInfra\" + $_.Name + "\Agent\table2csv.exe"
                }
        }

        Switch(Get-ChildItem -Path $MTfolder) {
                {($_.Name -notmatch "00000") -and ($_.Name -match ".tsf")} {
                    $monfile = $MTfolder + "\" + $_.name
                    cmd /c $convertpath -path $MonTablesFolder $monfile 2>&1 | Out-Null
                }
        }
    } else {
        LogMessage $LogLevel.Error "[$LogPrefix] Monitoring\Tables folder not found."
    }
}

Function GetWinRMConfig {

    $diagfile = $SysInfoLogFolder + $LogFile + "WinRM-Config.txt"

    if ((get-service -name WinRM).status -eq "Running") {
        $config = Get-ChildItem WSMan:\localhost\ -Recurse -ErrorAction Continue 2>&1 | Out-Null
        if (!$config) {
          LogMessage $LogLevel.Error ("[$LogPrefix] Cannot connect to localhost, trying with FQDN " + $fqdn)
          Connect-WSMan -ComputerName $fqdn -ErrorAction Continue 2>&1 | Out-Null
          $config = Get-ChildItem WSMan:\$fqdn -Recurse -ErrorAction Continue 2>&1 | Out-Null
          Disconnect-WSMan -ComputerName $fqdn -ErrorAction Continue 2>&1 | Out-Null
        }

        $config | out-file -Append $diagfile
            
        winrm get winrm/config 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "WinRM-Config.txt")
        winrm e winrm/config/listener 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "WinRM-Config.txt")
    } else {
        LogMessage $LogLevel.Error ("[$LogPrefix] WinRM service is not running. Skipping collection of WinRM configuration data.")
    }
}

Function GetFSLogixLogFiles {
  Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFilePath)

  if (Test-path -path "$LogFilePath") {  
    Copy-Item $LogFilePath $FSLogixLogFolder -Recurse -ErrorAction Continue 2>&1 | Out-Null
  } else {
    LogMessage $LogLevel.Error "[$LogPrefix] '$LogFilePath' folder not found."
  }
}

Function GetTeamsLogs {

    $TeamsLogPath = $env:userprofile + "\AppData\Roaming\Microsoft\Teams\logs.txt"
    if(Test-Path $TeamsLogPath) {

        Try {
            CreateLogFolder $TeamsLogFolder
        } Catch {
            LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
            Return
        }

        Copy-Item $TeamsLogPath ($TeamsLogFolder + $LogFile + "Teams_logs.txt") -ErrorAction Continue 2>&1 | Out-Null
    } else {
        LogMessage $LogLevel.Error "[$LogPrefix] Teams logs not found."
    }
    
    $TeamsDiagFolder = $env:userprofile + "\Downloads\MSTeams*"    
    if (Test-path -path $TeamsDiagFolder) {                     

        Try {
            CreateLogFolder $TeamsLogFolder
        } Catch {
            LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
            Return
        }

            Switch(Get-ChildItem -Path $TeamsDiagFolder) {
                {$_.Name -match "MSTeams Diagnostics Log"} {
                    $diagfile = $TeamsDiagFolder + "\" + $_.Name
                    Copy-Item $diagfile ($TeamsLogFolder + $LogFile + $_.Name) -ErrorAction Continue 2>&1 | Out-Null
                    }
                }
    } else {
        LogMessage $LogLevel.Error "[$LogPrefix] Teams Diagnostics logs not found."
    }
}

Function GetStore($store) {
  $certlist = Get-ChildItem ("Cert:\LocalMachine\" + $store)

  foreach ($cert in $certlist) {
    $EKU = ""
    foreach ($item in $cert.EnhancedKeyUsageList) {
      if ($item.FriendlyName) {
        $EKU += $item.FriendlyName + " / "
      } else {
        $EKU += $item.ObjectId + " / "
      }
    }

    $row = $tbcert.NewRow()

    foreach ($ext in $cert.Extensions) {
      if ($ext.oid.value -eq "2.5.29.14") {
        $row.SubjectKeyIdentifier = $ext.SubjectKeyIdentifier.ToLower()
      }
      if (($ext.oid.value -eq "2.5.29.35") -or ($ext.oid.value -eq "2.5.29.1")) { 
        $asn = New-Object Security.Cryptography.AsnEncodedData ($ext.oid,$ext.RawData)
        $aki = $asn.Format($true).ToString().Replace(" ","")
        $aki = (($aki -split '\n')[0]).Replace("KeyID=","").Trim()
        $row.AuthorityKeyIdentifier = $aki
      }
    }
    if ($EKU) {$EKU = $eku.Substring(0, $eku.Length-3)} 
    $row.Store = $store
    $row.Thumbprint = $cert.Thumbprint.ToLower()
    $row.Subject = $cert.Subject
    $row.Issuer = $cert.Issuer
    $row.NotAfter = $cert.NotAfter
    $row.EnhancedKeyUsage = $EKU
    $row.SerialNumber = $cert.SerialNumber.ToLower()
    $tbcert.Rows.Add($row)
  } 
}


Add-Type -MemberDefinition @"
[DllImport("netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
public static extern uint NetApiBufferFree(IntPtr Buffer);
[DllImport("netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
public static extern int NetGetJoinInformation(
  string server,
  out IntPtr NameBuffer,
  out int BufferType);
"@ -Namespace Win32Api -Name NetApi32

Function GetNBDomainName {
  $pNameBuffer = [IntPtr]::Zero
  $joinStatus = 0
  $apiResult = [Win32Api.NetApi32]::NetGetJoinInformation(
    $null,               # lpServer
    [Ref] $pNameBuffer,  # lpNameBuffer
    [Ref] $joinStatus    # BufferType
  )
  if ( $apiResult -eq 0 ) {
    [Runtime.InteropServices.Marshal]::PtrToStringAuto($pNameBuffer)
    [Void] [Win32Api.NetApi32]::NetApiBufferFree($pNameBuffer)
  }
}

Function FileVersion {
  param(
    [string] $FilePath,
    [bool] $Log = $false
  )
  if (Test-Path -Path $FilePath) {
    $fileobj = Get-item $FilePath
    $filever = $fileobj.VersionInfo.FileMajorPart.ToString() + "." + $fileobj.VersionInfo.FileMinorPart.ToString() + "." + $fileobj.VersionInfo.FileBuildPart.ToString() + "." + $fileobj.VersionInfo.FilePrivatepart.ToString()

    if ($log) {
      ($FilePath + "," + $filever + "," + $fileobj.CreationTime.ToString("yyyyMMdd HH:mm:ss")) 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "ver_KeyFileVersions.csv")
    }
    return $filever | Out-Null
  } else {
    return ""
  }
}

#endregion Internal functions


#region Diag functions

function Test-RegistryValue {
    param (
        [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()]$Path, [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()]$Value)

    try {
        $trv = Get-ItemProperty -Path $Path -ErrorAction Stop | Select-Object -ExpandProperty $Value -ErrorAction Stop
        if ($trv -or ($trv -eq 0)) { 
            return $true 
        } else { 
            return $false
        }
    }
    catch {
        return $false
    }
}

Function DiagWVDAgentIssues {
  Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogName, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogID, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$Message)
  
  If (!(Get-WinEvent -FilterHashtable @{logname=$LogName; id=$LogID} -ErrorAction SilentlyContinue | where-object { $_.Message -like '*' + $Message + '*' })) {
      LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] No '$Message' issue found."
  } else {
      LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] One or more events $LogID with '$Message' have been found. You might have issues with registering this VM to the host pool or connecting to it through the WVD services. Please review: https://docs.microsoft.com/en-us/azure/virtual-desktop/troubleshoot-agent for more details."
      Get-WinEvent -FilterHashtable @{logname=$LogName; id=$LogID} -ErrorAction SilentlyContinue | where-object { $_.Message -like '*' + $Message + '*' }
  }
}

Function CheckRegKeyValue {
Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegPath, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegKey, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegValue)

        $global:regok = $null

        if (test-registryvalue -path $RegPath -value $RegKey) {

            (Get-ItemProperty -path $RegPath).PSChildName | foreach-object -process {  
            
                $key = Get-ItemPropertyValue -Path $RegPath -name $RegKey
    
                if ($key -eq $RegValue) {    
                    $global:regok = 1
                    LogDiag $LogLevel.Normal ("[$LogPrefix] Registry key '$RegPath$RegKey' exists and has the expected value of: " + $key)
                } 
                else {
                    $global:regok = 2
                    LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] Registry key '$RegPath$RegKey' exists and has a value of '" + $key + "' but this is not the expected value. (The expected value is: " + $RegValue + ")")
                }
            }
        }
        else {
            $global:regok = 0
            LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] Registry key '$RegPath$RegKey' not found.")
        }

}

#endregion Diag functions


#region Main functions

<#
.SYNOPSIS
    Collects 'Core' WVD troubleshooting data
.DESCRIPTION
    CollectUEX_WVDBasicLog (no parameters)
.NOTES
    Date: 2021.04.06
#>
Function CollectUEX_WVDBasicLog{

    #Collecting RDS/WVD information
    " " | Out-File -Append $OutputLogFile
    LogMessage $LogLevel.Info ('Collecting RDS/WVD information')
    Try {
        CreateLogFolder $LogFileLogFolder
        CreateLogFolder $NetLogFolder
        CreateLogFolder $SysInfoLogFolder
    } Catch {
        LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
        Return
    }
    $LogPrefix = "WVD" 
    $Commands = @( 
        "GetPackagesLogFiles 'c:\Packages\Plugins\microsoft.powershell.dsc' 'Microsoft.PowerShell.DSC'"
        "GetPackagesLogFiles 'c:\Packages\Plugins\Microsoft.EnterpriseCloud.Monitoring.MicrosoftMonitoringAgent' 'Microsoft.EnterpriseCloud.Monitoring.MicrosoftMonitoringAgent'"
        "GetPackagesLogFiles 'c:\Packages\Plugins\Microsoft.Compute.JsonADDomainExtension' 'Microsoft.Compute.JsonADDomainExtension'"
        "GetWVDLogFiles 'C:\WindowsAzure\Logs\WaAppAgent.log' WaAppAgent"
        "GetWVDLogFiles 'C:\WindowsAzure\Logs\MonitoringAgent.log' MonitoringAgent"
        "GetWVDLogFiles 'C:\Windows\debug\NetSetup.LOG' NetSetup"
        "GetWVDLogFiles 'C:\Program Files\Microsoft RDInfra\AgentInstall.txt' AgentInstall"
        "GetWVDLogFiles 'C:\Program Files\Microsoft RDInfra\GenevaInstall.txt' GenevaInstall"
        "GetWVDLogFiles 'C:\Program Files\Microsoft RDInfra\SXSStackInstall.txt' SXSStackInstall"
        "GetWVDLogFiles 'C:\Windows\Temp\ScriptLog.log' ScriptLog"
        "GetRdClientAutoTrace"
        "GetMonTables"
        "qwinsta /counter 2>&1 | Out-File -Append " + $NetLogFolder + $LogFile + "qwinsta.txt"
        "dsregcmd /status 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFile + "dsregcmd.txt"
        "dxdiag /whql:off /t " + $SysInfoLogFolder + $LogFile + "DxDiag.txt"
    )
    RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True

    if ($ver -like "*Windows 7*") {
        $Commands = @( 
            "GetWVDLogFiles 'C:\Program Files\Microsoft RDInfra\WVDAgentManagerInstall.txt' WVDAgentManagerInstall"
        )
        RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True
    }

    LogMessage $LogLevel.Normal ("[$LogPrefix] Collecting 'C:\WindowsAzure\Logs\Plugins\*'")
    if (Test-path -path 'C:\WindowsAzure\Logs\Plugins') {
        Copy-Item 'C:\WindowsAzure\Logs\Plugins\*' $LogFileLogFolder -Recurse -ErrorAction Continue 2>>$ErrorLogFile
    } else {
        LogMessage $LogLevel.Error "[$LogPrefix] WindowsAzure Plugins logs not found."
    }

    if ([ADSI]::Exists("WinNT://localhost/Remote Desktop Users")) {
        $Commands = @(
            "net localgroup 'Remote Desktop Users' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFile + "LocalGroupsMembership.txt"
        )
        RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True
    } else {
        LogMessage $LogLevel.Error "[$LogPrefix] 'Remote Desktop Users' group not found."
    }

    if ([ADSI]::Exists("WinNT://localhost/Offer Remote Assistance Helpers")) {
        $Commands = @(
            "net localgroup 'Offer Remote Assistance Helpers' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFile + "LocalGroupsMembership.txt"
        )
        RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True
    } else {
        LogMessage $LogLevel.Error "[$LogPrefix] 'Offer Remote Assistance Helpers' group not found."
    }

    if ([ADSI]::Exists("WinNT://localhost/Distributed COM Users")) {
        $Commands = @(
            "net localgroup 'Distributed COM Users' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFile + "LocalGroupsMembership.txt"
        )
        RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True
    } else {
        LogMessage $LogLevel.Error "[$LogPrefix] 'Distributed COM Users' group not found."
    }

    #Collecting Geneva Scheduled task
    " " | Out-File -Append $OutputLogFile
    LogMessage $LogLevel.Info ('Collecting Geneva scheduled task information')

    if (!($ver -like "*Windows 7*")) {
        if (Get-ScheduledTask GenevaTask* -ErrorAction Ignore) { 
            Try {
                CreateLogFolder $SchedLogFolder
            } Catch {
                LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
                Return
            }

            (Get-ScheduledTask GenevaTask*).TaskName | ForEach-Object -Process {
                $Commands = @(
                    "Export-ScheduledTask -TaskName $_ 2>&1 | Out-File -Append " + $SchedLogFolder + $LogFile + "schtasks_" + $_ + ".xml"
                    "Get-ScheduledTaskInfo -TaskName $_ 2>&1 | Out-File -Append " + $SchedLogFolder + $LogFile + "schtasks_" + $_ + "_Info.txt"
                )
                RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True
            }
        } else { 
            LogMessage $LogLevel.Warning "[$LogPrefix] Geneva Scheduled Task not found."
        }
    }

    #Collecting event logs
    " " | Out-File -Append $OutputLogFile
    LogMessage $LogLevel.Info ('Collecting event log information')
    Try {
        CreateLogFolder $EventLogFolder
    } Catch {
        LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
        Return
    }
    $LogPrefix = "EventLog"
    $Commands = @(
        "GetEventLogs 'System' 'System'"
        "GetEventLogs 'Application' 'Application'"
        "GetEventLogs 'Security' 'Security'"
        "GetEventLogs 'RemoteDesktopServices' 'RemoteDesktopServices'"
        "GetEventLogs 'Microsoft-WindowsAzure-Diagnostics/Bootstrapper' 'WindowsAzure-Diag-Bootstrapper'"
        "GetEventLogs 'Microsoft-WindowsAzure-Diagnostics/GuestAgent' 'WindowsAzure-Diag-GuestAgent'"
        "GetEventLogs 'Microsoft-WindowsAzure-Diagnostics/Heartbeat' 'WindowsAzure-Diag-Heartbeat'"
        "GetEventLogs 'Microsoft-WindowsAzure-Diagnostics/Runtime' 'WindowsAzure-Diag-Runtime'"
        "GetEventLogs 'Microsoft-WindowsAzure-Status/GuestAgent' 'WindowsAzure-Status-GuestAgent'"
        "GetEventLogs 'Microsoft-WindowsAzure-Status/Plugins' 'WindowsAzure-Status-Plugins'"
        "GetEventLogs 'Microsoft-Windows-CAPI2/Operational' 'CAPI2'"
        "GetEventLogs 'Microsoft-Windows-DSC/Operational' 'DSC-Operational'"
        "GetEventLogs 'Microsoft-Windows-WinRM/Operational' 'WinRM-Operational'"
        "GetEventLogs 'Microsoft-Windows-PowerShell/Operational' 'PowerShell-Operational'"
        "GetEventLogs 'Microsoft-Windows-RemoteAssistance/Operational' 'RemoteAssistance-Operational'"
        "GetEventLogs 'Microsoft-Windows-RemoteAssistance/Admin' 'RemoteAssistance-Admin'"
        "GetEventLogs 'Microsoft-Windows-RemoteDesktopServices-RdpCoreTS/Operational' 'RemoteDesktopServicesRdpCoreTS-Operational'"
        "GetEventLogs 'Microsoft-Windows-RemoteDesktopServices-RdpCoreTS/Admin' 'RemoteDesktopServicesRdpCoreTS-Admin'"
        "GetEventLogs 'Microsoft-Windows-RemoteDesktopServices-RdpCoreCDV/Operational' 'RemoteDesktopServicesRdpCoreCDV-Operational'"
        "GetEventLogs 'Microsoft-Windows-TerminalServices-LocalSessionManager/Operational' 'TerminalServicesLocalSessionManager-Operational'"
        "GetEventLogs 'Microsoft-Windows-TerminalServices-LocalSessionManager/Admin' 'TerminalServicesLocalSessionManager-Admin'"
        "GetEventLogs 'Microsoft-Windows-TerminalServices-RemoteConnectionManager/Admin' 'TerminalServicesRemoteConnectionManager-Admin'"
        "GetEventLogs 'Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational' 'TerminalServicesRemoteConnectionManager-Operational'"
        "GetEventLogs 'Microsoft-Windows-TerminalServices-PnPDevices/Admin' 'TerminalServicesPnPDevices-Admin'"
        "GetEventLogs 'Microsoft-Windows-TerminalServices-PnPDevices/Operational' 'TerminalServicesPnPDevices-Operational'"   
        "GetEventLogs 'Microsoft-Windows-WinINet-Config/ProxyConfigChanged' 'WinHttp-ProxyConfigChanged'"
    )
    RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True

    #Collecting registry keys
    " " | Out-File -Append $OutputLogFile
    LogMessage $LogLevel.Info ('Collecting registry key information')
    Try {
        CreateLogFolder $RegLogFolder
    } Catch {
        LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
        Return
    }
    $LogPrefix = "Reg"
    $Commands = @(
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Azure\DSC' 'SW-MS-Azure-DSC.txt'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\NET Framework Setup\NDP' 'SW-MS-NetFS-NDP.txt'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\RDMonitoringAgent' 'SW-MS-RDMonitoringAgent.txt'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\RDInfraAgent' 'SW-MS-RDInfraAgent.txt'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Terminal Server Client' 'SW-MS-TerminalServerClient.txt'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows\CurrentVersion\Policies' 'SW-MS-Win-CV-Policies.txt'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows\CurrentVersion\Run' 'SW-MS-Win-CV-Run.txt'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Terminal Server' 'SW-MS-WinNT-CV-TerminalServer.txt'"

        "GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\Cryptography' 'SW-Policies-MS-Cryptography.txt'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation' 'SW-Policies-MS-Win-CredentialsDelegation.txt'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' 'SW-Policies-MS-WinNT-TerminalServices.txt'"
    
        "GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\Cryptography' 'System-CCS-Control-Cryptography.txt'"
        "GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\Lsa' 'System-CCS-Control-LSA.txt'"    
        "GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\Remote Assistance' 'System-CCS-Control-MSRA.txt'"
        "GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\SecurityProviders' 'System-CCS-Control-SecurityProviders.txt'"
        "GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\Terminal Server' 'System-CCS-Control-TerminalServer.txt'"

        "GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\RdAgent' 'System-CCS-Svc-RdAgent.txt'"
        "GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\TermService' 'System-CCS-Svc-TermService.txt'"
        "GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\UmRdpService' 'System-CCS-Svc-UmRdpService.txt'"
        "GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\WinRM' 'System-CCS-Svc-WinRM.txt'"
    
        "GetRegKeys 'HKCU' 'SOFTWARE\Microsoft\RdClientRadc' 'SW-MS-RdClientRadc.txt'"
        "GetRegKeys 'HKCU' 'SOFTWARE\Microsoft\Remote Desktop' 'SW-MS-RemoteDesktop.txt'"
    )
    RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True

    if (!($ver -like "*Windows 7*")) {
    $Commands = @(
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\RDAgentBootLoader' 'SW-MS-RDAgentBootLoader'"
        "GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\RDAgentBootLoader' 'System-CCS-Svc-RDAgentBootLoader'"
    )
    RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True
    } else {
        $Commands = @(
            "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\WVDAgentManager' 'SW-MS-WVDAgentManager'"
            "GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\WVDAgent' 'System-CCS-Svc-WVDAgent'"
            "GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\WVDAgentManager' 'System-CCS-Svc-WVDAgentManager'"        
        )
        RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True
    }

    #Collecting RDP and Net info
    " " | Out-File -Append $OutputLogFile
    LogMessage $LogLevel.Info ('Collecting networking information')

    $LogPrefix = "Net"
    if (!($ver -like "*Windows 7*")) {
        $Commands = @(
            "Get-NetConnectionProfile | Out-File -Append " + $NetLogFolder + $LogFile + "NetConnectionProfile.txt"
        )
        RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True
    }

    $Commands = @(
        "netsh advfirewall firewall show rule name=all 2>&1 | Out-File -Append " + $NetLogFolder + $LogFile + "FirewallRules.txt"
        "netstat -anob 2>&1 | Out-File -Append " + $NetLogFolder + $LogFile + "Netstat.txt"
        "ipconfig /all 2>&1 | Out-File -Append " + $NetLogFolder + $LogFile + "Ipconfig.txt"
        "netsh winhttp show proxy 2>&1 | Out-File -Append " + $NetLogFolder + $LogFile + "WinHTTP-Proxy.txt"
        "nslookup wpad 2>&1 | Out-File -Append " + $NetLogFolder + $LogFile + "WinHTTP-Proxy.txt"
        "nslookup rdweb.wvd.microsoft.com 2>&1 | Out-File -Append " + $NetLogFolder + $LogFile + "WinHTTP-Proxy.txt"
    )
    RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True

    #Collecting system information
    " " | Out-File -Append $OutputLogFile
    LogMessage $LogLevel.Info ('Collecting system information')
    $LogPrefix = "System"

    LogMessage $LogLevel.Normal "[$LogPrefix] Collecting details about currently running processes"
    $proc = Get-CimInstance -Namespace "root\cimv2" -Query "select Name, CreationDate, ProcessId, ParentProcessId, WorkingSetSize, UserModeTime, KernelModeTime, ThreadCount, HandleCount, CommandLine, ExecutablePath from Win32_Process" -ErrorAction Continue 2>>$ErrorLogFile
    if ($PSVersionTable.psversion.ToString() -ge "3.0") {
        $StartTime= @{e={$_.CreationDate.ToString("yyyyMMdd HH:mm:ss")};n="Start time"}
    } else {
        $StartTime= @{n='StartTime';e={$_.ConvertToDateTime($_.CreationDate)}}
    }

    if ($proc) {
        $proc | Sort-Object Name | Format-Table -AutoSize -property @{e={$_.ProcessId};Label="PID"}, @{e={$_.ParentProcessId};n="Parent"}, Name,
        @{N="WorkingSet";E={"{0:N0}" -f ($_.WorkingSetSize/1kb)};a="right"},
        @{e={[DateTime]::FromFileTimeUtc($_.UserModeTime).ToString("HH:mm:ss")};n="UserTime"}, @{e={[DateTime]::FromFileTimeUtc($_.KernelModeTime).ToString("HH:mm:ss")};n="KernelTime"},
        @{N="Threads";E={$_.ThreadCount}}, @{N="Handles";E={($_.HandleCount)}}, $StartTime, CommandLine | Out-String -Width 500 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "RunningProcesses.txt")

        LogMessage $LogLevel.Normal "[$LogPrefix] Collecting file version of running and key system binaries"
        $binlist = $proc | Group-Object -Property ExecutablePath
        foreach ($file in $binlist) {
            if ($file.Name) {
                FileVersion -Filepath ($file.name) -Log $true 2>&1 | Out-Null
            }
        }
        
        $pad = 27
        $OS = Get-CimInstance -Namespace "root\cimv2" -Query "select Caption, CSName, OSArchitecture, BuildNumber, InstallDate, LastBootUpTime, LocalDateTime, TotalVisibleMemorySize, FreePhysicalMemory, SizeStoredInPagingFiles, FreeSpaceInPagingFiles from Win32_OperatingSystem" -ErrorAction Continue 2>>$ErrorLogFile
        $CS = Get-CimInstance -Namespace "root\cimv2" -Query "select Model, Manufacturer, SystemType, NumberOfProcessors, NumberOfLogicalProcessors, TotalPhysicalMemory, DNSHostName, Domain, DomainRole from Win32_ComputerSystem" -ErrorAction Continue 2>>$ErrorLogFile
        $BIOS = Get-CimInstance -Namespace "root\cimv2" -query "select BIOSVersion, Manufacturer, ReleaseDate, SMBIOSBIOSVersion from Win32_BIOS" -ErrorAction Continue 2>>$ErrorLogFile
        $TZ = Get-CimInstance -Namespace "root\cimv2" -Query "select Description from Win32_TimeZone" -ErrorAction Continue 2>>$ErrorLogFile
        $PR = Get-CimInstance -Namespace "root\cimv2" -Query "select Name, Caption from Win32_Processor" -ErrorAction Continue 2>>$ErrorLogFile

        $ctr = Get-Counter -Counter "\Memory\Pool Paged Bytes" -ErrorAction Continue 2>>$ErrorLogFile
        $PoolPaged = $ctr.CounterSamples[0].CookedValue 
        $ctr = Get-Counter -Counter "\Memory\Pool Nonpaged Bytes" -ErrorAction Continue 2>>$ErrorLogFile
        $PoolNonPaged = $ctr.CounterSamples[0].CookedValue 

        "Computer name".PadRight($pad) + " : " + $OS.CSName 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "Model".PadRight($pad) + " : " + $CS.Model 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "Manufacturer".PadRight($pad) + " : " + $CS.Manufacturer 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "BIOS Version".PadRight($pad) + " : " + $BIOS.BIOSVersion 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "BIOS Manufacturer".PadRight($pad) + " : " + $BIOS.Manufacturer 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "BIOS Release date".PadRight($pad) + " : " + $BIOS.ReleaseDate 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "SMBIOS Version".PadRight($pad) + " : " + $BIOS.SMBIOSBIOSVersion 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "SystemType".PadRight($pad) + " : " + $CS.SystemType 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "Processor".PadRight($pad) + " : " + $PR.Name + " / " + $PR.Caption 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "Processors physical/logical".PadRight($pad) + " : " + $CS.NumberOfProcessors + " / " + $CS.NumberOfLogicalProcessors 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "Memory physical/visible".PadRight($pad) + " : " + ("{0:N0}" -f ($CS.TotalPhysicalMemory/1mb)) + " MB / " + ("{0:N0}" -f ($OS.TotalVisibleMemorySize/1kb)) + " MB" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "Pool Paged / NonPaged".PadRight($pad) + " : " + ("{0:N0}" -f ($PoolPaged/1mb)) + " MB / " + ("{0:N0}" -f ($PoolNonPaged/1mb)) + " MB" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "Free physical memory".PadRight($pad) + " : " + ("{0:N0}" -f ($OS.FreePhysicalMemory/1kb)) + " MB" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "Paging files size / free".PadRight($pad) + " : " + ("{0:N0}" -f ($OS.SizeStoredInPagingFiles/1kb)) + " MB / " + ("{0:N0}" -f ($OS.FreeSpaceInPagingFiles/1kb)) + " MB" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "Operating System".PadRight($pad) + " : " + $OS.Caption + " " + $OS.OSArchitecture 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")

        [string]$WinVerBuild = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentBuild).CurrentBuild
        [string]$WinVerRevision = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' UBR).UBR

        if (!($ver -like "*Windows 7*")) {                              
            [string]$WinVerMajor = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentMajorVersionNumber).CurrentMajorVersionNumber
            [string]$WiNVerMinor = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentMinorVersionNumber).CurrentMinorVersionNumber
            "Build Number".PadRight($pad) + " : " + $WinVerMajor + "." + $WiNVerMinor + "." + $WinVerBuild + "." + $WinVerRevision 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        } else {
            "Build Number".PadRight($pad) + " : " + $WinVerBuild + "." + $WinVerRevision 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        }

        "Installation type".PadRight($pad) + " : " + (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").InstallationType 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "Time zone".PadRight($pad) + " : " + $TZ.Description 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "Install date".PadRight($pad) + " : " + $OS.InstallDate 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "Last boot time".PadRight($pad) + " : " + $OS.LastBootUpTime 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "Local time".PadRight($pad) + " : " + $OS.LocalDateTime 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "DNS Hostname".PadRight($pad) + " : " + $CS.DNSHostName 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "DNS Domain name".PadRight($pad) + " : " + $CS.Domain 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        "NetBIOS Domain name".PadRight($pad) + " : " + (GetNBDomainName) 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
        $roles = "Standalone Workstation", "Member Workstation", "Standalone Server", "Member Server", "Backup Domain Controller", "Primary Domain Controller"
        "Domain role".PadRight($pad) + " : " + $roles[$CS.DomainRole] 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")

        " " | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")

        $drives = @()
        $drvtype = "Unknown", "No Root Directory", "Removable Disk", "Local Disk", "Network Drive", "Compact Disc", "RAM Disk"
        $Vol = Get-CimInstance -NameSpace "root\cimv2" -Query "select * from Win32_LogicalDisk" -ErrorAction Continue 2>>$ErrorLogFile
        foreach ($disk in $vol) {
                $drv = New-Object PSCustomObject
                $drv | Add-Member -type NoteProperty -name Letter -value $disk.DeviceID 
                $drv | Add-Member -type NoteProperty -name DriveType -value $drvtype[$disk.DriveType]
                $drv | Add-Member -type NoteProperty -name VolumeName -value $disk.VolumeName 
                $drv | Add-Member -type NoteProperty -Name TotalMB -Value ($disk.size)
                $drv | Add-Member -type NoteProperty -Name FreeMB -value ($disk.FreeSpace)
                $drives += $drv
            }
        $drives | Format-Table -AutoSize -property Letter, DriveType, VolumeName, @{N="TotalMB";E={"{0:N0}" -f ($_.TotalMB/1MB)};a="right"}, @{N="FreeMB";E={"{0:N0}" -f ($_.FreeMB/1MB)};a="right"} 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
    } else {
        $proc = Get-Process | Where-Object {$_.Name -ne "Idle"}
        $proc | Format-Table -AutoSize -property id, name, @{N="WorkingSet";E={"{0:N0}" -f ($_.workingset/1kb)};a="right"},
        @{N="VM Size";E={"{0:N0}" -f ($_.VirtualMemorySize/1kb)};a="right"},
        @{N="Proc time";E={($_.TotalProcessorTime.ToString().substring(0,8))}}, @{N="Threads";E={$_.threads.count}},
        @{N="Handles";E={($_.HandleCount)}}, StartTime, Path | Out-String -Width 300 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "RunningProcesses.txt")
    }

    $Commands = @(
        "Get-DscConfigurationStatus -all 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFile + "Get-DscConfiguration.txt"
        "gpresult /h " + $SysInfoLogFolder + $LogFile + "Gpresult.html" + " 2>&1 | Out-Null"
        "gpresult /r /z 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFile + "Gpresult-rz.txt"
        "Get-HotFix -ErrorAction SilentlyContinue | Sort-Object -Property InstalledOn -Descending -ErrorAction SilentlyContinue 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFile + "Hotfixes.txt"
        "(Get-Item -Path 'C:\Windows\System32\*.dll').VersionInfo | Format-List -Force 2>&1 | Out-File " + $SysInfoLogFolder + $LogFile + "ver_System32_DLL.txt"
        "(Get-Item -Path 'C:\Windows\System32\*.exe').VersionInfo | Format-List -Force 2>&1 | Out-File " + $SysInfoLogFolder + $LogFile + "ver_System32_EXE.txt"
        "(Get-Item -Path 'C:\Windows\System32\*.sys').VersionInfo | Format-List -Force 2>&1 | Out-File " + $SysInfoLogFolder + $LogFile + "ver_System32_SYS.txt"
        "(Get-Item -Path 'C:\Windows\System32\drivers\*.sys').VersionInfo | Format-List -Force 2>&1 | Out-File " + $SysInfoLogFolder + $LogFile + "ver_Drivers.txt"
        "(Get-Item -Path 'C:\Windows\SysWOW64\*.dll').VersionInfo | Format-List -Force 2>&1 | Out-File " + $SysInfoLogFolder + $LogFile + "ver_SysWOW64_DLL.txt"
        "(Get-Item -Path 'C:\Windows\SysWOW64\*.exe').VersionInfo | Format-List -Force 2>&1 | Out-File " + $SysInfoLogFolder + $LogFile + "ver_SysWOW64_EXE.txt"
        "(Get-Item -Path 'C:\Windows\SysWOW64\*.sys').VersionInfo | Format-List -Force 2>&1 | Out-File " + $SysInfoLogFolder + $LogFile + "ver_SysWOW64_SYS.txt"
        "msinfo32 /nfo " + $SysInfoLogFolder + $LogFile + "msinfo32.nfo" + " 2>&1 | Out-Null"
        "fltmc filters 2>&1 | Out-File " + $SysInfoLogFolder + $LogFile + "Fltmc.txt"
        "GetWinRMConfig"
    )
    RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True

    LogMessage $LogLevel.Normal "[$LogPrefix] Collecting PowerShell and .Net version information"
    "PowerShell Information:" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
    $PSVersionTable | Format-Table Name, Value 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
    ".Net Framework Information:" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
    Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP' -Recurse | Get-ItemProperty -Name version -EA 0 | Where-Object { $_.PSChildName -Match '^(?!S)\p{L}'} | Select-Object PSChildName, version 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "SystemInfo.txt")
    
    LogMessage $LogLevel.Normal "[$LogPrefix] Collecting service details"
    $svc = Get-CimInstance -NameSpace "root\cimv2" -Query "select  ProcessId, DisplayName, StartMode,State, Name, PathName, StartName from Win32_Service" -ErrorAction Continue
    if ($svc) {
        $svc | Sort-Object DisplayName | Format-Table -AutoSize -Property ProcessId, DisplayName, StartMode,State, Name, PathName, StartName | Out-String -Width 400 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFile + "Services.txt")
    }

    $LogPrefix = "Cert"
    LogMessage $LogLevel.Info "[$LogPrefix] Collecting certificates information"
    Try {
        CreateLogFolder $CertLogFolder
    } Catch {
        LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
        Return
    }
    $Commands = @(
        "certutil -verifystore -v MY 2>&1 | Out-File -Append " + $CertLogFolder + $LogFile + "Certificates-My.txt"
    )
    RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True

    LogMessage $LogLevel.Normal "[$LogPrefix] Exporting additional certificates information"
    $tbCert = New-Object system.Data.DataTable
    $col = New-Object system.Data.DataColumn Store,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn Thumbprint,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn Subject,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn Issuer,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn NotAfter,([DateTime]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn IssuerThumbprint,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn EnhancedKeyUsage,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn SerialNumber,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn SubjectKeyIdentifier,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn AuthorityKeyIdentifier,([string]); $tbCert.Columns.Add($col)
    GetStore "My"
    $aCert = $tbCert.Select("Store = 'My' ")
    foreach ($cert in $aCert) {
        $aIssuer = $tbCert.Select("SubjectKeyIdentifier = '" + ($cert.AuthorityKeyIdentifier).tostring() + "'")
        if ($aIssuer.Count -gt 0) {
        $cert.IssuerThumbprint = ($aIssuer[0].Thumbprint).ToString()
        }
    }
    $tbcert | Export-Csv ($CertLogFolder + $LogFile + "Certificates.csv") -noType -Delimiter "`t"
        
}


<#
.SYNOPSIS
    Collects Profiles specific WVD troubleshooting data, as part of the 'Extented' scenario
.DESCRIPTION
    CollectUEX_WVDProfilesLog (no parameters)
.NOTES
    Date: 2021.04.06
#>
Function CollectUEX_WVDProfilesLog{

    " " | Out-File -Append $OutputLogFile
    LogMessage $LogLevel.Info ('Collecting Profiles information (incl. FSLogix if present)')

    $LogPrefix = "Profiles"
    if (Test-path -path 'C:\Program Files\FSLogix') {

        Try {
            CreateLogFolder $FSLogixLogFolder
        } Catch {
            LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
            Return
        }

        #Collecting FSLogix Logs        
        $Commands = @( 
            "GetFSLogixLogFiles 'C:\ProgramData\FSLogix\Logs\*'"
        )
        RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True

        $cmd = "c:\program files\fslogix\apps\frx.exe" 
      
        if (Test-path -path 'C:\Program Files\FSLogix\apps') {           
            LogMessage $LogLevel.Normal ("[$LogPrefix] Running frx.exe version")
            Invoke-Expression "& '$cmd' + 'version'" | Out-File -FilePath ($FSLogixLogFolder + $LogFile + 'frx-list.txt') -Append
            
            " " | Out-File -FilePath ($FSLogixLogFolder + $LogFile + 'Frx-list.txt') -Append
            "==========================================" | Out-File -FilePath ($FSLogixLogFolder + $LogFile + 'Frx-list.txt') -Append
            " " | Out-File -FilePath ($FSLogixLogFolder + $LogFile + 'Frx-list.txt') -Append
            
            LogMessage $LogLevel.Normal ("[$LogPrefix] Running frx.exe list-redirects")
            Invoke-Expression "& '$cmd' + 'list-redirects'" | Out-File -FilePath ($FSLogixLogFolder + $LogFile + 'frx-list.txt') -Append
            
            " " | Out-File -FilePath ($FSLogixLogFolder + $LogFile + 'Frx-list.txt') -Append
            "==========================================" | Out-File -FilePath ($FSLogixLogFolder + $LogFile + 'Frx-list.txt') -Append
            " " | Out-File -FilePath ($FSLogixLogFolder + $LogFile + 'Frx-list.txt') -Append
            
            LogMessage $LogLevel.Normal ("[$LogPrefix] Running frx.exe list-rules")
            Invoke-Expression "& '$cmd' + 'list-rules'" | Out-File -FilePath ($FSLogixLogFolder + $LogFile + 'frx-list.txt') -Append
        } else {
            LogMessage $LogLevel.Error ("[$LogPrefix] 'C:\Program Files\FSLogix\apps' folder not found.")
        }

        $Commands = @(
            "GetRegKeys 'HKLM' 'SOFTWARE\FSLogix' 'SW-FSLogix'"
            "GetRegKeys 'HKLM' 'SOFTWARE\Policies\FSLogix' 'SW-Policies-FSLogix'"
        )
        RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True
    } else {
        LogMessage $LogLevel.Error ("[$LogPrefix] 'C:\Program Files\FSLogix' folder not found.")
    }

    #Collecting profile registry keys
    $LogPrefix = "Reg"
    $Commands = @(
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows Defender\Exclusions\Extensions' 'SW-MS-WinDef-Excl-Extensions'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths' 'SW-MS-WinDef-Excl-Paths'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes' 'SW-MS-WinDef-Excl-Processes'"
        "GetRegKeys 'HKCU' 'SOFTWARE\Microsoft\Office' 'SW-MS-Office'"
        "GetRegKeys 'HKCU' 'Software\Policies\Microsoft\office' 'SW-Policies-MS-Office'"
        "GetRegKeys 'HKCU' 'SOFTWARE\Microsoft\OneDrive' 'HKCU_SW-MS-OneDrive'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\OneDrive' 'HKLM_SW-MS-OneDrive'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\OneDrive' 'HKLM_SW-Pol-MS-OneDrive'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows Search' 'SW-MS-WindowsSearch'"
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList' 'SW-MS-WinNT-CV-ProfileList'"
    )
    RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True

    #Collecting profiles event logs
    $LogPrefix = "EventLog"
    $Commands = @(
        "GetEventLogs 'Microsoft-Windows-User Profile Service/Operational' 'UserProfileService-Operational'"
        "GetEventLogs 'Microsoft-Windows-VHDMP-Operational' 'VHDMP-Operational'"
        "GetEventLogs 'Microsoft-Windows-SMBClient/Operational' 'SMBClient-Operational'"
        "GetEventLogs 'Microsoft-Windows-SMBClient/Connectivity' 'SMBClient-Connectivity'"
        "GetEventLogs 'Microsoft-Windows-SMBClient/Security' 'SMBClient-Security'"
        "GetEventLogs 'Microsoft-Windows-SMBServer/Operational' 'SMBServer-Operational'"
        "GetEventLogs 'Microsoft-Windows-SMBServer/Connectivity' 'SMBServer-Connectivity'"
        "GetEventLogs 'Microsoft-Windows-SMBServer/Security' 'SMBServer-Security'"
        "GetEventLogs 'Microsoft-FSLogix-Apps/Admin' 'FSLogix-Apps-Admin'"
        "GetEventLogs 'Microsoft-FSLogix-Apps/Operational' 'FSLogix-Apps-Operational'"
        "GetEventLogs 'Microsoft-FSLogix-CloudCache/Admin' 'FSLogix-CloudCache-Admin'"
        "GetEventLogs 'Microsoft-FSLogix-CloudCache/Operational' 'FSLogix-CloudCache-Operational'"
    )
    RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True


}


<#
.SYNOPSIS
    Collects Microsoft Teams specific WVD troubleshooting data, as part of the 'Extented' scenario
.DESCRIPTION
    CollectUEX_WVDTeamsLog (no parameters)
.NOTES
    Date: 2021.04.06
#>
Function CollectUEX_WVDTeamsLog{

    $LogPrefix = "Teams"
    " " | Out-File -Append $OutputLogFile
    LogMessage $LogLevel.Info ('Collecting information on Teams and WVD media optimization for Teams')
    
    $Commands = @(
        "GetTeamsLogs"
        "GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Teams' 'SW-MS-Teams'"
        "GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\RDWebRTCSvc' 'System-CCS-Svc-RDWebRTCSvc'"
    )
    RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True

}


<#
.SYNOPSIS
    Runs WVD Diagnostics
.DESCRIPTION
    RunUEX_WVDDiag (no parameters)
.NOTES
    Date: 2021.04.06
#>
Function RunUEX_WVDDiag{

    $LogPrefix = "Diag" 
    " " | Out-File -Append $OutputLogFile
    if (!$DiagOnly) { 
        LogMessage $LogLevel.Info "Data collection complete - starting diagnostics (... please wait ...)" "Cyan"
    } else {
        LogMessage $LogLevel.Info "Starting diagnostics (... please wait ...)" "Cyan"
    }
    " " | Out-File -Append $OutputLogFile
    Write-Host

    $DiagFile = $BasicLogFolder + "WVD-Diag.txt"

    "WVD Diagnostics" | Out-File -Append $diagfile 
    "==========================================" | Out-File -Append $diagfile
    "The information below is not a replacement for a full data analysis." | Out-File -Append $diagfile
    "It is meant to help get a better overview of the system, catch some known issues and overall ease further troubleshooting. Depending on the scenario you are investigating, additional data collection and analysis may be required." | Out-File -Append $diagfile
    "==========================================" | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile

    
    #Brief deployment info
    LogDiag $LogLevel.Info "Checking environment"

    LogDiag $LogLevel.Normal ("[$LogPrefix] FQDN: " + $fqdn)
    
    if (($ver -like "*Pro*")) {
        LogDiag $LogLevel.Warning ("[$LogPrefix] [WARNING] OS: " + $ver + ". If this machine is a WVD host VM, then this OS is not supported to be run inside WVD. WVD only supports host VMs running Enterprise or Server OS.")
    } else {
        LogDiag $LogLevel.Normal ("[$LogPrefix] OS: " + $ver)
    } 
    
    [string]$WinVerBuild = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentBuild).CurrentBuild
    [string]$WinVerRevision = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' UBR).UBR

    if (!($ver -like "*Windows 7*")) {                              
        [string]$WinVerMajor = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentMajorVersionNumber).CurrentMajorVersionNumber
        [string]$WiNVerMinor = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentMinorVersionNumber).CurrentMinorVersionNumber
        LogDiag $LogLevel.Normal ("[$LogPrefix] OS Build: " + $WinVerMajor + "." + $WiNVerMinor + "." + $WinVerBuild + "." + $WinVerRevision)
    } else {    
        LogDiag $LogLevel.Normal ("[$LogPrefix] OS Build: " + $WinVerBuild + "." + $WinVerRevision)
    }

    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\RDMonitoringAgent') {
        if (test-registryvalue -path "HKLM:\SOFTWARE\Microsoft\RDMonitoringAgent" -value "SessionHostPool") {
            $hp = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Microsoft\RDMonitoringAgent" -name "SessionHostPool"
            LogDiag $LogLevel.Normal ("[$LogPrefix] Machine is part of WVD host pool: " + $hp)
        } else {
            LogDiag $LogLevel.Warning ("[$LogPrefix] [WARNING] 'RDMonitoringAgent' registry key found, but this machine does not seem to be part of any WVD host pool. It might have host pool registration issues.")
        }

        if (test-registryvalue -path "HKLM:\SOFTWARE\Microsoft\RDMonitoringAgent" -value "Ring") {
            $ring = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Microsoft\RDMonitoringAgent" -name "Ring"
            
            if ($ring -eq "R0") {
                LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] Host pool ring: " + $ring + ". This is a validation ring, intended for testing, not production use.")
            } else {
                LogDiag $LogLevel.Normal ("[$LogPrefix] Host pool ring: " + $ring)
            }
        }

        if (test-registryvalue -path "HKLM:\SOFTWARE\Microsoft\RDInfraAgent" -value "Geography") {
            $geo = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Microsoft\RDInfraAgent" -name "Geography"
            LogDiag $LogLevel.Normal ("[$LogPrefix] Geography: " + $geo)
        }
    } else {
        LogDiag $LogLevel.Normal ("[$LogPrefix] This machine does not seem to be part of any WVD host pool.")
    }


    #Checking status of key services

    " " | Out-File -Append $diagfile 
    "==========================================" | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile  

    LogDiag $LogLevel.Info "Checking status of key services"

    if (!($ver -like "*Windows 7*")) {
        $servlist = "RdAgent", "RDAgentBootLoader", "TermService", "SessionEnv", "UmRdpService", "WinRM", "AppXSvc", "AppReadiness", "frxsvc", "frxdrv", "frxccds", "OneDrive Updater Service", "msiserver"
    } else {
        $servlist = "WVDAgent", "WVDAgentManager", "TermService", "SessionEnv", "UmRdpService", "WinRM", "frxsvc", "frxdrv", "frxccds", "OneDrive Updater Service", "msiserver"
    }

    $servlist | ForEach-Object -Process {

        $service = Get-Service -Name $_ -ErrorAction SilentlyContinue
        if ($service.Length -gt 0) {
            $servstatus = (Get-Service $_).Status
            $servdispname = (Get-Service $_).DisplayName
            $servstart = (Get-Service $_).StartType
            if ($servstart -eq "Disabled") {
                LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] " + $_ + " (" + $servdispname + ") is in '" + $servstatus + "' state (StartType: " + $servstart + ").")
            } else {
                LogDiag $LogLevel.Normal ("[$LogPrefix] " + $_ + " (" + $servdispname + ") is in '" + $servstatus + "' state (StartType: " + $servstart + ").")
            }
        }
        else {
            LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] " + $_ + " not found.")
        }
    }
    

    #Checking WVD Agent and Stack information (not for Win7)

    " " | Out-File -Append $diagfile 
    "==========================================" | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile

    LogDiag $LogLevel.Info "Checking WVD Agent and Stack information"

    if (!($ver -like "*Windows 7*")) {

    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\RDAgentBootLoader') {

            if (Test-RegistryValue -Path 'HKLM:\SOFTWARE\Microsoft\RDAgentBootLoader\' -Value 'DefaultAgent') {

                $wvdagent = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\RDAgentBootLoader\' -name "DefaultAgent"
                $wvdagentver = $wvdagent.split("_")[1]

                $sxsstack = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\RDInfraAgent\SxsStack' -name "CurrentVersion"
                $sxsstackpath = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\RDInfraAgent\SxsStack' -name $sxsstack
                $sxsstackver = $sxsstackpath.split("-")[1].trimend(".msi")

                $wvdagentdate = (Get-ItemProperty  hklm:\software\microsoft\windows\currentversion\uninstall\* | Where-Object {($_.DisplayName -eq "Remote Desktop Services Infrastructure Agent" -and $_.DisplayVersion -eq $wvdagentver)}).InstallDate
                LogDiag $LogLevel.Normal ("[$LogPrefix] Current WVD Agent version: " + $wvdagentver + " (Installed on: " + $wvdagentdate + ")")

                $sxsstackdate = (Get-ItemProperty  hklm:\software\microsoft\windows\currentversion\uninstall\* | Where-Object {($_.DisplayName -eq "Remote Desktop Services SxS Network Stack" -and $_.DisplayVersion -eq $sxsstackver)}).InstallDate
                LogDiag $LogLevel.Normal ("[$LogPrefix] Current SxS Stack version: " + $sxsstackver + " (Installed on: " + $sxsstackdate + ")")
            
                if (Test-RegistryValue -Path 'HKLM:\SOFTWARE\Microsoft\RDAgentBootLoader\' -Value 'PreviousAgent') {

                    $wvdagentpre = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\RDAgentBootLoader\' -name "PreviousAgent"
                    $wvdagentverpre = $wvdagentpre.split("_")[1]
                    $wvdagentdatepre = (Get-ItemProperty  hklm:\software\microsoft\windows\currentversion\uninstall\* | Where-Object {($_.DisplayName -eq "Remote Desktop Services Infrastructure Agent" -and $_.DisplayVersion -eq $wvdagentverpre)}).InstallDate
                    LogDiag $LogLevel.Normal ("[$LogPrefix] Previous WVD Agent version: " + $wvdagentverpre + " (Installed on: " + $wvdagentdatepre + ")")                    

                    if (Test-RegistryValue -Path 'HKLM:\SOFTWARE\Microsoft\RDInfraAgent\SxsStack\' -Value 'PreviousVersion') {
                        $sxsstackpre = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\RDInfraAgent\SxsStack' -name "PreviousVersion"
                        $sxsstackpathpre = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\RDInfraAgent\SxsStack' -name $sxsstackpre
                        $sxsstackverpre = $sxsstackpathpre.split("-")[1].trimend(".msi")
                        $sxsstackdatepre = (Get-ItemProperty  hklm:\software\microsoft\windows\currentversion\uninstall\* | Where-Object {($_.DisplayName -eq "Remote Desktop Services SxS Network Stack" -and $_.DisplayVersion -eq $sxsstackverpre)}).InstallDate
                    } else {
                        $sxsstackverpre = "N/A"
                        $sxsstackdatepre = "N/A"
                    }                
                    LogDiag $LogLevel.Normal ("[$LogPrefix] Previous SxS Stack version: " + $sxsstackverpre + " (Installed on: " + $sxsstackdatepre + ")")
                }

            } else {
                LogDiag $LogLevel.Normal ("[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDAgentBootLoader\DefaultAgent' not found. This machine is either not a WVD VM or the WVD agent is not installed or configured properly.")
            }
        } else {
            LogDiag $LogLevel.Normal ("[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDAgentBootLoader' not found. This machine is either not a WVD VM or the WVD agent is not installed or configured properly.")
        }

    } else {
        LogDiag $LogLevel.Warning ("[$LogPrefix] Windows 7 detected. Skipping check (not applicable).")
    }


    #Checking for RD Listener configuration

    " " | Out-File -FilePath $diagfile -Append
    "==========================================" | Out-File -FilePath $diagfile -Append
    " " | Out-File -FilePath $diagfile -Append

    LogDiag $LogLevel.Info "Checking Remote Desktop Listener configuration"
    
    $Commands = @(
        "CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\' 'fEnableWinStation' '1'"
    )
    RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True


    #checking if multiple WVD listener reg keys are present

    if (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\rdp-sxs*') {

        (Get-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\rdp-sxs*').PSChildName | foreach-object -process {  
        
            $wvdlistener = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\" + $_
            
            if (Test-RegistryValue -Path $wvdlistener -Value 'fEnableWinStation') {

                $wvdkeyvalue = Get-ItemPropertyValue -Path $wvdlistener -name "fEnableWinStation"
                LogDiag $LogLevel.Normal ("[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\" + $_ + "\fEnableWinStation' exists and has a value of: " + $wvdkeyvalue)
            }
            else {
                LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] WVD Listener registry keys found, but the registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\" + $_ + "\fEnableWinStation' not found.")
            }
        }
    }
    else {
        LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] No WVD listener (HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\rdp-sxs*) registry keys found. This machine is either not a WVD VM or the WVD listener is not configured properly.")
    }


    #checking for the current WVD listener version and "fReverseConnectMode"

    if (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations') {

        if (Test-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\' -Value 'ReverseConnectionListener') {

            $listenervalue = Get-ItemPropertyValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations' -name "ReverseConnectionListener"

            LogDiag $LogLevel.Normal ("[$LogPrefix] The WVD listener currently in use is: " + $listenervalue)

            $listenerregpath = 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\' + $listenervalue

              if (Test-RegistryValue -Path $listenerregpath -Value 'fReverseConnectMode') {

                $revconkeyvalue = Get-ItemPropertyValue -Path $listenerregpath -name "fReverseConnectMode"
                if ($revconkeyvalue = 1) {
                  LogDiag $LogLevel.Normal ("[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\" + $listenervalue + "\fReverseConnectMode' exists and has a value of: " + $revconkeyvalue)
                } else {
                  LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\" + $listenervalue + "\fReverseConnectMode' exists BUT has a value of: " + $revconkeyvalue + " (instead of the expected value of '1'). Please review: https://docs.microsoft.com/en-us/azure/virtual-desktop/troubleshoot-agent#error-stack-listener-isnt-working-on-windows-10-2004-vm")
                }            
              }
              else {
                  LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\" + $listenervalue + "\fReverseConnectMode not found.")
              }

        } else {
            LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\ReverseConnectionListener' not found. This machine is either not a WVD VM or the WVD listener is not configured properly.")
        }
    } else {
        LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations' not found. This machine is either not a WVD VM or the WVD listener is not configured properly.")
    }
    


    #Checking for known WVD Agent issues

    " " | Out-File -FilePath $diagfile -Append
    "==========================================" | Out-File -FilePath $diagfile -Append
    " " | Out-File -FilePath $diagfile -Append

    LogDiag $LogLevel.Info "Checking for known WVD Agent issues"

    $LogPrefix = "Diag"
    $Commands = @(
        "DiagWVDAgentIssues 'Application' '3277' 'INVALID_REGISTRATION_TOKEN'"
        "DiagWVDAgentIssues 'Application' '3277' 'INVALID_FORM'"
        "DiagWVDAgentIssues 'Application' '3277' 'InstallationHealthCheckFailedException'"
        "DiagWVDAgentIssues 'Application' '3277' 'ENDPOINT_NOT_FOUND'"
        "DiagWVDAgentIssues 'Application' '3277' 'InstallMsiException'"
        "DiagWVDAgentIssues 'Application' '3277' 'DownloadMsiException'"
        "DiagWVDAgentIssues 'Application' '3019' 'Transport received an exception'"
        "DiagWVDAgentIssues 'Application' '3703' 'RD Gateway Url'"
        "DiagWVDAgentIssues 'Application' '3389' 'MissingMethodException'"
    )
    RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True
    


    #Checking for WinHTTP proxy settings

    " " | Out-File -FilePath $diagfile -Append
    "==========================================" | Out-File -FilePath $diagfile -Append
    " " | Out-File -FilePath $diagfile -Append

    LogDiag $LogLevel.Info "Checking for NETSH WINHTTP proxy configuration"

    $binval = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Connections" -Name WinHttpSettings).WinHttPSettings            
    $proxylength = $binval[12]            
    if ($proxylength -gt 0) {
      $proxy = -join ($binval[(12+3+1)..(12+3+1+$proxylength-1)] | ForEach-Object {([char]$_)})            
      LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] A NETSH WINHTTP proxy is configured: " + $proxy)
      $bypasslength = $binval[(12+3+1+$proxylength)]            
      if ($bypasslength -gt 0) {            
        $bypasslist = -join ($binval[(12+3+1+$proxylength+3+1)..(12+3+1+$proxylength+3+1+$bypasslength)] | ForEach-Object {([char]$_)})            
        LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] Bypass list: " + $bypasslist)
       } else {            
        LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] No bypass list is configured."
      }            
      LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] WVD may not work very well through proxies when the required URLs are not allowed. Please review https://docs.microsoft.com/en-us/azure/virtual-desktop/safe-url-list to make sure all URLs are accessible."
    } else {
      LogDiag $LogLevel.Normal "[$LogPrefix] No NETSH WINHTTP proxy configuration found."
    }

    

    #Checking 'SSL Cipher Suite Order' configuration

    " " | Out-File -FilePath $diagfile -Append
    "==========================================" | Out-File -FilePath $diagfile -Append
    " " | Out-File -FilePath $diagfile -Append

    LogDiag $LogLevel.Info "Checking 'SSL Cipher Suite Order' configuration"

    if (Test-Path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002') {

        if (Test-RegistryValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -Value 'Functions') {

            $rdpkeyvalue = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -name "Functions"
            LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\Functions' exists and has a value of: " + $rdpkeyvalue)
            LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] Make sure that the configured SSL cipher suites contain also the ones required by Azure Front Door: https://docs.microsoft.com/en-us/azure/frontdoor/front-door-faq#what-are-the-current-cipher-suites-supported-by-azure-front-door"
        }
        else {
            LogDiag $LogLevel.Normal "[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\Functions' not found. 'SSL Cipher Suite Order' is not configured."
        }
    } else {
        LogDiag $LogLevel.Normal "[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\Functions' not found. 'SSL Cipher Suite Order' is not configured."
    }
    



    #Checking if the Remote Desktop Session Host role is installed (only if OS is Windos Server based)

    " " | Out-File -FilePath $diagfile -Append
    "==========================================" | Out-File -FilePath $diagfile -Append
    " " | Out-File -FilePath $diagfile -Append

    LogDiag $LogLevel.Info "Checking Remote Desktop Session Host role presence"

    if ($ver -like "*Windows Server*") {
        
        if (Get-WindowsFeature -Name RDS-RD-Server) {
            LogDiag $LogLevel.Normal "[$LogPrefix] Remote Desktop Session Host role is installed on this VM."
        }
        else {
            LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] Remote Desktop Session Host role is not installed on this VM. The VM is running server OS and the RDSH role is required for proper host pool registration."
        }

    } else {
        LogDiag $LogLevel.Warning "[$LogPrefix] Windows Server OS not found. Skipping check (not applicable)." 
    }
   



    #Checking FSLogix version and “CleanupInvalidSessions” registry key when running FSLogix release 2009 or later

    " " | Out-File -Append $diagfile 
    "==========================================" | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile

    LogDiag $LogLevel.Info "Checking FSLogix version"
    $cmd = "c:\program files\fslogix\apps\frx.exe" 
      
    if (Test-path -path 'C:\Program Files\FSLogix\apps') {           
        Invoke-Expression "& '$cmd' + 'version'" | ForEach-Object -Process {
            LogDiag $LogLevel.Normal ("[$LogPrefix] " + $_)
            if ($_ -like "*Service*") {
                $frxver = ($_.Split(":")[1]).Trim()
            }
        }
        $frxver = $frxver.Replace(".","")
        if ($frxver -ge 29762130127) {
            LogDiag $LogLevel.Normal "[$LogPrefix] FSLogix release 2009 or later found. Always use the latest FSLogix version. Visit https://docs.microsoft.com/en-us/fslogix/whats-new to check the latest available version."
            $Commands = @(
                "CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Apps\' 'CleanupInvalidSessions' '1'"
            )
            RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True
            if (($global:regok -eq 2) -or ($global:regok -eq 0)) {
                LogDiag $LogLevel.Normal ("[$LogPrefix] If the FSLogix VHD(x) file is not dismounted as expected when the user's session is terminated, the 'CleanupInvalidSessions' registry key might help. See: https://docs.microsoft.com/en-au/fslogix/profile-container-configuration-reference#cleanupinvalidsessions for Profile Containers and/or https://docs.microsoft.com/en-us/fslogix/office-container-configuration-reference#cleanupinvalidsessions for Office Containers.")
            }
        } else {
            LogDiag $LogLevel.Normal "[$LogPrefix] FSLogix release earlier than release 2009 found. Please update FSLogix to the latest version. Review: https://docs.microsoft.com/en-us/fslogix/whats-new"
        }
    } else {
        LogDiag $LogLevel.Warning "[$LogPrefix] FSLogix not found. Skipping check (not applicable)."
    }




    #Checking for proper Defender Exclusions for FSLogix

    " " | Out-File -Append $diagfile 
    "==========================================" | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile

    LogDiag $LogLevel.Info "Checking for recommended Windows Defender Exclusions for FSLogix"

    if (Test-path -path 'C:\Program Files\FSLogix\apps') {
  
      LogDiag $LogLevel.Normal "[$LogPrefix] The tool is comparing the local settings with the recommended settings from: https://docs.microsoft.com/en-us/azure/architecture/example-scenario/wvd/windows-virtual-desktop-fslogix#antivirus-exclusions"
      LogDiag $LogLevel.Normal "[$LogPrefix] The recommendations might change over time, so verify them periodically and ensure that you are using the latest recommendations."
      LogDiag $LogLevel.Normal "[$LogPrefix] The below information is only for Windows Defender. If you are using any other Antivirus software, configure the recommended exclusions similarly, based on the above article."
                  
      if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths') {          
        LogDiag $LogLevel.Normal "[$LogPrefix] Windows Defender Paths exclusions"
        if ((Get-Item 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths').Property) {

            $recpaths = @("%ProgramFiles%\FSLogix\Apps\frxdrv.sys","%ProgramFiles%\FSLogix\Apps\frxdrvvt.sys","%ProgramFiles%\FSLogix\Apps\frxccd.sys","%TEMP%\*.VHD","%TEMP%\*.VHDX","%Windir%\TEMP\*.VHD","%Windir%\TEMP\*.VHDX","\\storageaccount.file.core.windows.net\share*\*.VHD","\\storageaccount.file.core.windows.net\share*\*.VHDX","%ProgramData%\FSLogix\Cache\*.VHD","%ProgramData%\FSLogix\Cache\*.VHDX","%ProgramData%\FSLogix\Proxy\*.VHD","%ProgramData%\FSLogix\Proxy\*.VHDX")
            $foundpaths = @((Get-Item 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths').Property)
            $msgpath = Compare-Object -ReferenceObject($foundpaths) -DifferenceObject($recpaths)
          
            LogDiag $LogLevel.Normal "[$LogPrefix] Comparing local values found with recommended values. False positives may occur if you use full paths instead of environment variables."
            if ($msgpath) {              
              LogDiag $LogLevel.Normal "[$LogPrefix] => means a recommended value that is not configured on this VM."
              LogDiag $LogLevel.Normal "[$LogPrefix] <= means a local value that is not part of the default list of recommended values."
              
              $msgpath | Out-File -FilePath $diagfile -Append
            } else {
              LogDiag $LogLevel.Normal "[$LogPrefix] No differences found."
            }

        } else {
            LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] No Paths exclusions have been found. Follow the above article to configure the recommended exclusions."
        }         
      }

      if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes') {          
        LogDiag $LogLevel.Normal "[$LogPrefix] Windows Defender Processes exclusions"
        if ((Get-Item 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes').Property) {

            $recprocesses = @("%ProgramFiles%\FSLogix\Apps\frxccd.exe","%ProgramFiles%\FSLogix\Apps\frxccds.exe","%ProgramFiles%\FSLogix\Apps\frxsvc.exe")
            $foundprocesses = @((Get-Item 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes').Property)
            $msgproc = Compare-Object -ReferenceObject($foundprocesses) -DifferenceObject($recprocesses)

            LogDiag $LogLevel.Normal "[$LogPrefix] Comparing local values found with recommended values. False positives may occur if you use full paths instead of environment variables."
            if ($msgproc) {
              LogDiag $LogLevel.Normal "[$LogPrefix] => means a recommended value that is not configured on this VM."
              LogDiag $LogLevel.Normal "[$LogPrefix] <= means a local value that is not part of the default list of recommended values."
              
              $msgproc | Out-File -FilePath $diagfile -Append
            } else {
              LogDiag $LogLevel.Normal "[$LogPrefix] No differences found."
            }

        } else {
            LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] No Processes exclusions have been found. Follow the above article to configure the recommended exclusions."
        }    
      }
    } else {
        LogDiag $LogLevel.Warning "[$LogPrefix] FSLogix not found. Skipping check (not applicable)."
    }

    


    #Checking OneDrive configuration

    " " | Out-File -Append $diagfile 
    "==========================================" | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile

    LogDiag $LogLevel.Info "Checking OneDrive configuration"

    $ODM = "C:\Program Files (x86)\Microsoft OneDrive" + '\OneDrive.exe'
    $ODU = "$ENV:localappdata" + '\Microsoft\OneDrive\OneDrive.exe'

    if ((test-path $ODM) -or (test-path $ODU)) {
        $Commands = @(
            "CheckRegKeyValue 'HKLM:\Software\Microsoft\OneDrive\' 'AllUsersInstall' '1'"
        )
        RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True

        if ($global:regok -eq 1) { 
            LogDiag $LogLevel.Normal "[$LogPrefix] OneDrive is installed in per-machine mode."
        } else {
            LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] OneDrive is installed in per-user mode."
        }

        $Commands = @(
            "CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Profiles\' 'ConcurrentUserSessions' '0'"
            "CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Profiles\' 'ProfileType' '0'"
            "CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\FSLogix\ODFC\' 'VHDAccessMode' '0'"
        )
        RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True

        LogDiag $LogLevel.Normal "[$LogPrefix] OneDrive does not support multiple simultaneous connections / multiple concurrent connections, using the same profile, under any circumstances."

    } else {
        LogDiag $LogLevel.Warning "[$LogPrefix] OneDrive installation not found."
    }

    

    #Checking media optimization configuration for Teams

    " " | Out-File -Append $diagfile 
    "==========================================" | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile

    LogDiag $LogLevel.Info "Checking media optimization configuration for Teams"


    if ($ver -like "*Windows 10*") {

        #Checking Teams installation info
    
        $TeamsLogPath = $env:userprofile + "\AppData\Local\Microsoft\Teams\current\Teams.exe"
        if(Test-Path $TeamsLogPath) {
            LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] Teams is installed in per-user mode."
            $isinst = $true
        }
        elseif (Test-Path "C:\Program Files (x86)\Microsoft\Teams\current\Teams.exe") {
            LogDiag $LogLevel.Normal "[$LogPrefix] Teams is installed in per-machine mode."
            $isinst = $true
        }
        else {
            LogDiag $LogLevel.Warning "[$LogPrefix] Teams not found. Skipping check (not applicable)."
            $isinst = $false
        }


        if ($isinst) {
            #Checking for IsWVDEnvironment reg key
            if (Test-Path HKLM:\SOFTWARE\Microsoft\Teams) {        
                if (Test-RegistryValue -Path 'HKLM:\SOFTWARE\Microsoft\Teams\' -Value 'IsWVDEnvironment') {

                $teamskeyvalue = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\Teams' -name "IsWVDEnvironment"
                LogDiag $LogLevel.Normal ("[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Teams\IsWVDEnvironment' exists and has a value of: " + $teamskeyvalue)
                }
                else {
                    LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Teams\IsWVDEnvironment' not found. Media optimization for Teams is not configured or this machine is not part of a WVD host pool."
                }
            }
            else {
                LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Teams' not found. Media optimization for Teams is not configured or this machine is not part of a WVD host pool."
            } 
        

            #Checking Teams deployment
            $verpath = $env:userprofile + ”\AppData\Roaming\Microsoft\Teams\settings.json”
    
            if ($PSVersionTable.PSVersion -like "*5.1*") {
                $response = Get-Content $verpath -ErrorAction Continue 
                $response = $response -creplace 'enableIpsForCallingContext','enableIPSForCallingContext'
                $response = $response | ConvertFrom-Json

                LogDiag $LogLevel.Normal ("[$LogPrefix] Teams version: " + $response.version)
                LogDiag $LogLevel.Normal ("[$LogPrefix] Teams ring: " + $response.ring)
                LogDiag $LogLevel.Normal ("[$LogPrefix] Teams environment: " + $response.environment)
            }
            else {
                LogDiag $LogLevel.Normal ("[$LogPrefix] Teams version: " + (Get-Content $verpath -ErrorAction Continue | ConvertFrom-Json -AsHashTable).version)
                LogDiag $LogLevel.Normal ("[$LogPrefix] Teams ring: " + (Get-Content $verpath -ErrorAction Continue | ConvertFrom-Json -AsHashTable).ring)
                LogDiag $LogLevel.Normal ("[$LogPrefix] Teams environment: " + (Get-Content $verpath -ErrorAction Continue | ConvertFrom-Json -AsHashTable).environment)
            }

            if ((Get-CimInstance -Class Win32_Product | Where-Object name -eq "Remote Desktop WebRTC Redirector Service").Version) {
                LogDiag $LogLevel.Normal ("[$LogPrefix] Remote Desktop WebRTC Redirector Service version: " + (Get-CimInstance -Class Win32_Product | Where-Object name -eq "Remote Desktop WebRTC Redirector Service").Version)
            } else {
                LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] The Remote Desktop WebRTC Redirector Service is not installed. Media optimization for Teams is not configured or this machine is not part of a WVD host pool. Please review: https://docs.microsoft.com/en-us/azure/virtual-desktop/teams-on-wvd#install-the-teams-websocket-service")
            }
        }

    } else {
        LogDiag $LogLevel.Warning "[$LogPrefix] Windows 10 OS not found. Skipping check (not applicable)."
    }


    #Checking 'DeleteUserAppContainersOnLogoff' registry key

    " " | Out-File -FilePath $diagfile -Append
    "==========================================" | Out-File -FilePath $diagfile -Append
    " " | Out-File -FilePath $diagfile -Append

    LogDiag $LogLevel.Info "Checking 'DeleteUserAppContainersOnLogoff' registry key"

    $Commands = @(
        "CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\' 'DeleteUserAppContainersOnLogoff' '1'"
    )
    RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True
    if (($global:regok -eq 2) -or ($global:regok -eq 0)) {
        LogDiag $LogLevel.Normal "[$LogPrefix] You could eventually run into host performance/hang issues if this key is not configured. See: https://support.microsoft.com/en-us/help/4490481"
    }

    
    #Checking WinRM configuration

    " " | Out-File -Append $diagfile 
    "==========================================" | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile

    LogDiag $LogLevel.Info "Checking WinRM configuration"

    if ((get-service -name WinRM).status -eq "Running") {
            $ipfilter = Get-Item WSMan:\localhost\Service\IPv4Filter
            if ($ipfilter.Value) {
                if ($ipfilter.Value -eq "*") {
                    LogDiag $LogLevel.Normal "[$LogPrefix] IPv4Filter = *"
                } else {
                    LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] IPv4Filter = " + $ipfilter.Value)
                }
            } else {
                LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] IPv4Filter is empty, WinRM will not listen on IPv4.")
            }

            $ipfilter = Get-Item WSMan:\localhost\Service\IPv6Filter
            if ($ipfilter.Value) {
                if ($ipfilter.Value -eq "*") {
                    LogDiag $LogLevel.Normal "[$LogPrefix] IPv6Filter = *"
                } else {
                    LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] IPv6Filter = " + $ipfilter.Value)
                }
            } else {
                    LogDiag $LogLevel.Normal ("[$LogPrefix] [WARNING] IPv6Filter is empty, WinRM will not listen on IPv6.")
            }
        } else {
            LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] The WinRM service is not running.")
        }

    if (!($ver -like "*Windows 7*")) {
        $fwrules = (Get-NetFirewallPortFilter –Protocol TCP | Where-Object { $_.localport –eq ‘5985’ } | Get-NetFirewallRule)
        if ($fwrules.count -eq 0) {
          LogDiag $LogLevel.Normal "[$LogPrefix] No firewall rule for port 5985."
        } else {
          LogDiag $LogLevel.Normal "[$LogPrefix] Found firewall rule for port 5985. Check the 'FirewallRules.txt' file for more details."
        }


        $fwrules = (Get-NetFirewallPortFilter –Protocol TCP | Where-Object { $_.localport –eq ‘5986’ } | Get-NetFirewallRule)
        if ($fwrules.count -eq 0) {
          LogDiag $LogLevel.Normal "[$LogPrefix] No firewall rule for port 5986."
        } else {
          LogDiag $LogLevel.Normal "[$LogPrefix] Found firewall rule for port 5986. Check the 'FirewallRules.txt' file for more details."
        }
    } else {
        LogDiag $LogLevel.Normal "[$LogPrefix] Windows 7 detected. Skipping firewall port check. (not implemented yet)"
    }


    #Checking the WinRMRemoteWMIUsers__ group"

        if ((get-ciminstance -Class Win32_ComputerSystem).PartOfDomain) {
  
          LogDiag $LogLevel.Normal "[$LogPrefix] Checking the WinRMRemoteWMIUsers__ group"
          $search = New-Object DirectoryServices.DirectorySearcher([ADSI]"")  # This is a Domain local group, therefore we need to collect to a non-global catalog
          $search.filter = "(samaccountname=WinRMRemoteWMIUsers__)"
          try 
            { $results = $search.Findall() } 
          catch {
            $_ | Out-File -FilePath $ErrorLogFile
            } 

          if ($results.count -gt 0) {
            LogDiag $LogLevel.Normal ("[$LogPrefix] Found " + $results.Properties.distinguishedname)
            if ($results.Properties.grouptype -eq  -2147483644) {
              LogDiag $LogLevel.Normal "[$LogPrefix] WinRMRemoteWMIUsers__ is a Domain local group."
            } elseif ($results.Properties.grouptype -eq -2147483646) {
              LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] WinRMRemoteWMIUsers__ is a Global group."
            } elseif ($results.Properties.grouptype -eq -2147483640) {
              LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] WinRMRemoteWMIUsers__ is a Universal group."
            }
            if (get-ciminstance -query "select * from Win32_Group where Name = 'WinRMRemoteWMIUsers__' and Domain = '$env:computername'") {
              LogDiag $LogLevel.Normal "[$LogPrefix] The group WinRMRemoteWMIUsers__ is also present as machine local group."
            }
          } else {
            LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] The WinRMRemoteWMIUsers__ was not found in the domain." 
            if (get-ciminstance -query "select * from Win32_Group where Name = 'WinRMRemoteWMIUsers__' and Domain = '$env:computername'") {
              LogDiag $LogLevel.Normal "[$LogPrefix] The group WinRMRemoteWMIUsers__ is present as machine local group."
            } else {
              LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] WinRMRemoteWMIUsers__ group not found as machine local group!"
            }
          }
        } else {
          LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] The machine is not joined to a domain."
          if (get-ciminstance -query "select * from Win32_Group where Name = 'WinRMRemoteWMIUsers__' and Domain = '$env:computername'") {
            LogDiag $LogLevel.Normal "[$LogPrefix] The group WinRMRemoteWMIUsers__ is present as machine local group."
          } else {
            LogDiag $LogLevel.Normal "[$LogPrefix] [WARNING] WinRMRemoteWMIUsers__ group not found as machine local group!"
          }
        }
        

    #Checking UDP ShortPath configuration

    " " | Out-File -Append $diagfile 
    "==========================================" | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile

    LogDiag $LogLevel.Info "Checking UDP ShortPath configuration"

    if (!($ver -like "*Windows 7*")) {

            $Commands = @(
                "CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\' 'fUseUdpPortRedirector' '1'"
                "CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\' 'UdpPortNumber' '3390'"
            )
            RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True


            # Checking if TermService is listening for UDP

            $udplistener = Get-NetUDPEndpoint -OwningProcess ((get-ciminstance win32_service -Filter "name = 'TermService'").ProcessId) -LocalPort 3390 -ErrorAction SilentlyContinue
            if ($udplistener) {
                LogDiag $LogLevel.Normal "[$LogPrefix] TermService is listening on UDP port 3390."
            }
            else {
                # Checking the process occupying UDP port 3390

                $procpid = (Get-NetUDPEndpoint -LocalPort 3390 -LocalAddress 0.0.0.0 -ErrorAction SilentlyContinue).OwningProcess

                if ($procpid) {
                    LogDiag $LogLevel.Normal "[$LogPrefix] TermService is NOT listening on UDP port 3390. UDP ShortPath is either not configured at all or not configured properly. The UDP port 3390 is being used by:"
                    tasklist /svc /fi "PID eq $procpid" | Out-File -Append $diagfile
                }
                else {
                    LogDiag $LogLevel.Normal "[$LogPrefix] No process is using UDP port 3390. UDP ShortPath is either not configured at all or not configured properly."
                }
            }


            #Checking if there are Firewall rules for UDP 3390

            $fwrules = (Get-NetFirewallPortFilter –Protocol UDP | Where-Object { $_.localport –eq ‘3390’ } | Get-NetFirewallRule)
            if ($fwrules.count -eq 0) {
                LogDiag $LogLevel.Normal "[$LogPrefix] No firewall rule for UDP port 3390."
            } else {
                LogDiag $LogLevel.Normal "[$LogPrefix] Found firewall rule for UDP port 3390. Check the 'FirewallRules.txt' file for more details."
            }
    } else {
        LogDiag $LogLevel.Warning "[$LogPrefix] Windows 7 detected. Skipping check (not applicable)." 
    }
    


    " " | Out-File -Append $diagfile 
    "==========================================" | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile


    Write-Host
    LogMessage $LogLevel.Normal "WVD Diagnostics results are available in the 'WVD-Diag.txt' file in the output folder" "Green"

}


#endregion Main functions 


#endregion Functions


#region ####################### MAIN ########################

Write-Host
LogMessage $LogLevel.Info "Starting WVD-Collect (v$version)" "Cyan"

If (!($Extended) -and ($NoProfiles -or $NoTeams)) {
    LogMessage $LogLevel.Info ("The '-NoTeams' and/or '-NoProfiles' parameters can only be used in combination with the '-Extended' parameter.") "Cyan"
    LogMessage $LogLevel.Info ("Please run the tool again providing all the required parameters or do not use any parameters and select the desired scenario when prompted by the tool.") "Cyan"
    Remove-Item -path $LogDir -Recurse | Out-Null
    CleanUpandExit
}

Write-Host "`n=============== Microsoft CSS Diagnostics Script ===============`n"
Write-Host "This Data Collection is for troubleshooting reported issues for the given scenarios."
Write-Host "Once you have started this script please wait until all data has been collected.`n`n"
Write-Host "======================= IMPORTANT NOTICE =======================`n"
Write-Host "This script is designed to collect information that will help Microsoft Customer Support Services (CSS) troubleshoot an issue you may be experiencing with Windows Virtual Desktop."
Write-Host "The collected data may contain Personally Identifiable Information (PII) and/or sensitive data, such as (but not limited to) IP addresses; PC names; and user names."
Write-Host "The script will save the collected data in a folder and also compress the results into a ZIP file, both in the same location from where the script has been launched."
Write-Host "This folder and its contents or the ZIP file are not automatically sent to Microsoft."
Write-Host "You can send the ZIP file to Microsoft CSS using a secure file transfer tool - Please discuss this with your support professional and also any concerns you may have."
Write-Host "Find our privacy statement here: https://privacy.microsoft.com/en-us/privacy`n"

$UserConsent = Read-Host -Prompt 'Are you sure you want to continue? [Y/N]'

if ($UserConsent.ToLower() -ne "y") {
    Write-Host("Script execution not approved by the admin user, exiting.")
    Remove-Item -path $LogDir -Recurse | Out-Null
    CleanUpandExit
}

Write-Host
if (!($Core) -and !($Extended) -and !($DiagOnly)) {

$title = "Please select one of the following WVD-Collect scenarios:"
$message = "
    1. Collect 'Core' data (without Profiles/FSLogix/OneDrive and without Teams related data) + Run Diagnostics`n
    2. Collect 'Extended' data (includes all 'Core' and also Profiles/FSLogix/OneDrive and Teams related data, as available) + Run Diagnostics`n
    3. Collect 'Extended with Profiles only' data (includes all 'Core' and also Profiles/FSLogix/OneDrive data, as available - does not include Teams data) + Run Diagnostics`n
    4. Collect 'Extended with Teams only' data (includes all 'Core' and also Teams related data, as available - does not include Profiles/FSLogix/OneDrive data) + Run Diagnostics`n
    5. Run 'Diagnostics' only (skip all Core/Extended data collection)`n
"

$coreOpt = New-Object System.Management.Automation.Host.ChoiceDescription '&Core', 'The tool will collect core troubleshooting data without Profiles/FSLogix/OneDrive and without Teams related information. + Run Diagnostics'
$extAllOpt = New-Object System.Management.Automation.Host.ChoiceDescription '&Extended', 'The tool will collect all troubleshooting data included in the Core scenario and also Profiles/FSLogix/OneDrive and Teams related information, as available. If the tool was started with the "-NoTeams" and/or "-NoProfiles" command line parameter(s), these parameters will have priority. + Run Diagnostics'
$extNOTeamsOpt = New-Object System.Management.Automation.Host.ChoiceDescription 'Extended with &Profiles only', 'The tool will collect all troubleshooting data included in the Core scenario and also Profiles/FSLogix/OneDrive related information, as available. No Teams related data will be collected. + Run Diagnostics'
$extNoProfilesOpt = New-Object System.Management.Automation.Host.ChoiceDescription 'Extended with &Teams only', 'The tool will collect all troubleshooting data included in the Core scenario and also Teams related information, as available. No Profiles/FSLogix/OneDrive related data will be collected. + Run Diagnostics'
$diagonlyOption = New-Object System.Management.Automation.Host.ChoiceDescription '&DiagOnly', 'The tool will only run Diagnostics, witout any Core/Extended troubleshooting data collection. Diagnostics will be performed also for Profiles/FSLogix/OneDrive and Teams scenarios.'
 
$options = [System.Management.Automation.Host.ChoiceDescription[]]($coreOpt, $extAllOpt, $extNOTeamsOpt, $extNoProfilesOpt, $diagonlyOption)

$result = $host.ui.PromptForChoice($title, $message, $options, 0)

switch ($result)
{
    0 { 
        Write-Host
        LogMessage $LogLevel.Info ("'Core' scenario selected.")
        $Core = $True
      }
    1 {
        Write-Host
        LogMessage $LogLevel.Info ("'Extended' scenario selected.")
        If ($NoTeams) {
            LogMessage $LogLevel.Info ("'-NoTeams' has been specified. Microsoft Teams data collaction will be skipped. This does not apply to the Diagnostics checks.")
        }
        If ($NoProfiles) {
            LogMessage $LogLevel.Info ("'-NoProfiles' has been specified. FSLogix data collaction will be skipped. This does not apply to the Diagnostics checks.")
        }
        $Extended = $True
      }
    2 {
        Write-Host
        LogMessage $LogLevel.Info ("'Extended with Profiles only' scenario selected. Microsoft Teams data collaction will be skipped. This does not apply to the Diagnostics checks.")
        If ($NoProfiles) {
            LogMessage $LogLevel.Info ("'-NoProfiles' has been specified. FSLogix data collaction will be skipped. This does not apply to the Diagnostics checks.")
        }
        $Extended = $True
        $NoTeams = $True
    }
    3 {
        Write-Host
        LogMessage $LogLevel.Info ("'Extended with Teams only' scenario selected. Profiles/FSLogix/OneDrive data collaction will be skipped. This does not apply to the Diagnostics checks.")
        If ($NoTeams) {
            LogMessage $LogLevel.Info ("'-NoTeams' has been specified. Microsoft Teams data collaction will be skipped. This does not apply to the Diagnostics checks.")
        }
        $Extended = $True
        $NoProfiles = $True
    }
    4 { 
        Write-Host
        LogMessage $LogLevel.Info ("'DiagOnly' scenario selected.")
        $DiagOnly = $True
      }
}

}


$StopWatchDC = [system.diagnostics.stopwatch]::startNew()

Write-Host
" " | Out-File -Append $OutputLogFile


if ($Core -and !($Extended) -and !($DiagOnly)) {
    CloseMSRDC
    " " | Out-File -Append $OutputLogFile
    LogMessage $LogLevel.Info "Starting data collection (... please wait ...)" "Cyan"
    Write-Host
    CollectUEX_WVDBasicLog
    Write-Host
    RunUEX_WVDDiag
}

if ($Extended -and !($DiagOnly)) {
    CloseMSRDC
    " " | Out-File -Append $OutputLogFile
    LogMessage $LogLevel.Info "Starting data collection (... please wait ...)" "Cyan"
    Write-Host
    CollectUEX_WVDBasicLog
    If (!$NoTeams) {
        CollectUEX_WVDTeamsLog
    } else {
        LogMessage $LogLevel.Warning "'-NoTeams' has been specified. Skipping Microsoft Teams data collection. This does not apply to the Diagnostics checks."
    }
    If (!$NoProfiles) {
        CollectUEX_WVDProfilesLog
    } else {
        LogMessage $LogLevel.Warning "'-NoProfiles' has been specified. Skipping FSLogix data collection. This does not apply to the Diagnostics checks."
    }    
    Write-Host
    RunUEX_WVDDiag
}

if ($DiagOnly) {
    RunUEX_WVDDiag
}

#endregion MAIN



#region ####################### Archive results ########################

$StopWatchDC.Stop()
$tsDC =  [timespan]::fromseconds(($StopWatchDC.Elapsed).TotalSeconds)
$elapsedDC = ("{0:hh\:mm\:ss\.fff}" -f $tsDC)

Write-Host
" " | Out-File -Append $OutputLogFile
LogMessage $LogLevel.Info ('Diagnostics complete - archiving files!')

LogMessage $LogLevel.Normal ('Data collection/diagnostics took (hh:mm:ss.fff): ' + $elapsedDC)
                
$destination = $LogRoot + "\" + $LogFolder + ".zip"
Compress-Archive -Path $LogDir -DestinationPath $destination -CompressionLevel Optimal -Force

if (Test-path -path $destination) {  
        LogMessage $LogLevel.Normal ('Zip file ready. Location of the collected data: ' + $LogRoot + '\') "Green"
    } else {
        LogMessage $LogLevel.Error ('Zip file could not be created. Please manually archive the subfolder containing the collected data. Location of the collected data: ' + $LogRoot + '\')
    }

Write-Host
explorer $LogRoot

#endregion Archive


# Disabling quick edit mode as somethimes this causes the script stop working until enter key is pressed.
If($fQuickEditCodeExist){
  [DisableConsoleQuickEdit]::SetQuickEdit($True) | Out-Null
}

# SIG # Begin signature block
# MIIjwAYJKoZIhvcNAQcCoIIjsTCCI60CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBS0F2WVE30Iywi
# 5WINq9eFycpkoTdrj5VXYP1Za6K53KCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVlTCCFZECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCB3DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgU1rIgpzx
# 9FtgFfGvQYQNxeVYqLwFZ8pd5USKKfqrQWcwcAYKKwYBBAGCNwIBDDFiMGCgQIA+
# AFcAVgBEACAAQwBvAGwAbABlAGMAdAAgAGYAbwByACAAVAByAG8AdQBiAGwAZQBz
# AGgAbwBvAHQAaQBuAGehHIAaaHR0cHM6Ly9ha2EubXMvd3ZkLWNvbGxlY3QwDQYJ
# KoZIhvcNAQEBBQAEggEAnX9SIwbwQRk90pjQgfGBUI4/+Pw7hKDWJuW8jEfeHh3V
# FCV46JdakHAswYMLQpN2nMV4ibnoKHqGgqKFTRGqgiOefpW3Edt8OY0NZU6Y2xZP
# pCA8hDcb+80GxjPmFT/LGXi/N8BtTHmyjb+I5AHcWq7aWcgF0F/vwM1sB37iUVg8
# tWpgNTuX5n3X3ERI9PMBX9NNIvM3no0hSwmw8lHB6Fs7OrHQFOUz661tFdxXqzdx
# eTTNc4wzvDGNonlD8rxrJEeQVgNrKqjjl2ozfnT1te7iL92MyHQHHzZhGBLU0dBf
# 1EyUxw9ucw5qyD7D/sbu5X3pnXwsrLGMWtZ7r3K7NqGCEvEwghLtBgorBgEEAYI3
# AwMBMYIS3TCCEtkGCSqGSIb3DQEHAqCCEsowghLGAgEDMQ8wDQYJYIZIAWUDBAIB
# BQAwggFVBgsqhkiG9w0BCRABBKCCAUQEggFAMIIBPAIBAQYKKwYBBAGEWQoDATAx
# MA0GCWCGSAFlAwQCAQUABCAptc5ZFcpw92QzosRnSa3xXhlD4U7P0hRPMfDODXWl
# ZgIGYGMsuzNLGBMyMDIxMDQwODExMTgyNS4wMzVaMASAAgH0oIHUpIHRMIHOMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNy
# b3NvZnQgT3BlcmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRT
# UyBFU046ODk3QS1FMzU2LTE3MDExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFNlcnZpY2Wggg5EMIIE9TCCA92gAwIBAgITMwAAAWAHIPCSSNq+6wAAAAAB
# YDANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAe
# Fw0yMTAxMTQxOTAyMjBaFw0yMjA0MTExOTAyMjBaMIHOMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0
# aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046ODk3QS1F
# MzU2LTE3MDExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC0MYAc0PLGzPFSMz4JjfU1
# pFrNpPEtQmVMjefEi8y1t9efK2WfzuJevBm+EpBP4gVEpOMlXrASjlaJ2yy95wMC
# F5rGIZ+QUdEVzyPVy4s81arJVIBz80z0bTLWbvo7coAqYeTH6rgYmv0qdB44+5RA
# 6zR0fwv9f8QmmckKYCEe5QESSGkVYecvlqm6pm1LBSKBeVB8MMyRSaTl8WLQNLlr
# q2iqXQlMwM4esJCmYDJEa1z9xP8OXLOFO3GImI2URpZtxq/ryYJMk7CltzgYk7ZG
# lv3o7aVvkuqbvzXs1xagM8Lkg43iCJjjnhGr5QPTvVaQnsaNc+lQqadBG9/dOLoT
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQUp5se+LeoF+Ca4XUyCXV80Ou+H2MwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAFTSYCJs6BaaJUHVPJ2HXF+8kpShD9+fa
# oOUP0hae3uI+XQNVfpLL5inWQdY4Y7AbNiJjTiLcjWNrtjcI2uCTcRX/tsvyk3D/
# BhPex/KIK/XPlW9bhxe4LZ3txfL579Am+/SuJm4YuktECIaj3CPHN+lKnj8CjC5t
# 9ifrzvcLiltjSvL/WwOYELvdgI+rn+wBgLjWByIdImaJPm3LiaWDyimNZ70thGtY
# M5hfCf4qz2ODFvL+P4GnpCaLH5HOoG6JmuMNYBQxioCob+7ZU9fud7hxkdk0tajG
# HjcBnxrY4k8UNQZUBGYm5OzxXwnvikYU0Uwkbc1p0oNzRBNMtqi51DCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtIwggI7AgEBMIH8oYHUpIHRMIHOMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3Bl
# cmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046ODk3
# QS1FMzU2LTE3MDExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZp
# Y2WiIwoBATAHBgUrDgMCGgMVAPsyknR1i0TcyJcqh1cV2YCp2dCioIGDMIGApH4w
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQACBQDk
# GN+9MCIYDzIwMjEwNDA4MDU0OTQ5WhgPMjAyMTA0MDkwNTQ5NDlaMHcwPQYKKwYB
# BAGEWQoEATEvMC0wCgIFAOQY370CAQAwCgIBAAICAl8CAf8wBwIBAAICEOEwCgIF
# AOQaMT0CAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQAC
# AwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQBxIfMP6+nyh4xQjIr3
# PNuayKlS/a10fPPxbSemcl5VNI1y1tr1l8fRS24xwFE/XY8D4Ff60PUyVyCqlPtd
# D+L8t9A/3Uzm/uQFxPhpMNEPoBkVKQZeqiODMDi98h8XIzsQsgPBP86/aahQP6/Y
# 8Y7GbB/BNS9BNXVzIneW15XDvTGCAw0wggMJAgEBMIGTMHwxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1l
# LVN0YW1wIFBDQSAyMDEwAhMzAAABYAcg8JJI2r7rAAAAAAFgMA0GCWCGSAFlAwQC
# AQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkE
# MSIEIB7UM+TOBHfyNmwykeiQNsSGEu5RvxuCK3Y0IiIo4jIVMIH6BgsqhkiG9w0B
# CRACLzGB6jCB5zCB5DCBvQQgAhKjvaNzLpdbRaevHuoryn6V0v+PXBcJ4l5I96iw
# ZbkwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAWAH
# IPCSSNq+6wAAAAABYDAiBCBrWKp5aTox+UaGlTHS8phCY1MPv9aIDP9xuVjHie/P
# WzANBgkqhkiG9w0BAQsFAASCAQAg2hBf57PPM1PaAa85n8WdPgnYPSmAE+1j7fyr
# UYE4nSUQsu7+XjYfGG0e/zaAObRgPyjCSdCg6EgduzTuP0KQB5Ftmz62gQFJRE6T
# Ua2b47vBan1iuuwd9gdBIkHbCW6g7IWhmNG+md9PnX/SAHvNSJlzPuxyAZwox83j
# MAlfdrec+yyuF8dMHlC/pMBz8iLofFanD1atkGPZqWFFEnrtvMZlGqXvuKVWpdlP
# 9Ukf+U4lRqAVDP3CwKhgw989oggl4qMQDe1SfhPpJ9deOarZj2rmjrJ/kXk9xUj7
# NE6EPYF79NGixhmwel4ui4Vmi23+eOCUw+AerSdmv6rXU732
# SIG # End signature block
